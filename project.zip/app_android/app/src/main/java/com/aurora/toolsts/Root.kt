package com.aurora.toolsts

import android.content.Context
import android.net.Uri
import java.io.File

/** Kirim file (yang sudah di-enkode) ke folder simpanan game memakai akses root. */
object Root {
    const val PKG = "com.playrix.township"
    const val DEFAULT_DEST = "/data/data/com.playrix.township/Saves/saves"

    private fun q(s: String) = "'" + s.replace("'", "'\\''") + "'"

    fun push(ctx: Context, src: Uri, dest: String, say: (String) -> Unit): Boolean {
        val tmp = File(ctx.cacheDir, "push.tmp")
        ctx.contentResolver.openInputStream(src)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
        say("File sementara siap (${tmp.length()} byte).")
        val d = q(dest)
        val cmd = "am force-stop $PKG; " +
            "cp -f ${q(tmp.absolutePath)} $d && " +
            "U=\$(stat -c %u /data/data/$PKG) && chown \$U:\$U $d && chmod 660 $d; " +
            "restorecon $d 2>/dev/null; echo EXIT=\$?"
        return try {
            val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
            val out = p.inputStream.bufferedReader().readText().trim()
            val code = p.waitFor()
            if (out.isNotEmpty()) say(out)
            tmp.delete()
            code == 0
        } catch (e: Exception) {
            say("Root tidak tersedia: ${e.message}")
            false
        }
    }
}
