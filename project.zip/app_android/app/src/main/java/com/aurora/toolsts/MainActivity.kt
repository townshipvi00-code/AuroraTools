package com.aurora.toolsts

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.sin
import kotlin.random.Random

val FIELDS = linkedMapOf("Koin" to "money", "T-Cash" to "moneyCash", "Level" to "levelup", "Pengalaman" to "experience")
fun rx(v: String) = Regex("(<Var name=\"$v\" v=\")(-?\\d+)(\" t=\"i\"/>)")

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF5CFFC8), onPrimary = Color.Black)) { App() } }
    }
}

@Composable
fun AuroraBackground() {
    val t = rememberInfiniteTransition(label = "a")
    val phase by t.animateFloat(0f, 6.2832f, infiniteRepeatable(tween(14000, easing = LinearEasing)), label = "p")
    val twinkle by t.animateFloat(0.3f, 1f, infiniteRepeatable(tween(2200), RepeatMode.Reverse), label = "s")
    val stars = remember { List(70) { Triple(Random.nextFloat(), Random.nextFloat() * 0.7f, Random.nextFloat() * 2f + 1f) } }
    val bands = listOf(
        Triple(0.18f, Color(0xFF00FFA3), 0f), Triple(0.28f, Color(0xFF7B5CFF), 1.7f), Triple(0.38f, Color(0xFF00D4FF), 3.4f))
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF050A1A), Color(0xFF0B1B3A), Color(0xFF07152B))))) {
        Canvas(Modifier.fillMaxSize()) {
            stars.forEach { (x, y, r) -> drawCircle(Color.White.copy(alpha = twinkle * 0.8f), r, Offset(x * size.width, y * size.height)) }
        }
        Canvas(Modifier.fillMaxSize().blur(36.dp)) {
            bands.forEach { (y0, c, off) ->
                val p = Path()
                p.moveTo(0f, 0f)
                var x = 0f
                while (x <= size.width + 20) {
                    val y = size.height * y0 + sin(x / size.width * 6f + phase + off) * 70f + sin(x / size.width * 11f - phase) * 25f
                    p.lineTo(x, y); x += 20f
                }
                var xr = size.width
                while (xr >= 0) {
                    val y = size.height * (y0 + 0.22f) + sin(xr / size.width * 5f + phase * 1.2f + off) * 60f
                    p.lineTo(xr, y); xr -= 20f
                }
                p.close()
                drawPath(p, Brush.verticalGradient(listOf(c.copy(alpha = 0f), c.copy(alpha = 0.55f), c.copy(alpha = 0f)),
                    startY = size.height * y0 - 80f, endY = size.height * (y0 + 0.3f)))
            }
        }
    }
}

@Composable
fun Glass(content: @Composable ColumnScope.() -> Unit) = Column(
    Modifier.fillMaxWidth().padding(vertical = 6.dp)
        .background(Color(0x33FFFFFF), RoundedCornerShape(20.dp)).padding(16.dp), content = content)

@Composable
fun App() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("auth", android.content.Context.MODE_PRIVATE) }
    var token by remember { mutableStateOf(prefs.getString("token", "") ?: "") }
    if (token.isEmpty()) LoginScreen(prefs) { token = it } else MainApp(prefs) { prefs.edit().remove("token").apply(); token = "" }
}

@Composable
fun LoginScreen(prefs: android.content.SharedPreferences, onOk: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var server by remember { mutableStateOf(prefs.getString("server", "http://10.0.2.2:8080") ?: "") }
    var key by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    var show by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    Box(Modifier.fillMaxSize()) {
        AuroraBackground()
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.Center) {
            Text("AuroraToolsTS", fontSize = 32.sp, fontWeight = FontWeight.Black, color = Color.White)
            Text("Masuk dengan kunci lisensi", color = Color(0xFFB8C7E6))
            Glass {
                OutlinedTextField(server, { server = it }, label = { Text("Alamat server") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(key, { key = it }, label = { Text("Kunci lisensi") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    visualTransformation = if (show) androidx.compose.ui.text.input.VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(),
                    trailingIcon = { TextButton(onClick = { show = !show }) { Text(if (show) "Sembunyi" else "Lihat") } })
                Button(enabled = !busy && key.isNotBlank(), modifier = Modifier.fillMaxWidth().padding(top = 12.dp), onClick = {
                    busy = true; msg = "Memverifikasi..."
                    scope.launch {
                        val dev = android.provider.Settings.Secure.getString(ctx.contentResolver, android.provider.Settings.Secure.ANDROID_ID) ?: "unknown"
                        val (tok, err) = withContext(Dispatchers.IO) { Api.login(server.trim(), key.trim(), dev) }
                        busy = false
                        if (tok != null) { prefs.edit().putString("server", server.trim()).putString("key", key.trim()).putString("token", tok).apply(); onOk(tok) } else msg = err
                    }
                }) { Text(if (busy) "MEMVERIFIKASI..." else "MASUK") }
                if (msg.isNotEmpty()) Text(msg, color = Color(0xFFFFD580), modifier = Modifier.padding(top = 8.dp))
            }
        }
    }
}

@Composable
fun MainApp(prefs: android.content.SharedPreferences, onLogout: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var xml by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf(0) }
    var dest by remember { mutableStateOf(Root.DEFAULT_DEST) }
    var query by remember { mutableStateOf("") }
    var backups by remember { mutableStateOf(listOf<java.io.File>()) }
    var cloud by remember { mutableStateOf(listOf<Triple<Int, Long, Int>>()) }
    val values = remember { mutableStateMapOf<String, String>() }
    val log = remember { mutableStateListOf("[${ts()}] Siap. Pilih file XML hasil decode.") }
    fun say(m: String) { log.add("[${ts()}] $m") }
    fun bdir() = java.io.File(ctx.filesDir, "backups").also { it.mkdirs() }
    fun refreshBackups() { backups = bdir().listFiles()?.sortedByDescending { it.name } ?: emptyList() }
    fun varRx(n: String) = Regex("(<Var name=\"" + Regex.escape(n) + "\" v=\")(-?\\d+)(\" t=\"i\"/>)")
    fun setVar(name: String, n: Long): Boolean {
        if (n < 0 || n > Int.MAX_VALUE) { say("Nilai $name tidak valid (0 - 2147483647)"); return false }
        if (!varRx(name).containsMatchIn(xml)) { say("Variabel $name tidak ditemukan"); return false }
        xml = varRx(name).replaceFirst(xml) { m -> m.groupValues[1] + n + m.groupValues[3] }
        say("✔ $name diperbarui menjadi $n"); return true
    }
    fun load(s: String) {
        xml = s
        FIELDS.forEach { (k, v) -> values[k] = rx(v).find(s)?.groupValues?.get(2) ?: "" }
    }

    val open = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u: Uri? ->
        if (u != null) scope.launch {
            say("Membaca file simpan...")
            val s = withContext(Dispatchers.IO) {
                val t = ctx.contentResolver.openInputStream(u)!!.bufferedReader().readText()
                java.io.File(bdir(), "auto-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".xml").writeText(t)
                bdir().listFiles()?.sortedByDescending { it.name }?.drop(5)?.forEach { it.delete() }
                t
            }
            load(s); refreshBackups()
            say("Cadangan otomatis dibuat. Siap untuk diedit!")
        }
    }
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/xml")) { u: Uri? ->
        if (u != null) scope.launch {
            say("Menyimpan XML hasil edit...")
            withContext(Dispatchers.IO) { ctx.contentResolver.openOutputStream(u)!!.bufferedWriter().use { it.write(xml) } }
            say("Selesai! Enkode ulang XML sebelum dikirim ke Saves.")
        }
    }
    val push = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u: Uri? ->
        if (u != null) scope.launch {
            say("📤 Mengirim ke simpanan game (push melalui root)…")
            val ok = withContext(Dispatchers.IO) { Root.push(ctx, u, dest, ::say) }
            say(if (ok) "Selesai! Buka game kembali." else "Gagal: pastikan root diizinkan & path benar.")
        }
    }
    val ready = xml.isNotEmpty()
    val white = Color.White

    Box(Modifier.fillMaxSize()) {
        AuroraBackground()
        Scaffold(containerColor = Color.Transparent, bottomBar = {
            NavigationBar(containerColor = Color(0x990B1B3A)) {
                listOf("Statistik" to "★", "Jelajah" to "⌕", "Cadangan" to "⛁", "Kirim" to "➤", "Cloud" to "☁").forEachIndexed { i, (n, ic) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i; if (i == 2) refreshBackups() },
                        icon = { Text(ic, fontSize = 20.sp, color = white) }, label = { Text(n, color = white, fontSize = 11.sp) })
                }
            }
        }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).statusBarsPadding().padding(16.dp).verticalScroll(rememberScrollState())) {
                Text("AuroraToolsTS", fontSize = 28.sp, fontWeight = FontWeight.Black, color = white)
                Text(if (ready) "● TERMUAT" else "● BELUM DIMUAT", color = if (ready) Color(0xFF5CFFC8) else Color(0xFFFF8A8A), fontSize = 12.sp)
                Glass {
                    Text("Berkas simpanan", color = white, fontWeight = FontWeight.Bold)
                    Row(Modifier.padding(top = 8.dp)) {
                        Button(onClick = { open.launch(arrayOf("*/*")) }, modifier = Modifier.weight(1f)) { Text("Muat XML") }
                        Spacer(Modifier.width(8.dp))
                        Button(enabled = ready, onClick = { save.launch("mGameInfo_edited.xml") }, modifier = Modifier.weight(1f)) { Text("Simpan XML") }
                    }
                }
                when (tab) {
                    0 -> Glass {
                        Text("Statistik Profil", color = white, fontWeight = FontWeight.Bold)
                        FIELDS.forEach { (k, v) ->
                            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                OutlinedTextField(values[k] ?: "", { values[k] = it.filter(Char::isDigit) }, label = { Text(k) }, singleLine = true,
                                    enabled = ready, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                                Spacer(Modifier.width(8.dp))
                                Button(enabled = ready, onClick = { values[k]?.toLongOrNull()?.let { n -> setVar(v, n) } ?: say("Nilai $k kosong") }) { Text("Apply") }
                            }
                        }
                    }
                    1 -> Glass {
                        Text("Jelajah Variabel", color = white, fontWeight = FontWeight.Bold)
                        Text("Cari nama variabel angka (mis. Boost, Expand, Achievement) lalu ubah nilainya.", color = Color(0xFFB8C7E6), fontSize = 12.sp)
                        OutlinedTextField(query, { query = it }, label = { Text("Cari nama") }, singleLine = true, enabled = ready, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                        if (ready && query.length >= 3) {
                            val hits = remember(xml, query) {
                                Regex("<Var name=\"([^\"]*" + Regex.escape(query) + "[^\"]*)\" v=\"(-?\\d+)\" t=\"i\"/>", RegexOption.IGNORE_CASE)
                                    .findAll(xml).take(15).map { it.groupValues[1] to it.groupValues[2] }.toList()
                            }
                            if (hits.isEmpty()) Text("Tidak ada hasil.", color = white, modifier = Modifier.padding(top = 8.dp))
                            hits.forEach { (n, v) ->
                                var t by remember(n, v) { mutableStateOf(v) }
                                Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    OutlinedTextField(t, { t = it.filter(Char::isDigit) }, label = { Text(n, maxLines = 1) }, singleLine = true,
                                        modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                                    Spacer(Modifier.width(8.dp))
                                    Button(onClick = { t.toLongOrNull()?.let { x -> setVar(n, x) } }) { Text("Apply") }
                                }
                            }
                        }
                    }
                    2 -> Glass {
                        Text("Cadangan & Riwayat", color = white, fontWeight = FontWeight.Bold)
                        Text("Setiap file yang dimuat dicadangkan otomatis (5 terakhir).", color = Color(0xFFB8C7E6), fontSize = 12.sp)
                        if (backups.isEmpty()) Text("Belum ada cadangan.", color = white, modifier = Modifier.padding(top = 8.dp))
                        backups.forEach { f ->
                            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(f.name.removePrefix("auto-").removeSuffix(".xml"), color = white, modifier = Modifier.weight(1f), fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                                Button(onClick = { scope.launch { load(withContext(Dispatchers.IO) { f.readText() }); say("Cadangan ${f.name} dipulihkan ke editor.") } }) { Text("Pulihkan") }
                            }
                        }
                    }
                    3 -> Glass {
                        Text("Kirim ke game (root)", color = white, fontWeight = FontWeight.Bold)
                        Text("Pilih file yang SUDAH di-enkode. Game ditutup lalu file disalin ke path di bawah.", color = Color(0xFFB8C7E6), fontSize = 12.sp)
                        OutlinedTextField(dest, { dest = it }, label = { Text("Path tujuan") }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                        Button(onClick = { push.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("Pilih file & kirim") }
                    }
                    else -> Glass {
                        val base = prefs.getString("server", "") ?: ""
                        val tk = prefs.getString("token", "") ?: ""
                        Text("Cloud", color = white, fontWeight = FontWeight.Bold)
                        Text("Cadangan online di server Anda (10 terakhir).", color = Color(0xFFB8C7E6), fontSize = 12.sp)
                        Row(Modifier.padding(top = 8.dp)) {
                            Button(enabled = ready, modifier = Modifier.weight(1f), onClick = {
                                scope.launch {
                                    say("☁ Mengunggah cadangan...")
                                    val r = withContext(Dispatchers.IO) { runCatching { Api.call(base, "POST", "/api/backup", tk, xml.toByteArray()) }.getOrNull() }
                                    say(if (r?.code == 200) "✔ Cadangan terunggah." else "Gagal unggah (${r?.code ?: "jaringan"}).")
                                    if (r?.code == 401) onLogout()
                                }
                            }) { Text("Unggah") }
                            Spacer(Modifier.width(8.dp))
                            Button(modifier = Modifier.weight(1f), onClick = {
                                scope.launch {
                                    val l = withContext(Dispatchers.IO) { runCatching { Api.list(base, tk) }.getOrNull() }
                                    if (l == null) say("Gagal memuat daftar (sesi habis / jaringan).") else { cloud = l; say("${l.size} cadangan ditemukan.") }
                                }
                            }) { Text("Muat daftar") }
                        }
                        cloud.forEach { (id, ts, size) ->
                            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(ts * 1000)) + " · ${size / 1024} KB", color = white, modifier = Modifier.weight(1f), fontSize = 13.sp)
                                Button(onClick = {
                                    scope.launch {
                                        val r = withContext(Dispatchers.IO) { runCatching { Api.call(base, "GET", "/api/backup/$id", tk) }.getOrNull() }
                                        if (r?.code == 200) { load(r.text); say("Cadangan cloud #$id dipulihkan ke editor.") } else say("Gagal mengunduh #$id.")
                                    }
                                }) { Text("Pulihkan") }
                            }
                        }
                        Row(Modifier.padding(top = 12.dp)) {
                            OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                                scope.launch {
                                    val r = withContext(Dispatchers.IO) { runCatching { Api.call(base, "GET", "/api/version") }.getOrNull() }
                                    if (r?.code != 200) say("Cek update gagal.") else {
                                        val o = org.json.JSONObject(r.text)
                                        @Suppress("DEPRECATION") val cur = ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionCode
                                        say(if (o.getInt("version_code") > cur) "⬆ Update tersedia: ${o.optString("url")}" else "Sudah versi terbaru.")
                                    }
                                }
                            }) { Text("Cek update") }
                            Spacer(Modifier.width(8.dp))
                            OutlinedButton(modifier = Modifier.weight(1f), onClick = onLogout) { Text("Keluar") }
                        }
                    }
                }
                Glass {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("CONSOLE", color = white, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        TextButton(onClick = { log.clear() }) { Text("Clear") }
                    }
                    Column(Modifier.fillMaxWidth().heightIn(min = 120.dp).background(Color(0xCC000000), RoundedCornerShape(12.dp)).padding(10.dp)) {
                        log.takeLast(40).forEach { Text(it, color = Color(0xFFB6FFE0), fontFamily = FontFamily.Monospace, fontSize = 12.sp) }
                    }
                }
            }
        }
    }
}

fun ts(): String = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
