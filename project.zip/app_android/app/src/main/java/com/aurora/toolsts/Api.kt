package com.aurora.toolsts

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Klien HTTP sederhana untuk server lisensi & cadangan AuroraToolsTS. */
object Api {
    class Res(val code: Int, val body: ByteArray) { val text get() = String(body, Charsets.UTF_8) }

    fun call(base: String, method: String, path: String, token: String? = null, body: ByteArray? = null, json: Boolean = false): Res {
        val c = URL(base.trimEnd('/') + path).openConnection() as HttpURLConnection
        c.requestMethod = method; c.connectTimeout = 15000; c.readTimeout = 60000
        if (token != null) c.setRequestProperty("Authorization", "Bearer $token")
        if (json) c.setRequestProperty("Content-Type", "application/json")
        if (body != null) { c.doOutput = true; c.setFixedLengthStreamingMode(body.size); c.outputStream.use { it.write(body) } }
        val code = c.responseCode
        val data = (if (code in 200..299) c.inputStream else c.errorStream)?.use { it.readBytes() } ?: ByteArray(0)
        return Res(code, data)
    }

    /** Kembalikan Pair(token, pesanError). */
    fun login(base: String, key: String, device: String): Pair<String?, String> = try {
        val r = call(base, "POST", "/api/login", body = JSONObject().put("key", key).put("device", device).toString().toByteArray(), json = true)
        if (r.code == 200) JSONObject(r.text).getString("token") to "" else null to (runCatching { JSONObject(r.text).getString("error") }.getOrDefault("Gagal (${r.code})"))
    } catch (e: Exception) { null to "Tidak bisa terhubung: ${e.message}" }

    fun list(base: String, token: String): List<Triple<Int, Long, Int>> {
        val a = JSONArray(call(base, "GET", "/api/backups", token).text)
        return (0 until a.length()).map { val o = a.getJSONObject(it); Triple(o.getInt("id"), o.getLong("created"), o.getInt("size")) }
    }
}
