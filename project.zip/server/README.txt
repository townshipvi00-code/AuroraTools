Jalankan server:   ADMIN_TOKEN=rahasiaAnda python3 server.py
Panel admin:       http://IP-SERVER:8080/admin  (isi Admin token, klik "Buat kunci")
Di aplikasi:       isi Alamat server (mis. https://domain-anda.com) + kunci lisensi.
Emulator Android:  alamat http://10.0.2.2:8080 menunjuk ke komputer Anda.
Produksi:          pakai HTTPS (nginx/Caddy). Pada http biasa kunci & data terkirim tanpa enkripsi.
Update:            LATEST_CODE=2 UPDATE_URL=https://... python3 server.py

Kunci lifetime bawaan: VIP_AURORATS_LIFE (dibuat otomatis saat server pertama jalan).
Ganti/tambah lewat env:  SEED_KEYS="VIP_AURORATS_LIFE,KUNCI_LAIN" python3 server.py
Kunci kustom lain: panel /admin -> isi "Kunci kustom", hari 0 = lifetime.

=== HOSTING GRATIS: PythonAnywhere (akun Beginner) ===
1. Daftar gratis di pythonanywhere.com (tanpa kartu kredit).
2. Tab Files: buat folder  aurora  lalu unggah server.py dan wsgi.py ke dalamnya.
3. Tab Web: Add a new web app -> Manual configuration -> pilih Python 3.10+.
4. Buka "WSGI configuration file", hapus isinya, tempel isi pythonanywhere_wsgi_contoh.py
   (ganti USERNAME dan GANTI_DENGAN_TOKEN_KUAT). Save.
5. Klik Reload. Alamat server Anda:  https://USERNAME.pythonanywhere.com
6. Di aplikasi isi alamat itu + kunci VIP_AURORATS_LIFE. Panel admin: /admin
7. Gratis: web app kedaluwarsa jika tidak diperpanjang (tombol "Run until..." di tab Web, kira-kira tiap bulan).
