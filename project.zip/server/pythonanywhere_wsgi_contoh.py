# Tempel ini ke "WSGI configuration file" di tab Web PythonAnywhere (ganti USERNAME & token)
import sys, os
sys.path.insert(0, "/home/USERNAME/aurora")
os.environ["ADMIN_TOKEN"] = "GANTI_DENGAN_TOKEN_KUAT"
os.environ["DB_PATH"] = "/home/USERNAME/aurora/aurora.db"
os.environ["SEED_KEYS"] = "VIP_AURORATS_LIFE"
from wsgi import application
