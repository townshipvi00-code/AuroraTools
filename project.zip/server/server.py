#!/usr/bin/env python3
"""Server lisensi & cadangan cloud untuk AuroraToolsTS (stdlib saja).
Jalankan:  ADMIN_TOKEN=rahasia123 python3 server.py   (port 8080)
Produksi: taruh di belakang HTTPS (nginx/caddy). Panel admin: /admin"""
import json, os, re, secrets, sqlite3, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ADMIN = os.environ.get("ADMIN_TOKEN") or secrets.token_hex(8)
DB = os.environ.get("DB_PATH", "aurora.db")
LATEST = {"version_code": int(os.environ.get("LATEST_CODE", "1")), "url": os.environ.get("UPDATE_URL", "")}
LIFETIME = 4102444800  # 1 Jan 2100 = seumur hidup
SEED_KEYS = [k for k in os.environ.get("SEED_KEYS", "VIP_AURORATS_LIFE").split(",") if k]
MAX_BODY = 20 * 1024 * 1024
KEEP = 10

def db():
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row; return c
with db() as c:
    c.executescript("""
    CREATE TABLE IF NOT EXISTS keys(k TEXT PRIMARY KEY, device TEXT, expires INTEGER, revoked INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, k TEXT, created INTEGER);
    CREATE TABLE IF NOT EXISTS backups(id INTEGER PRIMARY KEY AUTOINCREMENT, k TEXT, created INTEGER, size INTEGER, data BLOB);""")

with db() as c:  # kunci lifetime bawaan (dibuat sekali)
    for k in SEED_KEYS:
        c.execute("INSERT OR IGNORE INTO keys(k,expires) VALUES(?,?)", (k, LIFETIME))

PANEL = """<!doctype html><meta name=viewport content="width=device-width,initial-scale=1"><title>Aurora Admin</title>
<style>body{font-family:system-ui;background:#0b1b3a;color:#e8f6ff;padding:16px}input,button{font:inherit;padding:8px;margin:4px 0;border-radius:8px;border:0}
button{background:#2ee6a8;font-weight:700}table{width:100%;border-collapse:collapse}td,th{padding:6px;border-bottom:1px solid #345;font-size:13px;word-break:break-all}</style>
<h2>Aurora Admin</h2><input id=t type=password placeholder="Admin token"><br>
<input id=ck placeholder="Kunci kustom (opsional)"><br><input id=d type=number value=30 style=width:80px> hari (0 = lifetime) <button onclick=mk()>Buat kunci</button> <button onclick=ls()>Muat daftar</button>
<table id=T></table><script>
const H=()=>({'X-Admin-Token':document.getElementById('t').value,'Content-Type':'application/json'});
async function mk(){await fetch('/admin/keys',{method:'POST',headers:H(),body:JSON.stringify({days:+d.value,key:ck.value.trim()})});ls()}
async function act(p,k){await fetch(p,{method:'POST',headers:H(),body:JSON.stringify({key:k})});ls()}
async function ls(){const r=await fetch('/admin/keys',{headers:H()});if(!r.ok){T.innerHTML='<tr><td>Token salah</td></tr>';return}
const j=await r.json();T.innerHTML='<tr><th>Kunci<th>Perangkat<th>Berakhir<th>Aksi</tr>'+j.map(x=>`<tr><td>${x.key}${x.revoked?' ⛔':''}<td>${x.device||'-'}<td>${(x.expires>=4102444800?'Lifetime':new Date(x.expires*1000).toLocaleDateString())}<td><button onclick="act('/admin/revoke','${x.key}')">Cabut</button><button onclick="act('/admin/reset-device','${x.key}')">Reset</button></tr>`).join('')}
</script>"""

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def send(self, code, body=b"", ctype="application/json"):
        if isinstance(body, (dict, list)): body = json.dumps(body).encode()
        self.send_response(code); self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
    def body(self):
        n = int(self.headers.get("Content-Length", 0))
        if n > MAX_BODY: raise ValueError("too big")
        return self.rfile.read(n)
    def jbody(self):
        try: return json.loads(self.body() or b"{}")
        except Exception: return {}
    def admin_ok(self): return secrets.compare_digest(self.headers.get("X-Admin-Token", ""), ADMIN)
    def user(self):
        t = self.headers.get("Authorization", "").removeprefix("Bearer ").strip()
        with db() as c:
            r = c.execute("SELECT s.k FROM sessions s JOIN keys k ON k.k=s.k WHERE s.token=? AND k.revoked=0 AND k.expires>?", (t, int(time.time()))).fetchone()
        return r["k"] if r else None

    def do_GET(self):
        p = self.path.split("?")[0]
        if p == "/admin": return self.send(200, PANEL.encode(), "text/html; charset=utf-8")
        if p == "/api/version": return self.send(200, LATEST)
        if p == "/admin/keys":
            if not self.admin_ok(): return self.send(401, {"error": "unauthorized"})
            with db() as c:
                return self.send(200, [{"key": r["k"], "device": r["device"], "expires": r["expires"], "revoked": r["revoked"]} for r in c.execute("SELECT * FROM keys ORDER BY expires DESC")])
        k = self.user()
        if p.startswith("/api/") and not k: return self.send(401, {"error": "unauthorized"})
        if p == "/api/backups":
            with db() as c:
                return self.send(200, [dict(r) for r in c.execute("SELECT id,created,size FROM backups WHERE k=? ORDER BY id DESC", (k,))])
        m = re.fullmatch(r"/api/backup/(\d+)", p)
        if m:
            with db() as c:
                r = c.execute("SELECT data FROM backups WHERE id=? AND k=?", (m.group(1), k)).fetchone()
            return self.send(200, r["data"], "application/octet-stream") if r else self.send(404, {"error": "not found"})
        self.send(404, {"error": "not found"})

    def do_POST(self):
        p = self.path.split("?")[0]
        if p == "/api/login":
            j = self.jbody(); key, dev = str(j.get("key", "")).strip(), str(j.get("device", "")).strip()
            if not key or not dev: return self.send(400, {"error": "data tidak lengkap"})
            with db() as c:
                r = c.execute("SELECT * FROM keys WHERE k=?", (key,)).fetchone()
                if not r or r["revoked"]: return self.send(403, {"error": "kunci tidak valid"})
                if r["expires"] < time.time(): return self.send(403, {"error": "kunci kedaluwarsa"})
                if r["device"] and r["device"] != dev: return self.send(403, {"error": "kunci terikat ke perangkat lain"})
                if not r["device"]: c.execute("UPDATE keys SET device=? WHERE k=?", (dev, key))
                tok = secrets.token_urlsafe(32)
                c.execute("INSERT INTO sessions VALUES(?,?,?)", (tok, key, int(time.time())))
            return self.send(200, {"token": tok, "expires": r["expires"]})
        if p == "/api/backup":
            k = self.user()
            if not k: return self.send(401, {"error": "unauthorized"})
            try: data = self.body()
            except ValueError: return self.send(413, {"error": "terlalu besar"})
            if not data: return self.send(400, {"error": "kosong"})
            with db() as c:
                c.execute("INSERT INTO backups(k,created,size,data) VALUES(?,?,?,?)", (k, int(time.time()), len(data), data))
                c.execute("DELETE FROM backups WHERE k=? AND id NOT IN (SELECT id FROM backups WHERE k=? ORDER BY id DESC LIMIT ?)", (k, k, KEEP))
            return self.send(200, {"ok": True})
        if p.startswith("/admin/"):
            if not self.admin_ok(): return self.send(401, {"error": "unauthorized"})
            j = self.jbody()
            with db() as c:
                if p == "/admin/keys":
                    key = str(j.get("key") or "").strip() or "AUR-" + "-".join(secrets.token_hex(2).upper() + secrets.token_hex(2).upper() for _ in range(3))
                    days = int(j.get("days", 30))
                    exp = LIFETIME if days <= 0 else int(time.time()) + days * 86400
                    if c.execute("SELECT 1 FROM keys WHERE k=?", (key,)).fetchone(): return self.send(409, {"error": "kunci sudah ada"})
                    c.execute("INSERT INTO keys(k,expires) VALUES(?,?)", (key, exp))
                    return self.send(200, {"key": key})
                if p == "/admin/revoke": c.execute("UPDATE keys SET revoked=1 WHERE k=?", (j.get("key"),)); return self.send(200, {"ok": True})
                if p == "/admin/reset-device": c.execute("UPDATE keys SET device=NULL WHERE k=?", (j.get("key"),)); return self.send(200, {"ok": True})
        self.send(404, {"error": "not found"})

if __name__ == "__main__":
    print("ADMIN_TOKEN:", ADMIN, "| panel: http://localhost:8080/admin")
    ThreadingHTTPServer(("0.0.0.0", int(os.environ.get("PORT", "8080"))), H).serve_forever()
