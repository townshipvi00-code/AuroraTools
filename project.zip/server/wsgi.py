"""Adaptor WSGI agar server.py bisa jalan di hosting gratis (PythonAnywhere, dll).
Atur ADMIN_TOKEN dan DB_PATH di file WSGI sebelum import ini."""
import io
from server import H

class _Headers(dict):
    def get(self, k, d=None):
        return super().get(k.lower(), d)

class _Req(H):
    def __init__(self, environ):  # tanpa memanggil __init__ socket
        self.path = environ.get("PATH_INFO", "/")
        n = int(environ.get("CONTENT_LENGTH") or 0)
        self.rfile = io.BytesIO(environ["wsgi.input"].read(n) if n else b"")
        h = _Headers()
        h["content-length"] = str(n)
        h["authorization"] = environ.get("HTTP_AUTHORIZATION", "")
        h["x-admin-token"] = environ.get("HTTP_X_ADMIN_TOKEN", "")
        self.headers = h
        self.out = (500, b"", "text/plain")
    def send(self, code, body=b"", ctype="application/json"):
        import json
        if isinstance(body, (dict, list)): body = json.dumps(body).encode()
        self.out = (code, body, ctype)

_ST = {200: "200 OK", 400: "400 Bad Request", 401: "401 Unauthorized", 403: "403 Forbidden",
       404: "404 Not Found", 409: "409 Conflict", 413: "413 Payload Too Large"}

def application(environ, start_response):
    r = _Req(environ)
    {"GET": r.do_GET, "POST": r.do_POST}.get(environ["REQUEST_METHOD"], lambda: r.send(405, {"error": "method"}))()
    code, body, ctype = r.out
    start_response(_ST.get(code, f"{code} Error"), [("Content-Type", ctype), ("Content-Length", str(len(body)))])
    return [body]
