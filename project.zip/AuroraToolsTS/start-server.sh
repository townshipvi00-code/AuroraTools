#!/bin/sh
# Menjalankan server lisensi + Cloudflare Tunnel, lalu otomatis mengisi alamat ke config.xml
# Syarat: python3 dan cloudflared terpasang. Jalankan dari folder AuroraToolsTS.
cd "$(dirname "$0")"
(cd license-server && python3 server.py serve 8080) &
SP=$!
trap 'kill $SP 2>/dev/null' EXIT
sleep 1
cloudflared tunnel --url http://localhost:8080 2>&1 | while read -r line; do
  echo "$line"
  U=$(echo "$line" | grep -o 'https://[a-z0-9-]*\.trycloudflare\.com' | head -1)
  if [ -n "$U" ]; then
    ./set-server.sh "$U"
    echo ">>> Alamat server: $U"
    echo ">>> Sekarang build APK: ./gradlew assembleRelease (biarkan jendela ini tetap terbuka)"
  fi
done
