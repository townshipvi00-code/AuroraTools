#!/bin/sh
# Pakai: ./set-server.sh https://lisensi.domainanda.com
[ -z "$1" ] && { echo "Pakai: $0 https://domain-anda"; exit 1; }
case "$1" in https://*) ;; *) echo "Harus HTTPS"; exit 1;; esac
U="${1%/}"
sed -i "s|>https://[^<]*<|>$U<|" app/src/main/res/values/config.xml
grep license_server app/src/main/res/values/config.xml
