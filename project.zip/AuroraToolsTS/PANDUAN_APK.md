# Membuat APK AuroraToolsTS tanpa PC (GitHub Actions)

AI Studio hanya membangun aplikasi web, jadi proyek Android native ini dibuild lewat GitHub Actions.

1. Buat akun GitHub, lalu repo baru (disarankan **Private**).
2. Upload ISI folder ini (bukan folder induknya) ke repo, sehingga `.github/`, `app/`, `build.gradle` ada di root repo.
   Tips di HP: buka github.com lewat browser > Add file > Upload files, atau pakai aplikasi Termux/git.
3. Buka tab **Actions** > workflow **Build APK** > **Run workflow** (atau otomatis berjalan setiap push).
4. Setelah hijau (±5–8 menit), buka run tersebut > bagian **Artifacts** > unduh `AuroraToolsTS-apk` (zip).
5. Ekstrak zip, ambil `app-debug.apk`, lalu install di HP (izinkan "Install dari sumber tidak dikenal").

## Opsional: APK rilis bertanda tangan sendiri
Buat keystore (lihat BUILD_RELEASE.md), lalu tambahkan Secrets di Settings > Secrets and variables > Actions:
`KEYSTORE_BASE64` (hasil `base64 -w0 aurora-release.jks`), `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.

## Catatan
- `license-server/licenses.db` (berisi key lisensi) sudah dimasukkan ke .gitignore; jangan upload ke repo publik.
- Alamat server lisensi diatur di `app/src/main/res/values/config.xml`.
