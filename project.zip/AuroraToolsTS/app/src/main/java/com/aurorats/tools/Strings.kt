package com.aurorats.tools

import android.content.Context

/** Bahasa (ID/EN) + preferensi sederhana. */
object S {
    var lang = "id"; private set
    var effects = true; var activated = false; var key = ""
    private lateinit var sp: android.content.SharedPreferences
    private val T = mapOf(
        "id" to mapOf("connect" to "▶ Township", "found" to "● Township terdeteksi", "missing" to "● Township tidak ditemukan",
            "notInstalled" to "Township belum terpasang", "apply" to "Terapkan", "cancel" to "Batal", "engine" to "engine belum terhubung",
            "settings" to "Info & Pengaturan", "language" to "Bahasa", "langName" to "Indonesia", "effects" to "Efek latar", "on" to "Aktif", "off" to "Mati",
            "version" to "Versi", "dev" to "Pengembang", "game" to "Paket game", "mode" to "Fitur terhubung ke engine save game Township.",
            "loginTitle" to "Masuk dengan Key", "keyHint" to "Masukkan key", "loginBtn" to "MASUK", "invalid" to "Key tidak valid", "empty" to "Key tidak boleh kosong", "welcome" to "Berhasil masuk • Lifetime", "license" to "Lisensi", "lifetime" to "Seumur hidup ♾", "logout" to "Keluar / hapus key", "wait" to "Terlalu banyak percobaan, tunggu", "checking" to "Memeriksa key…", "device_limit" to "Key ini sudah dipakai di perangkat lain", "revoked" to "Key telah dicabut", "expired" to "Key sudah kedaluwarsa", "neterr" to "Tidak bisa terhubung ke server lisensi", "bound" to "Terikat ke perangkat ini", "env" to "Lingkungan", "root" to "Root", "yes" to "Terdeteksi", "no" to "Tidak terdeteksi", "virt" to "Ruang virtual", "inVirt" to "App berjalan di ruang virtual", "noVirt" to "App berjalan normal", "none" to "tidak ada",
            "search" to "Cari fitur…", "update" to "Pembaruan tersedia", "exitAgain" to "Tekan sekali lagi untuk keluar", "help" to "Bantuan", "noResult" to "Tidak ada hasil",
            "h1t" to "Key tidak bisa dipakai?", "h1" to "Pastikan ada internet dan key diketik persis. Satu key hanya untuk satu perangkat.",
            "h2t" to "Ganti HP?", "h2" to "Minta admin mereset key Anda, lalu login lagi di perangkat baru.",
            "h3t" to "Township tidak terdeteksi?", "h3" to "Pasang Township dari Play Store, lalu buka ulang AuroraToolsTS.",
            "h4t" to "Cara menerapkan fitur?", "h4" to "Tekan HUBUNGKAN, pilih fitur atau ubah statistik, lalu tekan SIMPAN & KIRIM untuk menulis langsung ke save game Township."),
        "en" to mapOf("connect" to "▶ Township", "found" to "● Township detected", "missing" to "● Township not found",
            "notInstalled" to "Township is not installed", "apply" to "Apply", "cancel" to "Cancel", "engine" to "engine not connected",
            "settings" to "Info & Settings", "language" to "Language", "langName" to "English", "effects" to "Background effects", "on" to "On", "off" to "Off",
            "version" to "Version", "dev" to "Developer", "game" to "Game package", "mode" to "Features connected to Township save engine.",
            "loginTitle" to "Sign in with Key", "keyHint" to "Enter your key", "loginBtn" to "SIGN IN", "invalid" to "Invalid key", "empty" to "Key cannot be empty", "welcome" to "Signed in • Lifetime", "license" to "License", "lifetime" to "Lifetime ♾", "logout" to "Sign out / remove key", "wait" to "Too many attempts, please wait", "checking" to "Checking key…", "device_limit" to "This key is already used on another device", "revoked" to "This key has been revoked", "expired" to "This key has expired", "neterr" to "Cannot reach the license server", "bound" to "Bound to this device", "env" to "Environment", "root" to "Root", "yes" to "Detected", "no" to "Not detected", "virt" to "Virtual space", "inVirt" to "App runs inside a virtual space", "noVirt" to "App runs normally", "none" to "none",
            "search" to "Search features…", "update" to "Update available", "exitAgain" to "Press back again to exit", "help" to "Help", "noResult" to "No results",
            "h1t" to "Key not working?", "h1" to "Make sure you are online and the key is typed exactly. One key works on one device only.",
            "h2t" to "New phone?", "h2" to "Ask the admin to reset your key, then sign in again on the new device.",
            "h3t" to "Township not detected?", "h3" to "Install Township from the Play Store, then reopen AuroraToolsTS.",
            "h4t" to "How to apply features?", "h4" to "Tap CONNECT, choose features or edit stats, then tap SAVE & SEND to write directly to Township save."))
    private val X = mapOf(
        "id" to mapOf("noAccess" to "Data Township tidak bisa dibaca tanpa root di ruang virtual ini. Buka Township sekali dulu di ruang virtual yang sama, atau aktifkan root di sana.", "noRootMode" to "Mode tanpa root (akses file langsung)", "directOk" to "data game terjangkau", "gateVirt" to "Tidak bisa terhubung: bukan ruang virtual, root tidak aktif, dan data Township tidak terjangkau. Jalankan app ini di ruang virtual atau beri izin root.", "gateRoot" to "Root tidak terdeteksi di ruang virtual. Aktifkan root di ruang virtual lalu coba lagi.",
            "checkingEnv" to "Memeriksa ruang virtual…", "working" to "Memproses…", "backupOk" to "Cadangan data kota berhasil", "backupFail" to "Gagal mencadangkan data kota",
            "fetchOk" to "Data kota berhasil diambil", "fetchFail" to "Gagal mengambil data kota", "noBackup" to "Belum ada cadangan", "pickBackup" to "Pilih cadangan (paling bawah = paling lama / asli)", "noGameData" to "Data Township tidak ditemukan di ruang virtual ini. Buka Township sekali dulu."),
        "en" to mapOf("noAccess" to "Township data cannot be read without root in this virtual space. Open Township once in the same virtual space, or enable root there.", "noRootMode" to "No-root mode (direct file access)", "directOk" to "game data reachable", "gateVirt" to "Cannot connect: not a virtual space, no root, and Township data is not reachable. Run this app in a virtual space or grant root.", "gateRoot" to "Root not detected in the virtual space. Enable root there and try again.",
            "checkingEnv" to "Checking virtual space…", "working" to "Working…", "backupOk" to "City data backup complete", "backupFail" to "City data backup failed",
            "fetchOk" to "City data fetched", "fetchFail" to "Failed to fetch city data", "noBackup" to "No backups yet", "pickBackup" to "Pick a backup (bottom = oldest / original)", "noGameData" to "Township data not found in this virtual space. Open Township once first."))
    fun load(c: Context) { sp = c.getSharedPreferences("aurora", Context.MODE_PRIVATE); lang = sp.getString("lang", "id")!!; effects = sp.getBoolean("fx", true); activated = sp.getBoolean("act", false); key = sp.getString("key", "")!! }
    fun setActivated(v: Boolean, k: String = "") { activated = v; key = if (v) k else ""; sp.edit().putBoolean("act", v).putString("key", key).apply() }
    fun t(k: String) = T[lang]?.get(k) ?: X[lang]?.get(k) ?: k
    fun setLang(l: String) { lang = l; sp.edit().putString("lang", l).apply() }
    fun toggleLang() { lang = if (lang == "id") "en" else "id"; sp.edit().putString("lang", lang).apply() }
    fun toggleFx() { effects = !effects; sp.edit().putBoolean("fx", effects).apply() }
}
