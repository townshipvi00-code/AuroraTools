package com.aurorats.tools

import android.app.Activity
import android.os.Build
import android.view.WindowManager
import kotlin.math.abs

/**
 * Pengaturan performa tinggi 60 FPS:
 * Mengaktifkan akselerasi GPU perangkat keras, mengunci laju bingkai ke 60 FPS,
 * dan aman dari crash pada ruang virtual (VPhoneOS, VMOS, dsb.).
 */
object Perf {
    const val TARGET_FPS = 60f

    fun lock60(a: Activity) {
        try {
            val w = a.window ?: return

            // Aktifkan akselerasi perangkat keras di tingkat window
            try {
                w.setFlags(
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
                )
            } catch (_: Throwable) {}

            val lp = w.attributes ?: return

            // Pasang preferensi refresh rate 60 Hz secara aman
            try {
                lp.preferredRefreshRate = TARGET_FPS
            } catch (_: Throwable) {}

            // Pilih mode display 60 Hz jika didukung (aman dari NPE pada ruang virtual)
            if (Build.VERSION.SDK_INT >= 23) {
                try {
                    val disp = if (Build.VERSION.SDK_INT >= 30) {
                        try { a.display } catch (_: Throwable) { null }
                    } else {
                        @Suppress("DEPRECATION")
                        try { a.windowManager?.defaultDisplay } catch (_: Throwable) { null }
                    }
                    if (disp != null) {
                        val cur = try { disp.mode } catch (_: Throwable) { null }
                        val modes = try { disp.supportedModes } catch (_: Throwable) { null }
                        if (cur != null && !modes.isNullOrEmpty()) {
                            val best = modes.firstOrNull {
                                it != null && it.physicalWidth == cur.physicalWidth &&
                                        it.physicalHeight == cur.physicalHeight &&
                                        abs(it.refreshRate - TARGET_FPS) < 1f
                            }
                            if (best != null) {
                                lp.preferredDisplayModeId = best.modeId
                            }
                        }
                    }
                } catch (_: Throwable) {}
            }

            try {
                w.attributes = lp
            } catch (_: Throwable) {}
        } catch (_: Throwable) {}
    }
}
