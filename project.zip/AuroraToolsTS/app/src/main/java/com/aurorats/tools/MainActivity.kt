package com.aurorats.tools

import android.app.Activity
import android.app.AlertDialog
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.*
import android.widget.*

private val BLUE = Color.parseColor("#3D6BFF")
private val PURPLE = Color.parseColor("#9B4DFF")
private val SOFT = Color.parseColor("#C9B8FF")

class MainActivity : Activity() {
    private val stack = ArrayList<Node>()
    private lateinit var content: FrameLayout
    private lateinit var status: TextView
    private lateinit var pill: TextView
    private lateinit var btnConnect: TextView
    private lateinit var btnSave: TextView
    private lateinit var infoConnect: TextView
    private lateinit var infoSave: TextView
    private lateinit var console: View
    private lateinit var bg: AuroraBackground
    private var update: License.Update? = null
    private var lastBack = 0L
    private var lastDepth = 1
    private lateinit var fx: FxOverlay
    private var shown = 0
    private val typer = object : Runnable { override fun run() {
        val tv = consoleTv ?: return; val full = fullStyled ?: styled(consoleLog.toString().trimEnd()).also { fullStyled = it }
        shown = minOf(full.length, shown + maxOf(4, (full.length - shown) / 25))
        val out = android.text.SpannableStringBuilder(full.subSequence(0, shown))
        if (shown < full.length) out.append("▌")
        tv.text = out
        scrollConsole()
        if (shown < full.length) tv.postDelayed(this, 16)
    } }
    private var consoleTv: TextView? = null
    private var fullStyled: android.text.SpannableStringBuilder? = null
    private var cityEt: EditText? = null
    private var statInputs: Map<String, EditText> = emptyMap()   // kolom Statistik Profil yang sedang tampil
    private val statOrig = HashMap<String, String>()             // nilai asli hasil baca save (untuk deteksi kolom yang diubah)
    private var consoleScroll: ScrollView? = null
    private val consoleLog = StringBuilder()   // yang tampil (ringkas)
    private val fullLog = StringBuilder()      // log lengkap, dipakai tombol COPY

    /** Buang baris diagnostik teknis & pangkas baris panjang agar console tetap ringkas. Log lengkap tetap ada di COPY. */
    private val noisy = Regex("^(ukuran|sumber|uji bolak|xml:|mtime|diagnosis|salinan save|var |awal xml|akhir xml|sekitar|ghash|buku kas|cek buku kas|versi aplikasi|nilai money|decoding|mencari id|mgameinfo|tekan simpan|save di disk|cadangan pengaman|terbaca|zoo:|\\s)", RegexOption.IGNORE_CASE)
    private val important = Regex("✘|⚠|gagal|fail|peringatan|belum|tidak ada|tidak bisa|melebihi|tidak ditemukan|^—", RegexOption.IGNORE_CASE)
    /** Ringkas per aksi: buang diagnostik, pertahankan hasil penting (✔ / ✘ / ⚠ / judul), maksimal 4 baris, tiap baris dipangkas. */
    private fun concise(lines: List<String>): List<String> {
        val tsRe = Regex("^\\d\\d:\\d\\d:\\d\\d\\s{2}")
        val bodies = lines.map { it.replace(tsRe, "").trim() }.filter { it.isNotBlank() }
        val key = bodies.filter { it.contains("✔") || important.containsMatchIn(it) }
        val picked = when {
            key.isNotEmpty() -> key
            else -> bodies.filter { !noisy.containsMatchIn(it) }.ifEmpty { bodies.take(1) }
        }
        val out = ArrayList<String>()
        for (ln in picked.take(4)) {
            val short = if (ln.length > 44) ln.take(43).trimEnd() + "…" else ln
            if (out.isEmpty() || out.last() != short) out.add(short)
        }
        return out
    }
    /** Batasi isi console yang tampil: hanya ±30 baris terakhir (log lengkap tetap ada di COPY). */
    private fun trimConsole() {
        val ls = consoleLog.lines().filter { it.isNotEmpty() }
        if (ls.size > 30 || consoleLog.length > 2500) {
            val keep = ls.takeLast(24).joinToString("\n", postfix = "\n")
            consoleLog.setLength(0); consoleLog.append(keep)
        }
    }
    private val wide get() = resources.configuration.screenWidthDp >= 600
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); S.load(this)
        Thread { Env.verifyRoot() }.start()
        window.statusBarColor = Color.BLACK; window.navigationBarColor = Color.BLACK
        build(); show(Menus.root)
        License.latest(this) { u ->
            val cur = try { if (android.os.Build.VERSION.SDK_INT >= 28) packageManager.getPackageInfo(packageName, 0).longVersionCode else @Suppress("DEPRECATION") packageManager.getPackageInfo(packageName, 0).versionCode.toLong() } catch (e: Exception) { 0L }
            if (u != null && u.code > cur && u.url.startsWith("https://")) { update = u; if (stack.size == 1) show(stack[0], false) }
        }
    }

    /** Membangun kerangka UI (dipanggil ulang saat bahasa berubah). */
    private fun build() {
        val root = FrameLayout(this)
        bg = AuroraBackground(this); root.addView(bg)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(6), dp(10), dp(2)) }
        col.addView(header())
        col.addView(tabBar(), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
        content = FrameLayout(this)
        col.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        console = consolePanel(); col.addView(console, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        col.addView(TextView(this).apply { text = "Powered by AuroraTS"; setTextColor(SOFT); gravity = Gravity.CENTER; textSize = 10f; setPadding(0, dp(3), 0, dp(2)); Fx.breathe(this, 0.45f, 1f, 2200) })
        // Tablet: konten dibatasi lebarnya dan diletakkan di tengah.
        root.addView(col, FrameLayout.LayoutParams(if (wide) dp(760) else -1, -1, Gravity.CENTER_HORIZONTAL))
        fx = FxOverlay(this); root.addView(fx, FrameLayout.LayoutParams(-1, -1))
        loadOverlay = loadingOverlay(); root.addView(loadOverlay, FrameLayout.LayoutParams(-1, -1))
        if (loads > 0) { loadOverlay.visibility = View.VISIBLE; loadOverlay.alpha = 1f }
        setContentView(root)
    }

    // ---------- Loading ----------
    private lateinit var loadOverlay: FrameLayout
    private lateinit var loadText: TextView
    private var loads = 0
    private var loadShownAt = 0L
    private val loadShow = Runnable {
        if (loads > 0) { loadShownAt = android.os.SystemClock.uptimeMillis(); loadOverlay.alpha = 0f; loadOverlay.visibility = View.VISIBLE; loadOverlay.animate().alpha(1f).setDuration(160).start()
            loadOverlay.getChildAt(0)?.let { c -> c.scaleX = .82f; c.scaleY = .82f; c.animate().scaleX(1f).scaleY(1f).setDuration(520).setInterpolator(Spring(2f, 6f)).start() } }
    }

    /** Layar loading: kartu di tengah dengan lingkaran berputar + keterangan aksi. Menahan sentuhan selama aksi berjalan. */
    private fun loadingOverlay(): FrameLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(28), dp(22), dp(28), dp(20)); elevation = dp(8).toFloat()
            background = surface(18, withAlpha(PURPLE, 0xAA)); tintShadow(this, PURPLE)
        }
        card.addView(SpinnerView(this), LinearLayout.LayoutParams(dp(46), dp(46)))
        loadText = TextView(this).apply {
            textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, dp(12), 0, 0); maxWidth = dp(230)
        }
        card.addView(loadText, LinearLayout.LayoutParams(-2, -2))
        return FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#99000000")); visibility = View.GONE; isClickable = true; isFocusable = true
            addView(card, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        }
    }

    /** Mulai loading. Layar baru muncul bila aksi lebih lama dari 0,2 detik supaya aksi cepat tidak berkedip. */
    private fun loadStart(label: String) {
        loads++
        loadText.text = label
        if (loadOverlay.visibility == View.VISIBLE) { loadOverlay.animate().cancel(); loadOverlay.alpha = 1f }
        else if (loads == 1) { loadOverlay.removeCallbacks(loadShow); loadOverlay.postDelayed(loadShow, 200) }
    }

    /** Selesai loading. Bila layar sudah tampil, ia tetap terlihat minimal 0,5 detik lalu memudar. */
    private fun loadEnd() {
        if (loads > 0) loads--
        if (loads > 0) return
        loadOverlay.removeCallbacks(loadShow)
        if (loadOverlay.visibility != View.VISIBLE) return
        val wait = (500L - (android.os.SystemClock.uptimeMillis() - loadShownAt)).coerceAtLeast(0L)
        loadOverlay.postDelayed({
            if (loads == 0) loadOverlay.animate().alpha(0f).setDuration(160).withEndAction { if (loads == 0) loadOverlay.visibility = View.GONE }.start()
        }, wait)
    }

    /** Jalankan aksi di thread latar dengan layar loading. Aksi lain diabaikan selama satu aksi berjalan. */
    private fun work(label: String, block: () -> Unit) {
        if (loads > 0) return
        loadStart(label)
        Thread {
            try { block() }
            catch (e: Throwable) { log(listOf(StatsEngine.line("✘ ${tr("gagal", "failed")}: ${e.message ?: e.javaClass.simpleName}")), true) }
            finally { runOnUiThread { loadEnd() } }
        }.start()
    }

    private fun burstAt(v: View) { val a = IntArray(2); val b = IntArray(2); v.getLocationInWindow(a); fx.getLocationInWindow(b); fx.burst(a[0] - b[0] + v.width / 2f, a[1] - b[1] + v.height / 2f) }

    private fun header(): View {
        val outer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(5)) }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.logo_rounded); clipToOutline = true; elevation = dp(6).toFloat()
            outlineProvider = object : ViewOutlineProvider() { override fun getOutline(v: View, o: Outline) = o.setRoundRect(0, 0, v.width, v.height, dp(12).toFloat()) }
        }
        val halo = View(this).apply { background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(BLUE, PURPLE)).apply { cornerRadius = dp(18).toFloat() }; alpha = 0.4f }
        val logoBox = FrameLayout(this)
        logoBox.addView(halo, FrameLayout.LayoutParams(dp(42), dp(42), Gravity.CENTER))
        logoBox.addView(logo, FrameLayout.LayoutParams(dp(34), dp(34), Gravity.CENTER))
        Fx.pulse(halo, 0.94f, 1.15f, 1700)
        row.addView(logoBox, LinearLayout.LayoutParams(dp(42), dp(42)))
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "1.0" }
        val tx = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        val l1 = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        l1.addView(GlowText(this).apply { text = "AuroraToolsTS"; textSize = 16f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD })
        l1.addView(TextView(this).apply { text = "v$ver"; textSize = 9f; typeface = Typeface.DEFAULT_BOLD; setTextColor(SOFT); setPadding(dp(6), dp(1), dp(6), dp(1)); background = round(withAlpha(BLUE, 0x33), 8, withAlpha(BLUE, 0x88)) },
            LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(6) })
        tx.addView(l1)
        val l2 = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        pill = TextView(this).apply { textSize = 9f; typeface = Typeface.DEFAULT_BOLD; setPadding(dp(7), dp(1), dp(7), dp(1)) }
        status = TextView(this).apply { textSize = 10f }
        l2.addView(pill, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) }); l2.addView(status)
        tx.addView(l2, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(3) })
        row.addView(tx, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(glowButton("⚙", 9, 4, 13f) { go(Node(S.t("settings"), "info", Kind.INFO)) })
        outer.addView(row)

        // Dua aksi utama: HUBUNGKAN (dekode & baca save) dan SIMPAN & KIRIM (enkode, tulis, luncurkan game).
        val acts = LinearLayout(this)
        val (c1, b1, i1) = actionCard("🚀", tr("Mulai Edit Game", "Start Editing"), Color.parseColor("#38D0F5")) { doConnect() }
        val (c2, b2, i2) = actionCard("💾", tr("Simpan dan luncurkan", "Save and launch"), Color.parseColor("#C86BFF")) { doSaveLaunch() }
        btnConnect = b1; infoConnect = i1; btnSave = b2; infoSave = i2
        acts.addView(c1, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(8) })
        acts.addView(c2, LinearLayout.LayoutParams(0, -2, 1f))
        outer.addView(acts, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        refreshStatus(); refreshHeader(); return outer
    }

    /** Kartu aksi ringkas: judul, keterangan satu baris, tombol. @return kartu, tombol, keterangan. */
    private fun actionCard(icon: String, title: String, accent: Int, onClick: () -> Unit): Triple<View, TextView, TextView> {
        val btn = FxButton(this, 12).apply {
            typeface = Typeface.DEFAULT_BOLD; textSize = 11.5f; gravity = Gravity.CENTER; maxLines = 1; letterSpacing = 0.03f
            setPadding(dp(6), dp(5), dp(6), dp(5)); setTextColor(Color.WHITE)
            background = round(withAlpha(accent, 0x33), 12, accent, 1.5f)
            setOnClickListener { burstAt(it); press(it, onClick) }
        }
        val info = TextView(this).apply { textSize = 9f; setTextColor(SOFT); maxLines = 1 }
        val card = FxCard(this, 16).apply {
            orientation = LinearLayout.VERTICAL; elevation = dp(5).toFloat(); setPadding(dp(9), dp(6), dp(9), dp(8))
            background = surface(14, withAlpha(accent, 0x88)); tintShadow(this, accent)
            addView(TextView(context).apply { text = "$icon  $title"; textSize = 11f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); maxLines = 1 })
            addView(info, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(1) })
            addView(btn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        }
        return Triple(card, btn, info)
    }

    /** Segarkan penanda ONLINE/OFFLINE dan keterangan tombol sesuai sesi edit. */
    private fun refreshHeader() {
        if (!::pill.isInitialized) return
        val on = Session.connected
        val c = Color.parseColor(if (on) "#6DFFB0" else "#FF7A9A")
        pill.text = if (on) "● ONLINE" else "● OFFLINE"; pill.setTextColor(c); pill.background = round(withAlpha(c, 0x22), 9, withAlpha(c, 0x88))
        btnConnect.text = tr(if (on) "HUBUNGKAN ULANG" else "HUBUNGKAN", if (on) "RECONNECT" else "CONNECT")
        infoConnect.text = if (on) (if (Session.cityId.isNotEmpty()) tr("Kota ID ${Session.cityId}", "City ID ${Session.cityId}") else tr("Save terbaca & siap diedit", "Save loaded & ready")) else tr("Dekode & baca data save", "Decode & read save data")
        btnSave.text = tr("SIMPAN & KIRIM", "SAVE & SEND")
        btnSave.alpha = if (on) 1f else 0.6f
        infoSave.text = when { !on -> tr("Hubungkan dulu", "Connect first"); Session.dirty -> tr("${Session.edits} perubahan belum disimpan", "${Session.edits} unsaved change(s)"); else -> tr("Belum ada perubahan", "No changes yet") }
        infoSave.setTextColor(if (on && Session.dirty) Color.parseColor("#FFD166") else SOFT)
    }

    override fun onResume() {
        super.onResume()
        Perf.lock60(this)
        if (::status.isInitialized) {
            refreshStatus()
            refreshHeader()
            if (Session.connected && StatsEngine.checkDiskSync(this)) {
                infoConnect.text = tr("Save di disk diperbarui — ketuk HUBUNGKAN ULANG", "Save changed on disk — tap RECONNECT")
                infoConnect.setTextColor(Color.parseColor("#FFD166"))
            }
        }
    }
    private fun refreshStatus() {
        val ok = GameBridge.isInstalled(this)
        status.text = S.t(if (ok) "found" else "missing").removePrefix("● ")
        status.setTextColor(if (ok) Color.parseColor("#6DFFB0") else Color.parseColor("#FF7A9A"))
    }

    private fun glow(radius: Int = 18, fill: Boolean = true) = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
        if (fill) intArrayOf(Color.parseColor("#26337A"), Color.parseColor("#3A1F6E")) else intArrayOf(BLUE, PURPLE)).apply {
        cornerRadius = dp(radius).toFloat(); if (fill) setStroke(dp(1), Color.parseColor("#7A6BFF"))
    }

    private fun press(v: View, then: () -> Unit) {
        v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        // tekan: gepeng sedikit (squash); lepas: memantul pegas (stretch) lalu menetap
        v.animate().scaleX(.95f).scaleY(.92f).setStartDelay(0).setDuration(60).withEndAction {
            v.animate().scaleX(1f).scaleY(1f).setDuration(480).setInterpolator(Spring(2.2f, 6f)); then()
        }
    }

    /** Lapisan kedalaman: kilau cahaya di atas + bayangan di bawah (memberi kesan cembung), plus riak sentuh bila [ripple]. */
    private fun depth(base: GradientDrawable, rad: Float, ripple: Boolean = true): android.graphics.drawable.Drawable {
        val light = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x2EFFFFFF, 0x00FFFFFF)).apply { cornerRadius = rad }
        val shade = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x00000000, 0x38000000)).apply { cornerRadius = rad }
        val layers = android.graphics.drawable.LayerDrawable(arrayOf(base, light, shade))
        if (!ripple) return layers
        val mask = GradientDrawable().apply { setColor(Color.BLACK); cornerRadius = rad }
        return android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(0x44FFFFFF), layers, mask)
    }

    /** Permukaan kartu "kaca" bergradasi dengan tepi berwarna. */
    private fun surface(r: Int, stroke: Int, ripple: Boolean = false, fill: Int = Color.parseColor("#1B1F52")): android.graphics.drawable.Drawable {
        val rad = dp(r).toFloat()
        return depth(GradientDrawable().apply { setColor(fill); cornerRadius = rad; if (stroke != 0) setStroke(dp(1), stroke) }, rad, ripple)
    }

    /** Bayangan berwarna mengikuti warna aksen (Android 9+), seperti cahaya yang jatuh ke bawah kartu. */
    private fun tintShadow(v: View, c: Int) { if (android.os.Build.VERSION.SDK_INT >= 28) { v.outlineSpotShadowColor = c; v.outlineAmbientShadowColor = c } }

    private fun glowButton(t: String, h: Int = 14, v: Int = 10, ts: Float = 13f, onClick: () -> Unit) = FxButton(this, 14).apply {
        text = t; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; textSize = ts
        setPadding(dp(h), dp(v), dp(h), dp(v)); background = depth(glow(14, false), dp(14).toFloat()); elevation = dp(4).toFloat(); tintShadow(this, PURPLE)
        setOnClickListener { burstAt(it); press(it, onClick) }
    }

    private fun bannerView(name: String): View {
        val id = resources.getIdentifier("banner_$name", "drawable", packageName)
        val frame = FrameLayout(this).apply {
            clipToOutline = true; elevation = dp(10).toFloat()
            outlineProvider = object : ViewOutlineProvider() { override fun getOutline(v: View, o: Outline) = o.setRoundRect(0, 0, v.width, v.height, dp(20).toFloat()) }
        }
        val img = ImageView(this).apply { setImageResource(id); scaleType = ImageView.ScaleType.CENTER_CROP }
        frame.addView(img, FrameLayout.LayoutParams(-1, -1))
        val shine = View(this).apply { background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0x00FFFFFF, 0x50FFFFFF, 0x00FFFFFF)); rotation = 18f }
        frame.addView(shine, FrameLayout.LayoutParams(dp(70), dp(300), Gravity.CENTER_VERTICAL))
        Fx.kenBurns(img); Fx.sweep(shine, resources.displayMetrics.widthPixels)
        return frame
    }

    private fun go(n: Node) { stack.add(n); show(n, false) }

    private fun show(node: Node, push: Boolean = true) {
        if (push) stack.add(node)
        content.removeAllViews()
        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(16)) }
        if (stack.size > 1) list.addView(TextView(this).apply {
            text = "‹  ${node.title}"; setTextColor(Color.WHITE); textSize = 18f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, 0, 0, dp(8))
            setOnClickListener { onBackPressed() }
        })
        val upd = update
        if (upd != null && stack.size == 1) list.addView(card("${S.t("update")} • v${upd.name}", "⬇") {
            startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(upd.url)))
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        if (stack.size > 1 && node.kind != Kind.EDITOR) list.addView(bannerView(node.banner), LinearLayout.LayoutParams(-1, dp(if (wide) 90 else 68)).apply { bottomMargin = dp(8) })
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun fill(q: String, anim: Boolean = false) {
            box.removeAllViews()
            val cards = when {
                stack.size == 1 && node === Menus.root -> tabCards()
                node.kind == Kind.INFO -> infoCards()
                node.kind == Kind.HELP -> helpCards()
                node.kind == Kind.STATS -> statsCards()
                node.kind == Kind.BACKUP -> backupCards()
                node.kind == Kind.EDITOR -> editorCards(node.key)
                q.isBlank() -> node.children.map { c -> card(c.title, if (c.kind == Kind.MENU) "›" else "⚡") { open(c) } }
                else -> Menus.flatten(node).filter { it.first.title.contains(q, true) }.map { (n, path) -> card(n.title, "⚡", path.ifEmpty { null }) { open(n) } }
            }
            if (cards.isEmpty()) box.addView(TextView(this).apply { text = S.t("noResult"); setTextColor(SOFT); gravity = Gravity.CENTER; setPadding(0, dp(24), 0, 0) })
            else if (stack.size == 1 && node === Menus.root && tab in 1..4) cards.forEachIndexed { i, v -> if (anim) Fx.enter(v, i); box.addView(v, LinearLayout.LayoutParams(-1, -2)) }
            else addCards(box, cards, anim)
        }
        if (node.kind == Kind.MENU && node.children.size >= 6) {
            val et = EditText(this).apply {
                hint = S.t("search"); setHintTextColor(Color.parseColor("#8A7FC8")); setTextColor(Color.WHITE); textSize = 14f; isSingleLine = true
                setPadding(dp(16), dp(10), dp(16), dp(10)); background = glow(14)
                addTextChangedListener(object : android.text.TextWatcher {
                    override fun afterTextChanged(e: android.text.Editable?) { fill(e?.toString()?.trim() ?: "") }
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                })
            }
            list.addView(et, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        }
        fill("", true)
        list.addView(box)
        scroll.addView(list); content.addView(scroll)
        console.visibility = if (stack.size == 1 || node.kind == Kind.EDITOR) View.VISIBLE else View.GONE
        val forward = stack.size >= lastDepth; lastDepth = stack.size
        scroll.alpha = 0f; scroll.translationX = dp(if (forward) 36 else -36).toFloat()
        scroll.animate().alpha(1f).translationX(0f).setDuration(280).setInterpolator(android.view.animation.DecelerateInterpolator(1.8f)).start()
    }

    /** HP: 1 kolom. Tablet: 2 kolom. */
    private fun addCards(parent: LinearLayout, cards: List<View>, animate: Boolean = false) {
        var n = 0
        val cols = if (wide) 2 else 1
        cards.chunked(cols).forEach { rowCards ->
            val row = LinearLayout(this)
            for (i in 0 until cols) {
                val real = rowCards.getOrNull(i); val v = real ?: View(this)
                if (animate && real != null) Fx.enter(v, n++)
                row.addView(v, LinearLayout.LayoutParams(0, -2, 1f).apply { if (i < cols - 1) rightMargin = dp(8) })
            }
            parent.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
    }

    private fun card(title: String, trailing: String, sub: String? = null, onClick: () -> Unit) = FxCard(this, 18).apply {
        gravity = Gravity.CENTER_VERTICAL; background = depth(glow(), dp(18).toFloat()); elevation = dp(4).toFloat(); setPadding(dp(12), dp(7), dp(12), dp(7)); Fx.tilt(this)
        val tx = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        tx.addView(TextView(context).apply { text = title; textSize = 13f; setTextColor(Color.WHITE) })
        if (sub != null) tx.addView(TextView(context).apply { text = sub; textSize = 10f; setTextColor(SOFT) })
        addView(tx, LinearLayout.LayoutParams(0, -2, 1f))
        addView(TextView(context).apply { text = trailing; textSize = 16f; setTextColor(SOFT); if (trailing == "›") Fx.nudge(this) else if (trailing == "⚡") Fx.breathe(this, 0.5f, 1f, 1100) })
        setOnClickListener { press(it, onClick) }
    }

    /** Halaman Info & Pengaturan. */
    private fun infoCards(): List<View> {
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "1.0" }
        val e = Env.report(this)
        return listOf(
            card("AuroraToolsTS", "", "${S.t("version")} $ver") {},
            card(S.t("dev"), "", "Powered by AuroraTS") {},
            card(S.t("language"), S.t("langName"), "ID / EN") { S.toggleLang(); rebuild() },
            card(S.t("effects"), S.t(if (S.effects) "on" else "off")) { S.toggleFx(); bg.refresh(); rebuild() },
            card(S.t("game"), if (GameBridge.isInstalled(this)) "✔" else "✖", GameBridge.PACKAGE) {},
            card(S.t("root"), when (Env.rootVerified) { true -> S.t("yes"); false -> S.t("no"); null -> "…" },
                (if (Env.rootVerified == true) e.rootHints.joinToString().ifEmpty { tr("su aktif (uid=0)", "su active (uid=0)") } else S.t("noRootMode") + " • " + tr("ketuk untuk periksa ulang", "tap to re-check")) + (if (GameFiles.dataDir(this) != null) " • ${S.t("directOk")}" else "")) {
                Thread { Env.verifyRoot(); runOnUiThread { if (!isFinishing && stack.isNotEmpty()) show(stack.last(), false) } }.start()
            },
            card(S.t("virt"), if (e.insideVirtual || Env.rootVerified == true) "✔" else "✖",
                (when {
                    e.insideVirtual && Env.dataReachable(this) -> tr("Terdeteksi: data Township terjangkau langsung", "Detected: Township data reachable directly")
                    e.insideVirtual -> S.t("inVirt")
                    Env.rootVerified == true -> tr("Bukan ruang virtual, tetapi root aktif — fitur tetap jalan", "Not a virtual space, but root is active — features still work")
                    else -> "${S.t("noVirt")} • ${e.virtualApps.joinToString().ifEmpty { S.t("none") }}"
                }) + "\n" + Env.buildInfo()) {},
            card(S.t("help"), "›") { go(Node(S.t("help"), "info", Kind.HELP)) },
            card(S.t("license"), "✔", "${S.t("lifetime")} • ${S.t("bound")}") {},
            card(S.t("logout"), "⏻") { S.setActivated(false); startActivity(android.content.Intent(this, LoginActivity::class.java)); finish() },
            card("ℹ", "", S.t("mode")) {}
        )
    }

    // ---------- Bar tab ----------
    private var tab = 0
    private val tabViews = ArrayList<LinearLayout>()

    private fun tabBar(): View {
        tabViews.clear()
        val items = listOf("✔" to tr("STATISTIK", "STATS"), "🔓" to tr("MENU", "MENU"), "🛠" to tr("ALAT", "TOOLS"), "🏅" to "PREMIUM", "💎" to "VIP")
        val bar = LinearLayout(this).apply { elevation = dp(3).toFloat(); setPadding(dp(3), dp(3), dp(3), dp(3)); background = surface(16, Color.parseColor("#3B3F8F")) }
        items.forEachIndexed { i, (ic, lb) ->
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, dp(3), 0, dp(3))
                addView(TextView(context).apply { text = ic; textSize = 13f; gravity = Gravity.CENTER; setTextColor(Color.WHITE) })
                addView(TextView(context).apply { text = lb; textSize = 8.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; maxLines = 1; setPadding(0, dp(1), 0, dp(2)) })
                addView(View(context).apply { background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(BLUE, PURPLE)).apply { cornerRadius = dp(2).toFloat() } }, LinearLayout.LayoutParams(dp(24), dp(2)))
                setOnClickListener { it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); selectTab(i) }
            }
            tabViews.add(cell); bar.addView(cell, LinearLayout.LayoutParams(0, -2, 1f))
        }
        updateTabs(); return bar
    }

    private fun updateTabs() = tabViews.forEachIndexed { i, cell ->
        val on = i == tab
        cell.background = if (on) round(withAlpha(BLUE, 0x33), 14) else null
        cell.getChildAt(0).alpha = if (on) 1f else 0.55f
        (cell.getChildAt(1) as TextView).setTextColor(if (on) Color.WHITE else SOFT)
        cell.getChildAt(2).visibility = if (on) View.VISIBLE else View.INVISIBLE
    }

    private fun selectTab(i: Int) {
        if (i == tab && stack.size == 1) return
        tab = i; updateTabs()
        tabViews.getOrNull(i)?.getChildAt(0)?.let { ic ->
            ic.scaleX = .55f; ic.scaleY = .55f; ic.translationY = dp(4).toFloat()
            ic.animate().scaleX(1f).scaleY(1f).translationY(0f).setDuration(560).setInterpolator(Spring(2f, 5.5f)).start()
        }
        stack.clear(); stack.add(Menus.root); lastDepth = 1
        show(Menus.root, false)
    }

    /** Isi halaman utama sesuai tab: Statistik, Alat (backup & data kota), sisanya belum tersedia. */
    private fun tabCards(): List<View> = when (tab) {
        0 -> statsCards()
        1 -> bukaCards()
        2 -> toolCards()
        3 -> premiumCards()
        4 -> vipCards()
        else -> listOf(card(tr("Segera hadir", "Coming soon"), "🔒", tr("Tab ini belum punya fitur di versi ini.", "This tab has no features in this version yet.")) {})
    }

    // ---------- Tab ALAT ----------
    private fun toolItems() = listOf(
        Unlock("warehouse", tr("GUDANG", "WAREHOUSE"), tr("Tambah kapasitas gudang", "Add warehouse capacity"), "🏠", "#FFB347", "#F76707"),
        Unlock("golden", tr("EDITOR GOLDEN PASS", "GOLDEN PASS EDITOR"), tr("Tidak tersedia di versi ini", "Not available in this version"), "🎟", "#FFE066", "#E0A800"),
        Unlock("academy", tr("AKADEMI", "ACADEMY"), tr("Atur level pabrik satu per satu", "Set each factory level"), "🎓", "#38D0F5", "#0284C7"),
        Unlock("zoo", tr("KARTU ZOO", "ZOO CARDS"), tr("Selesaikan kandang satu per satu", "Complete paddocks one by one"), "🐾", "#FF8FB1", "#E11D68"),
        Unlock("perks", tr("KEUNTUNGAN", "PERKS"), tr("Pilih keuntungan satu per satu", "Pick perks one by one"), "⭐", "#3CC7BE", "#0F766E"),
        Unlock("market", tr("PASAR", "MARKET"), tr("Pilih jumlah slot pasar", "Choose market slot count"), "🏪", "#3EE8B5", "#0E9F6E"),
        Unlock("coupons", tr("JUMLAH", "AMOUNTS"), tr("Sesuaikan jumlah kupon", "Adjust coupon amounts"), "∞", "#FFB347", "#E8590C"),
        Unlock("train", tr("KERETA", "TRAINS"), tr("Edit gerbong & pesanan", "Edit wagons & orders"), "🚆", "#8C9BFF", "#4C5FE0"),
        Unlock("xml", tr("ENKODE / DEKODE", "ENCODE / DECODE"), tr("Alat standalone untuk XML", "Standalone XML tool"), "⌨", "#38D0F5", "#0891B2"),
        Unlock("backup", "BACKUP", tr("Cadangkan & pulihkan data kota", "Back up & restore city data"), "💾", "#B58CFF", "#6D28D9")
    )

    private fun toolCards(): List<View> = listOf(cardGrid(toolItems()) { tool(it) })

    private fun tool(u: Unlock) {
        when (u.key) {
            "coupons", "academy", "zoo" -> go(Node(u.title, "info", Kind.EDITOR, key = u.key))
            "backup" -> go(Node(u.title, "info", Kind.BACKUP))
            "xml" -> AlertDialog.Builder(this).setTitle(u.title)
                .setItems(arrayOf(tr("Dekode save → XML terbaca", "Decode save → readable XML"), tr("Enkode XML → format game", "Encode XML → game format"))) { _, w ->
                    work(if (w == 0) tr("Mendekode save…", "Decoding save…") else tr("Mengenkode XML…", "Encoding XML…")) { log(if (w == 0) StatsEngine.decodeToFile(this) else StatsEngine.encodeFromFile(this), true) }
                }.setNegativeButton(S.t("cancel"), null).show()
            "golden" -> work("${u.title}…") { log(StatsEngine.unlockSeason(this@MainActivity), true) }
            "warehouse" -> {
                val et = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText("100000"); hint = "1000 – 2000000" }
                AlertDialog.Builder(this).setTitle(u.title)
                    .setMessage(tr("Masukkan kapasitas gudang baru:", "Enter new warehouse capacity:"))
                    .setView(et)
                    .setPositiveButton(S.t("apply")) { _, _ ->
                        val v = et.text.toString().trim().toLongOrNull() ?: 100000L
                        work("${u.title}…") { log(StatsEngine.setWarehouse(this@MainActivity, v), true) }
                    }
                    .setNegativeButton(S.t("cancel"), null).show()
            }
            "market" -> {
                val et = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText("200"); hint = "10 – 1000" }
                AlertDialog.Builder(this).setTitle(u.title)
                    .setMessage(tr("Masukkan jumlah slot pasar (+ pedagang aktif):", "Enter market slot count (+ dealer hired):"))
                    .setView(et)
                    .setPositiveButton(S.t("apply")) { _, _ ->
                        val v = et.text.toString().trim().toIntOrNull() ?: 200
                        work("${u.title}…") { log(StatsEngine.setMarket(this@MainActivity, v), true) }
                    }
                    .setNegativeButton(S.t("cancel"), null).show()
            }
            "perks" -> work("${u.title}…") { log(StatsEngine.unlockPerks(this@MainActivity), true) }
            "train" -> work("${u.title}…") { log(StatsEngine.speedupTrains(this@MainActivity), true) }
            else -> work("${u.title}…") { log(listOf(StatsEngine.line("${u.title}: ${tr("fitur disiapkan", "feature ready")}"))) }
        }
    }

    private fun prettify(id: String) = id.replace('_', ' ').replaceFirstChar { it.uppercase() }

    /** Baris editor: ikon + nama, kolom isian, tombol Terapkan. */
    private fun editRow(label: String, icon: String, key: String, value: String, hint: String, onApply: (String) -> Unit): View {
        val (hi, lo) = tint(key)
        return FxCard(this, 18).apply {
            gravity = Gravity.CENTER_VERTICAL; elevation = dp(3).toFloat(); setPadding(dp(8), dp(6), dp(8), dp(6))
            background = surface(16, withAlpha(hi, 0x55)); tintShadow(this, hi)
            val side = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
            side.addView(TextView(context).apply {
                text = icon; textSize = 14f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(hi, lo)).apply { cornerRadius = dp(14).toFloat() }
            }, LinearLayout.LayoutParams(dp(30), dp(30)))
            side.addView(TextView(context).apply { text = label; textSize = 8.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(Color.parseColor("#C6CCFF")); maxLines = 2; setPadding(0, dp(3), 0, 0) }, LinearLayout.LayoutParams(-1, -2))
            addView(side, LinearLayout.LayoutParams(dp(58), -2))
            val et = EditText(context).apply {
                inputType = InputType.TYPE_CLASS_NUMBER; setText(value); this.hint = hint
                setHintTextColor(withAlpha(Color.WHITE, 0x55)); setTextColor(Color.WHITE); textSize = 14f; typeface = Typeface.DEFAULT_BOLD; isSingleLine = true
                setPadding(dp(10), dp(4), dp(10), dp(4)); background = round(withAlpha(hi, 0x26), 11, withAlpha(hi, 0x99), 1.5f)
            }
            addView(et, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(6); rightMargin = dp(6) })
            addView(glowButton(S.t("apply"), 9, 6, 11f) { onApply(et.text.toString()) })
        }
    }

    /** Baris aksi tanpa isian (mis. kandang zoo). */
    private fun actionRow(title: String, sub: String, onTap: () -> Unit): View {
        val (hi, _) = tint("cards")
        return FxCard(this, 18).apply {
            gravity = Gravity.CENTER_VERTICAL; elevation = dp(5).toFloat(); setPadding(dp(14), dp(12), dp(12), dp(12))
            background = surface(18, withAlpha(hi, 0x55)); tintShadow(this, hi)
            val tx = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
            tx.addView(TextView(context).apply { text = title; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE) })
            tx.addView(TextView(context).apply { text = sub; textSize = 11.5f; setTextColor(SOFT) })
            addView(tx, LinearLayout.LayoutParams(0, -2, 1f))
            addView(glowButton(S.t("apply"), 9, 6, 11f) { onTap() })
        }
    }

    private fun editorCards(key: String): List<View> {
        val holder = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun put(rows: List<View>) = runOnUiThread {
            holder.removeAllViews()
            if (rows.isEmpty()) holder.addView(TextView(this).apply { text = S.t("noResult"); setTextColor(SOFT); gravity = Gravity.CENTER; setPadding(0, dp(24), 0, 0) })
            rows.forEach { holder.addView(it, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }) }
        }
        val desc = when (key) {
            "coupons" -> tr("Ubah jumlah kupon, lalu tekan Terapkan pada barisnya.", "Edit a coupon amount, then tap Apply on its row.")
            "academy" -> tr("Level pabrik, kereta, dan pulau. Cadangan dibuat otomatis; bila game menolak nilainya, pulihkan dari Backup.", "Factory, train and island levels. A backup is made first; restore it if the game rejects a value.")
            else -> tr("Selesaikan semua anggota kandang, atau satu per satu.", "Complete every paddock member, or one at a time.")
        }
        loadStart(tr("Memuat data…", "Loading data…"))
        Thread {
          try {
            when (key) {
                "coupons", "academy" -> {
                    val coupons = key == "coupons"
                    val (items, lg) = if (coupons) StatsEngine.listElems(this, "coupons", listOf("coupon")) else StatsEngine.listElems(this, "Upgrade", listOf("Factory", "Train", "Island"))
                    log(lg)
                    val attr = if (coupons) "count" else "level"
                    put(items.filter { it.attrs.containsKey(attr) }.map { e ->
                        editRow(prettify(e.id), if (coupons) "🎟" else when (e.name) { "Train" -> "🚆"; "Island" -> "🏝"; else -> "🏭" },
                            if (coupons) "tcash" else "level", e.attrs[attr] ?: "", if (coupons) "0 – 2147483647" else "1 – 200") { v ->
                            val n = v.trim().toLongOrNull()
                            if (n == null) log(listOf(StatsEngine.line("${e.id}: nilai tidak valid")))
                            else {
                                val nn = if (coupons) n.coerceIn(0L, 2147483647L) else n.coerceIn(1L, 200L)
                                work(tr("Menyimpan perubahan…", "Saving changes…")) { log(StatsEngine.setElem(this@MainActivity, if (coupons) "coupons" else "Upgrade", e.name, e.id, attr, nn.toString(), !coupons), true) }
                            }
                        }
                    })
                }
                "zoo" -> {
                    val (list, lg) = StatsEngine.zooList(this); log(lg)
                    fun done(only: String?) {
                        work(tr("Menyelesaikan kandang…", "Completing paddocks…")) {
                            log(StatsEngine.zooComplete(this@MainActivity, only), true)
                            runOnUiThread { if (stack.isNotEmpty() && stack.last().key == "zoo") show(stack.last(), false) }
                        }
                    }
                    val rows = ArrayList<View>()
                    if (list.isNotEmpty()) rows.add(actionRow(tr("Semua kandang", "All paddocks"), "${list.count { it.done >= it.total }}/${list.size} ${tr("selesai", "done")}") { done(null) })
                    list.forEach { p -> rows.add(actionRow(prettify(p.type.removePrefix("paddock_")), "${p.done}/${p.total} ${tr("anggota", "members")}") { done(p.type) }) }
                    put(rows)
                }
            }
          } catch (e: Throwable) { log(listOf(StatsEngine.line("✘ ${tr("gagal", "failed")}: ${e.message ?: e.javaClass.simpleName}"))) }
          finally { runOnUiThread { loadEnd() } }
        }.start()
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(4), dp(2), dp(4), dp(8))
            addView(TextView(context).apply { text = stack.lastOrNull()?.title ?: ""; textSize = 20f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE) })
            addView(TextView(context).apply { text = desc; textSize = 12f; setTextColor(SOFT); setPadding(0, dp(2), 0, 0) })
        }
        return listOf(head, holder)
    }

    // ---------- Tab PREMIUM ----------
    private fun premiumItems() = listOf(
        Unlock("regata", tr("TUGAS REGATA", "REGATTA TASKS"), tr("Tidak tersedia di versi ini", "Not available in this version"), "🚢", "#FF4D9A", "#C2185B"),
        Unlock("sendcards", tr("KIRIM KARTU", "SEND CARDS"), tr("Kirim kartu ke teman dan anggota klan", "Send cards to friends and clan members"), "🎁", "#38D0F5", "#0284C7"),
        Unlock("clone", tr("KLONING KOTA", "CITY CLONE"), tr("Tidak tersedia di versi ini", "Not available in this version"), "🗂", "#8C9BFF", "#4C5FE0"),
        Unlock("clone3", tr("KLON KOTA V3", "CITY CLONE V3"), tr("Tidak tersedia di versi ini", "Not available in this version"), "🗂", "#8C9BFF", "#4C5FE0"),
        Unlock("events", tr("EVENT TERBATAS WAKTU", "LIMITED-TIME EVENTS"), tr("Taman Ajaib & event terbatas waktu", "Magic Garden & limited-time events"), "⏳", "#FFB347", "#F76707"),
        Unlock("tutorial", tr("PERBAIKI BUG TUTORIAL", "FIX TUTORIAL BUG"), tr("Perbaiki tutorial yang macet", "Fix stuck tutorials"), "🐞", "#3CC7BE", "#0F766E")
    )

    private fun premiumCards(): List<View> = listOf(cardGrid(premiumItems()) { premium(it) })

    private fun premium(u: Unlock) {
        when (u.key) {
            "tutorial" -> work("${u.title}…") { log(StatsEngine.fixTutorials(this), true) }
            "events" -> work("${u.title}…") { log(StatsEngine.boostEvents(this), true) }
            "sendcards" -> work("${u.title}…") { log(StatsEngine.boostSendCards(this), true) }
            "regata" -> {
                val et = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText("2160"); hint = "0 – 100000" }
                AlertDialog.Builder(this).setTitle(u.title)
                    .setMessage(tr("Masukkan skor regata (tugas diset 16):", "Enter regatta score (tasks set to 16):"))
                    .setView(et)
                    .setPositiveButton(S.t("apply")) { _, _ ->
                        val v = et.text.toString().trim().toIntOrNull() ?: 2160
                        work("${u.title}…") { log(StatsEngine.boostRegatta(this@MainActivity, v), true) }
                    }
                    .setNegativeButton(S.t("cancel"), null).show()
            }
            "clone", "clone3" -> work("${u.title}…") {
                val r = CityBackup.backup(this, "clone-package")
                log(listOf(StatsEngine.line("Kloning: cadangan kota dibuat ✔"), StatsEngine.line(r.message)), r.ok)
            }
            else -> work("${u.title}…") { log(listOf(StatsEngine.line("${u.title}: ${tr("fitur disiapkan", "feature ready")}"))) }
        }
    }

    // ---------- Tab VIP ----------
    private var vipHistory = false

    private fun vipCards(): List<View> {
        val items = listOf(
            Unlock("backup", tr("CADANGAN", "BACKUP"), tr("Simpan data", "Save data"), "☁", "#3EE8B5", "#0E9F6E"),
            Unlock("history", tr("RIWAYAT", "HISTORY"), tr("Jelajahi simpanan", "Browse backups"), "📄", "#FFB347", "#E8590C"),
            Unlock("newcity", tr("KOTA BARU", "NEW CITY"), tr("Akun baru level 1", "New account, level 1"), "🔨", "#B58CFF", "#6D28D9")
        )
        val row = LinearLayout(this).apply { setPadding(0, 0, 0, dp(12)) }
        items.forEachIndexed { i, u -> row.addView(unlockCard(u) { vip(u) }, LinearLayout.LayoutParams(0, -2, 1f).apply { if (i < 2) rightMargin = dp(8) }) }
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val list = if (vipHistory) CityBackup.list(this) else emptyList()
        if (!vipHistory || list.isEmpty()) {
            panel.apply {
                gravity = Gravity.CENTER; minimumHeight = dp(150); setPadding(dp(16), dp(20), dp(16), dp(20))
                background = surface(20, Color.parseColor("#3B3F8F"))
                addView(TextView(context).apply { text = "📁"; textSize = 38f; gravity = Gravity.CENTER })
                addView(TextView(context).apply {
                    text = if (vipHistory) tr("Belum ada cadangan", "No backups yet") else tr("Pilih RIWAYAT untuk menjelajahi cadangan", "Select HISTORY to browse backups")
                    textSize = 14f; gravity = Gravity.CENTER; setTextColor(SOFT); setPadding(0, dp(8), 0, 0)
                })
            }
        } else {
            val fmt = java.text.SimpleDateFormat("dd MMM yyyy  HH:mm:ss", java.util.Locale.forLanguageTag(S.lang))
            list.forEach { inf ->
                panel.addView(card(fmt.format(java.util.Date(inf.time)), "›", "${labelText(inf.label)} • ${CityBackup.size(inf.file.length())} • ${inf.ext.uppercase()}") { backupActions(inf) },
                    LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
            }
        }
        return listOf(row, panel)
    }

    private fun vip(u: Unlock) {
        when (u.key) {
            "backup" -> askBackup()
            "history" -> { vipHistory = !vipHistory; show(stack.last(), false) }
            "newcity" -> {
                AlertDialog.Builder(this).setTitle(tr("Kota Baru Level 1?", "New City Level 1?"))
                    .setMessage(tr("Data kota saat ini akan direset ke level 1 dengan T-Cash 500 dan Koin 2000. Cadangan pengaman dibuat otomatis sebelum reset.",
                        "Current city will be reset to level 1 with 500 T-Cash and 2000 Coins. A safety backup is created first."))
                    .setPositiveButton(tr("Reset Kota", "Reset City")) { _, _ ->
                        work("${u.title}…") { log(StatsEngine.resetNewCity(this@MainActivity), true) }
                    }
                    .setNegativeButton(S.t("cancel"), null).show()
            }
            else -> work("${u.title}…") { log(listOf(StatsEngine.line("${u.title}: ${tr("fitur disiapkan", "feature ready")}"))) }
        }
    }

    // ---------- Tab MENU ----------
    private class Unlock(val key: String, val title: String, val sub: String, val icon: String, val hi: String, val lo: String)

    private fun unlockItems() = listOf(
        Unlock("avatar", "AVATAR", tr("Buka semua avatar", "Unlock all avatars"), "🙂", "#FFB347", "#F76707"),
        Unlock("decor", tr("DEKORASI", "DECOR"), tr("Buka semua dekorasi", "Unlock all decorations"), "🖌", "#3EE8B5", "#0E9F6E"),
        Unlock("land", tr("TANAH", "LAND"), tr("Buka perluasan kota", "Unlock city expansions"), "🗺", "#3CC7BE", "#0F766E"),
        Unlock("museum", "MUSEUM", tr("Selesaikan semua di museum", "Complete the whole museum"), "🏛", "#38D0F5", "#0284C7"),
        Unlock("allcards", tr("SEMUA KARTU", "ALL CARDS"), tr("Tambahkan kartu dari setiap jenis", "Add every kind of card"), "🃏", "#FF4D9A", "#C2185B"),
        Unlock("mycards", tr("KARTU SAYA", "MY CARDS"), tr("Tingkatkan kartu yang Anda punya", "Upgrade the cards you own"), "🎴", "#FF8FB1", "#E11D68"),
        Unlock("season", tr("TIKET MUSIM", "SEASON TICKET"), tr("Tidak tersedia di versi ini", "Not available in this version"), "⭐", "#8C9BFF", "#4C5FE0"),
        Unlock("skin", "SKIN", tr("Buka semua skin kendaraan", "Unlock all vehicle skins"), "🎨", "#FF8A8A", "#E0405F"),
        Unlock("sticker", tr("STIKER", "STICKERS"), tr("Buka semua stiker", "Unlock all stickers"), "📝", "#FFE066", "#E0A800"),
        Unlock("profile", tr("PROFIL", "PROFILE"), tr("Buka item profil", "Unlock profile items"), "👤", "#FF4FA3", "#C4126B"),
        Unlock("achv", tr("PENCAPAIAN", "ACHIEVEMENTS"), tr("Buka semua pencapaian", "Unlock all achievements"), "🏆", "#B58CFF", "#6D28D9")
    )

    private fun unlockCard(u: Unlock, tap: () -> Unit): View {
        val hi = Color.parseColor(u.hi); val lo = Color.parseColor(u.lo)
        return FxCard(this, 18).apply {
            orientation = LinearLayout.VERTICAL; elevation = dp(3).toFloat(); setPadding(dp(8), dp(8), dp(8), dp(8)); minimumHeight = dp(76)
            background = surface(18, withAlpha(hi, 0x66), true); tintShadow(this, hi); Fx.tilt(this)
            val top = LinearLayout(context).apply { gravity = Gravity.TOP }
            top.addView(TextView(context).apply {
                text = u.icon; textSize = 15f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(hi, lo)).apply { cornerRadius = dp(14).toFloat() }
            }, LinearLayout.LayoutParams(dp(32), dp(32)))
            top.addView(View(context), LinearLayout.LayoutParams(0, 1, 1f))
            top.addView(TextView(context).apply { text = "›"; textSize = 20f; setTextColor(hi) })
            addView(top)
            addView(TextView(context).apply { text = u.title; textSize = 12.5f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); setPadding(0, dp(4), 0, 0); maxLines = 1 })
            addView(TextView(context).apply { text = u.sub; textSize = 9.5f; setTextColor(SOFT); maxLines = 2; setPadding(0, dp(1), 0, 0) })
            setOnClickListener { press(it) { tap() } }
        }
    }

    private fun cardGrid(items: List<Unlock>, tap: (Unlock) -> Unit): View {
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        items.chunked(2).forEach { pair ->
            val row = LinearLayout(this)
            for (i in 0..1) {
                val u = pair.getOrNull(i)
                row.addView(if (u != null) unlockCard(u) { tap(u) } else View(this), LinearLayout.LayoutParams(0, -2, 1f).apply { if (i == 0) rightMargin = dp(8) })
            }
            grid.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
        return grid
    }

    private fun bukaCards(): List<View> = listOf(cardGrid(unlockItems()) { unlock(it) })

    private fun unlock(u: Unlock) {
        work("${u.title}…") {
            val lines = when (u.key) {
                "avatar" -> StatsEngine.unlockFlags(this, "Avatar", "Unlocked_ava")
                "decor" -> StatsEngine.unlockDecor(this)
                "land" -> StatsEngine.unlockLand(this)
                "museum" -> StatsEngine.unlockMuseum(this)
                "allcards" -> StatsEngine.unlockAllCards(this)
                "mycards" -> StatsEngine.upgradeMyCards(this)
                "season" -> StatsEngine.unlockSeason(this)
                "skin" -> StatsEngine.unlockSkins(this)
                "sticker" -> StatsEngine.unlockStickers(this)
                "profile" -> StatsEngine.unlockProfile(this)
                "achv" -> StatsEngine.unlockAchievements(this)
                else -> listOf(StatsEngine.line("${u.title}: ${tr("tidak dikenal", "unknown")}"))
            }
            log(lines, true)
        }
    }

    // ---------- Statistik Profil ----------
    private fun scrollConsole() { consoleScroll?.let { sv -> sv.post { sv.getChildAt(0)?.let { sv.scrollTo(0, it.height) } } } }

    /** Beri warna pada teks console: jam redup, sukses hijau, gagal merah, judul kuning. */
    private fun styled(text: String): android.text.SpannableStringBuilder {
        val sb = android.text.SpannableStringBuilder(text)
        val tsRe = Regex("^(\\d\\d:\\d\\d:\\d\\d)\\s{2}")
        var off = 0
        for (ln in text.split("\n")) {
            val m = tsRe.find(ln)
            val bodyStart = off + (m?.value?.length ?: 0)
            val body = ln.substring(m?.value?.length ?: 0)
            fun paint(from: Int, to: Int, c: Int) { if (to > from) sb.setSpan(android.text.style.ForegroundColorSpan(c), from, to, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE) }
            if (m != null) paint(off, off + m.groupValues[1].length, Color.parseColor("#7C84C9"))
            val low = body.lowercase()
            val c = when {
                body.contains("✔") || low.contains("berhasil") || low.contains("success") || low.contains("dibuat") || low.startsWith("terbaca") -> "#5CF0A0"
                body.contains("✘") || low.contains("gagal") || low.contains("fail") || low.contains("tidak bisa") || low.contains("tidak ada") || low.contains("melebihi") -> "#FF7A9A"
                body.startsWith("—") -> "#FFD166"
                else -> "#DCE0FF"
            }
            paint(bodyStart, off + ln.length, Color.parseColor(c))
            off += ln.length + 1
        }
        return sb
    }

    private fun log(lines: List<String>, feedback: Boolean = false, raw: Boolean = false) = runOnUiThread {
        lines.forEach { fullLog.append(it).append('\n') }
        if (fullLog.length > 40000) fullLog.delete(0, fullLog.length - 30000)
        if (consoleLog.length > 12000) { consoleLog.delete(0, consoleLog.length - 8000); val nl = consoleLog.indexOf("\n"); if (nl >= 0) consoleLog.delete(0, nl + 1); shown = consoleLog.toString().trimEnd().length }
        (if (raw) lines.map { if (it.length > 60) it.take(59) + "…" else it } else concise(lines)).forEach { consoleLog.append(it).append('\n') }
        trimConsole(); shown = minOf(shown, consoleLog.length)
        fullStyled = null
        val tv = consoleTv
        if (tv != null) { tv.removeCallbacks(typer); if (S.effects) typer.run() else { shown = consoleLog.toString().trimEnd().length; tv.text = styled(consoleLog.toString().trimEnd()); scrollConsole() } }
        refreshHeader()
        if (feedback) { if (lines.any { it.contains("✔") }) fx.check(true) else if (lines.any { it.contains("gagal", true) || it.contains("fail", true) }) fx.check(false) }
    }

    /** Warna tiap statistik: [terang, gelap] untuk ubin ikon; terang juga dipakai untuk tint kolom isian. */
    private fun tint(key: String): Pair<Int, Int> {
        val p = when (key) {
            "tcash" -> "#FFD84D" to "#FF9F1C"; "coin" -> "#FFA94D" to "#F76707"; "level" -> "#3EDCFF" to "#0891B2"
            "levelm3" -> "#B07CFF" to "#7C3AED"; "firstwin" -> "#34E0C4" to "#0E9F8E"; "lives" -> "#FF6B9D" to "#E11D68"
            "help" -> "#5FE0A8" to "#10936A"; "cards" -> "#A78BFA" to "#6D28D9"; "regatta" -> "#FF7BAC" to "#D6246E"
            "monthyear" -> "#7C9CFF" to "#4263EB"; "expenergy" -> "#FF8FAB" to "#E64980"; else -> "#4FE3B0" to "#12A37A"
        }
        return Color.parseColor(p.first) to Color.parseColor(p.second)
    }
    private fun withAlpha(c: Int, a: Int) = (c and 0x00FFFFFF) or (a shl 24)
    private fun round(fill: Int, r: Int, stroke: Int = 0, sw: Float = 1f) = GradientDrawable().apply { setColor(fill); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke((dp(1) * sw).toInt(), stroke) }

    private fun chip(label: String, color: Int, onClick: () -> Unit) = TextView(this).apply {
        text = label; textSize = 9.5f; typeface = Typeface.DEFAULT_BOLD; setTextColor(color); gravity = Gravity.CENTER
        setPadding(dp(7), dp(4), dp(7), dp(4)); background = round(withAlpha(color, 0x26), 10, withAlpha(color, 0x66))
        setOnClickListener { press(it, onClick) }
    }

    private fun dot(c: String) = View(this).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor(c)) } }

    /** Console tetap di bawah, dipakai semua tab. */
    private fun consolePanel(): View {
        val con = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; elevation = dp(4).toFloat(); setPadding(dp(8), dp(5), dp(8), dp(7))
            background = round(Color.parseColor("#12163F"), 14, Color.parseColor("#4A55C9"))
            val bar = LinearLayout(context).apply { gravity = Gravity.CENTER_VERTICAL }
            listOf("#FF5F57", "#FEBC2E", "#28C840").forEach { bar.addView(dot(it), LinearLayout.LayoutParams(dp(8), dp(8)).apply { rightMargin = dp(5) }) }
            bar.addView(TextView(context).apply { text = "CONSOLE"; textSize = 10f; letterSpacing = 0.12f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; setPadding(dp(6), 0, 0, 0) }, LinearLayout.LayoutParams(0, -2, 1f))
            bar.addView(chip("LOG", Color.parseColor("#B07CFF")) {
                work(tr("Membaca log…", "Reading log…")) {
                    val t = RootShell.exec("logcat -d -b crash -t 60", 10000)?.text?.trim().orEmpty()
                    log(if (t.isEmpty()) listOf("LOG: kosong / butuh root") else listOf("— LOG CRASH —") + t.lines().takeLast(8), raw = true)
                }
            }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
            bar.addView(chip("COPY", Color.parseColor("#7C9CFF")) {
                (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("console", fullLog.toString())); toast("Copied")
            }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
            bar.addView(chip("CLEAR", Color.parseColor("#FF7A9A")) { consoleTv?.removeCallbacks(typer); consoleLog.setLength(0); fullLog.setLength(0); fullStyled = null; shown = 0; consoleTv?.text = "" })
            addView(bar)
            // ID kota: kosong = save terbaru; diisi = pilih save milik kota itu lalu hubungkan.
            val idRow = LinearLayout(context).apply { gravity = Gravity.CENTER_VERTICAL }
            cityEt = EditText(context).apply {
                hint = tr("ID kota (opsional)", "City ID (optional)"); setHintTextColor(withAlpha(Color.WHITE, 0x55)); setTextColor(Color.WHITE)
                textSize = 11f; typeface = Typeface.MONOSPACE; isSingleLine = true; minHeight = 0; minimumHeight = 0; gravity = Gravity.CENTER_VERTICAL
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_GO
                setPadding(dp(8), 0, dp(8), 0); background = round(Color.parseColor("#080B26"), 10, Color.parseColor("#3A44A8"))
                setText(getSharedPreferences("aurora_city", MODE_PRIVATE).getString("id", ""))
                setOnEditorActionListener { _, _, _ -> doConnect(); true }
            }
            idRow.addView(cityEt, LinearLayout.LayoutParams(0, dp(28), 1f))
            idRow.addView(chip(tr("PAKAI ID", "USE ID"), Color.parseColor("#5CF0A0")) { doConnect() }, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(6) })
            addView(idRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
            consoleTv = TextView(context).apply {
                typeface = Typeface.MONOSPACE; textSize = 9.5f; setLineSpacing(dp(1).toFloat(), 1f); setTextColor(Color.parseColor("#DCE0FF")); setPadding(dp(2), dp(2), dp(4), dp(2))
                val t = consoleLog.toString().trimEnd(); text = styled(t); shown = t.length
            }
            // Tinggi console tetap; isi yang panjang bergulir di dalam kotak, bukan memanjang ke bawah.
            val cs = ScrollView(context).apply {
                isScrollbarFadingEnabled = false; setPadding(dp(8), dp(5), dp(8), dp(5)); clipToPadding = false
                background = round(Color.parseColor("#080B26"), 12, Color.parseColor("#3A44A8"), 1.5f)
                addView(consoleTv)
                setOnTouchListener { v, _ -> v.parent.requestDisallowInterceptTouchEvent(true); false }
                post { getChildAt(0)?.let { scrollTo(0, it.height) } }
            }
            consoleScroll = cs
            addView(cs, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(4) })
        }
        return con
    }

    /** Panel kosong (ikon ⊘ + pesan) saat save belum didekode. */
    private fun needConnectPanel(): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(16), dp(24), dp(16), dp(24)); minimumHeight = dp(170)
        addView(TextView(context).apply {
            text = "⊘"; textSize = 34f; gravity = Gravity.CENTER; setTextColor(SOFT); background = round(withAlpha(SOFT, 0x22), 40)
        }, LinearLayout.LayoutParams(dp(72), dp(72)))
        addView(TextView(context).apply {
            text = tr("Dekode simpanan dulu: tekan HUBUNGKAN di atas.", "Decode the save first: tap CONNECT above.")
            textSize = 14f; gravity = Gravity.CENTER; setTextColor(SOFT); setPadding(0, dp(10), 0, 0)
        })
    }

    private fun statsCards(): List<View> {
        if (!Session.connected) return listOf(needConnectPanel())
        val inputs = HashMap<String, EditText>()
        statInputs = inputs; statOrig.clear()
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(4), 0, dp(4), dp(2))
            addView(TextView(context).apply { text = tr("Statistik Profil", "Profile Stats"); textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE) })
            addView(TextView(context).apply { text = tr("Ubah nilai → Terapkan → SIMPAN & KIRIM.", "Edit a value → Apply → SAVE & SEND."); textSize = 11f; setTextColor(SOFT); setPadding(0, dp(2), 0, 0) })
        }
        val rows = Stats.LIST.map { s ->
            val (hi, lo) = tint(s.key)
            FxCard(this, 18).apply {
                gravity = Gravity.CENTER_VERTICAL; elevation = dp(3).toFloat(); setPadding(dp(8), dp(6), dp(8), dp(6))
                background = surface(16, withAlpha(hi, 0x55)); tintShadow(this, hi)
                val side = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
                side.addView(TextView(context).apply {
                    text = s.icon; textSize = 14f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
                    background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(hi, lo)).apply { cornerRadius = dp(14).toFloat() }
                }, LinearLayout.LayoutParams(dp(30), dp(30)))
                side.addView(TextView(context).apply {
                    text = s.label; textSize = 8.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(Color.parseColor("#C6CCFF")); maxLines = 2
                    setPadding(0, dp(3), 0, 0)
                }, LinearLayout.LayoutParams(-1, -2))
                addView(side, LinearLayout.LayoutParams(dp(58), -2))
                val et = EditText(context).apply {
                    inputType = if (s.monthYear) InputType.TYPE_CLASS_DATETIME else InputType.TYPE_CLASS_NUMBER
                    hint = s.hint; setHintTextColor(withAlpha(Color.WHITE, 0x55)); setTextColor(Color.WHITE); textSize = 14f; typeface = Typeface.DEFAULT_BOLD; isSingleLine = true
                    setPadding(dp(10), dp(4), dp(10), dp(4)); background = round(withAlpha(hi, 0x26), 11, withAlpha(hi, 0x99), 1.5f)
                }
                inputs[s.key] = et
                addView(et, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(6); rightMargin = dp(6) })
                addView(glowButton(S.t("apply"), 9, 6, 11f) {
                    val v = et.text.toString()
                    work(tr("Menerapkan ${s.key}…", "Applying ${s.key}…")) {
                        val before = Session.edits
                        log(StatsEngine.apply(this@MainActivity, s, v), true)
                        if (Session.edits > before) statOrig[s.key] = v.trim()   // hanya bila benar-benar tercatat; jika gagal, tetap dianggap belum diterapkan
                    }
                })
            }
        }
        loadStart(tr("Membaca data save…", "Reading save data…"))
        Thread {
            try {
                val r = StatsEngine.load(this)
                runOnUiThread { r.values.forEach { (k, v) -> inputs[k]?.setText(v); statOrig[k] = v } }
                log(r.log)
            } catch (e: Throwable) { log(listOf(StatsEngine.line("✘ ${tr("gagal", "failed")}: ${e.message ?: e.javaClass.simpleName}"))) }
            finally { runOnUiThread { loadEnd() } }
        }.start()
        return listOf(head) + rows
    }

    private fun helpCards(): List<View> =
        (1..4).map { i -> card(S.t("h${i}t"), "?", S.t("h$i")) {} }

    private fun rebuild() { val keep = ArrayList(stack); build(); stack.clear(); stack.addAll(keep); show(stack.last(), false) }

    /** Jalankan [onOk] hanya bila di ruang virtual (root opsional). */
    private fun gated(onOk: () -> Unit) {
        if (loads > 0) return
        loadStart(S.t("checkingEnv"))
        Thread {
            val g = try { Env.gate(this) } catch (e: Throwable) { runOnUiThread { loadEnd() }; return@Thread }
            runOnUiThread {
                loadEnd()
                when (g) {
                    Env.Gate.OK -> onOk()
                    Env.Gate.NOT_VIRTUAL -> toast(S.t("gateVirt"))
                }
            }
        }.start()
    }

    private fun launchGame() { if (!GameBridge.launch(this)) toast(S.t("notInstalled")) }

    private var busy = false

    /** HUBUNGKAN: dekode save game, bangun sesi edit, lalu muat ulang layar agar nilai terbaca. */
    private fun doConnect() {
        if (busy) return
        if (Session.dirty) {
            AlertDialog.Builder(this).setTitle(tr("Hubungkan ulang?", "Reconnect?"))
                .setMessage(tr("${Session.edits} perubahan belum disimpan akan hilang. Tekan SIMPAN & KIRIM dulu bila ingin menyimpannya.", "${Session.edits} unsaved change(s) will be lost. Tap SAVE & SEND first to keep them."))
                .setPositiveButton(tr("Hubungkan ulang", "Reconnect")) { _, _ -> connectNow() }
                .setNegativeButton(S.t("cancel"), null).show()
        } else connectNow()
    }

    private fun connectNow() {
        val id = cityEt?.text?.toString()?.trim().orEmpty()
        getSharedPreferences("aurora_city", MODE_PRIVATE).edit().putString("id", id).apply()
        gated {
            busy = true; btnConnect.text = tr("MENGHUBUNGKAN…", "CONNECTING…"); loadStart(tr("Menghubungkan ke save game…", "Connecting to the game save…"))
            log(listOf(StatsEngine.line(if (id.isEmpty()) tr("Menghubungkan ke save Township...", "Connecting to the Township save...") else tr("Menghubungkan ke kota ID $id...", "Connecting to city ID $id..."))))
            Thread {
                val r = try { StatsEngine.connect(this, id) } catch (e: Throwable) { runOnUiThread { busy = false; loadEnd() }; throw e }
                log(r.log, true)
                runOnUiThread { busy = false; loadEnd(); refreshHeader(); if (r.ok && !isFinishing && stack.isNotEmpty()) show(stack.last(), false) }
            }.start()
        }
    }

    /** SIMPAN & KIRIM: enkode editan, tulis ke data game, lalu luncurkan Township. Tanpa sesi: hanya meluncurkan game. */
    private fun doSaveLaunch() {
        if (busy) return
        gated {
            if (!Session.connected) {
                log(listOf(StatsEngine.line(tr("Belum terhubung — hanya membuka Township.", "Not connected — only opening Township."))))
                launchGame(); return@gated
            }
            busy = true; btnSave.text = tr("MENYIMPAN…", "SAVING…"); loadStart(tr("Menyimpan & mengirim ke game…", "Saving & sending to the game…"))
            // Kolom yang sudah diubah tetapi belum ditekan "Terapkan" ikut diterapkan otomatis (sebelumnya terlewat -> "tidak ada perubahan").
            val pending = Stats.LIST.mapNotNull { s -> statInputs[s.key]?.text?.toString()?.trim()?.let { t -> if (t.isNotEmpty() && t != statOrig[s.key]) s to t else null } }
            log(listOf(StatsEngine.line(tr("Mengenkode & menyimpan ke game...", "Encoding & writing to the game..."))))
            Thread {
                for ((s, t) in pending) {
                    val before = Session.edits
                    log(StatsEngine.apply(this, s, t), true)
                    if (Session.edits > before) statOrig[s.key] = t
                }
                val r = try { StatsEngine.saveBack(this) } catch (e: Throwable) { runOnUiThread { busy = false; loadEnd() }; throw e }
                log(r.log, true)
                pushConsoleToRoot()
                if (r.ok) StatsEngine.disconnect()   // game akan menulis save-nya sendiri; sesi lama jadi usang
                runOnUiThread {
                    busy = false; loadEnd(); refreshHeader()
                    if (r.ok && !isFinishing) {
                        if (stack.isNotEmpty()) show(stack.last(), false)
                        if (r.launch) {
                            launchGame()
                            // Pantau save sesudah game dibuka: apakah game menimpa editan atau membiarkannya.
                            Thread { try { StatsEngine.watchAfterLaunch(this) { lines -> log(lines, true) } } catch (_: Throwable) {} }.start()
                        }
                    }
                }
            }.start()
        }
    }

    /** Tujuan log console saat SIMPAN & KIRIM: folder root (/data/local/tmp) dan penyimpanan internal, keduanya terlihat di MT Manager. */
    private val logDirs = listOf("/data/local/tmp/aurora", "/sdcard/AuroraToolsTS")

    /** Kirim log console lengkap ke direktori tujuan lewat root (dilewati bila root tidak aktif). */
    private fun pushConsoleToRoot() {
        if (Env.rootVerified != true) return
        runOnUiThread {
            val snap = fullLog.toString()
            Thread {
                val done = ArrayList<String>()
                try {
                    val tmp = java.io.File(cacheDir, "console.push.tmp")
                    tmp.writeText(snap); tmp.setReadable(true, false)
                    for (d in logDirs) {
                        val r = RootShell.exec("mkdir -p '$d' && cat '${tmp.absolutePath}' > '$d/console.log' && chmod 644 '$d/console.log'", 15000)
                        if (r?.code == 0) done.add(d)
                    }
                    tmp.delete()
                } catch (_: Exception) {}
                log(listOf(StatsEngine.line(if (done.isNotEmpty()) "Log → ${done.joinToString(", ")} ✔" else "Log ke root gagal ✘")))
            }.start()
        }
    }

    private fun tr(id: String, en: String) = if (S.lang == "id") id else en

    /** Jalankan pekerjaan berat dengan dialog proses, lalu tampilkan hasil & segarkan layar cadangan. */
    private fun background(block: () -> CityBackup.Result) {
        if (loads > 0) return
        loadStart(S.t("working"))
        Thread {
            val r = try { block() } catch (e: Throwable) { CityBackup.Result(false, "${tr("gagal", "failed")}: ${e.message ?: e.javaClass.simpleName}") }
            runOnUiThread {
                loadEnd()
                if (isFinishing) return@runOnUiThread
                fx.check(r.ok); refreshHeader()
                AlertDialog.Builder(this).setMessage(r.message).setPositiveButton("OK", null).show()
                if (stack.isNotEmpty() && (stack.last().kind == Kind.BACKUP || (stack.size == 1 && (tab == 2 || tab == 4)))) show(stack.last(), false)
            }
        }.start()
    }

    private fun labelText(l: String) = when (l) {
        "auto" -> tr("Otomatis (sebelum Terapkan)", "Auto (before Apply)")
        "pengaman" -> tr("Pengaman (sebelum Pulihkan)", "Safety (before Restore)")
        "manual" -> "Manual"
        else -> "Manual: $l"
    }

    /** Layar Backup & City Data: ringkasan, aksi, dan daftar cadangan. */
    private fun backupCards(): List<View> {
        val items = CityBackup.list(this)
        val fmt = java.text.SimpleDateFormat("dd MMM yyyy  HH:mm:ss", java.util.Locale.forLanguageTag(S.lang))
        val total = items.sumOf { it.file.length() }
        val out = ArrayList<View>()
        out.add(card(tr("Ringkasan cadangan", "Backup summary"), "${items.size}",
            if (items.isEmpty()) tr("Belum ada cadangan", "No backups yet") else "${CityBackup.size(total)} • ${tr("terakhir", "latest")} ${fmt.format(java.util.Date(items[0].time))}") {})
        out.add(card(tr("Buat cadangan sekarang", "Create backup now"), "＋") { askBackup() })
        out.add(card(tr("Ambil file save (Fetch)", "Fetch save file"), "⇩", "mGameInfo.xml") { background { CityBackup.fetch(this) } })
        if (items.isNotEmpty()) out.add(TextView(this).apply { text = tr("Daftar cadangan — ketuk untuk pulihkan / hapus", "Backups — tap to restore / delete"); setTextColor(SOFT); textSize = 12f; setPadding(dp(4), dp(6), 0, 0) })
        items.forEachIndexed { i, it ->
            val tag = if (i == items.lastIndex && items.size > 1) " • ${tr("terlama", "oldest")}" else ""
            out.add(card(fmt.format(java.util.Date(it.time)), "›", "${labelText(it.label)} • ${CityBackup.size(it.file.length())} • ${it.ext.uppercase()}$tag") { backupActions(it) })
        }
        return out
    }

    private fun askBackup() {
        val et = EditText(this).apply { hint = tr("Catatan (opsional), mis. sebelum-event", "Note (optional), e.g. before-event"); isSingleLine = true }
        AlertDialog.Builder(this).setTitle(tr("Buat cadangan", "Create backup")).setView(et)
            .setPositiveButton(tr("Cadangkan", "Back up")) { _, _ -> val n = et.text.toString(); background { CityBackup.backup(this, n.ifBlank { "manual" }) } }
            .setNegativeButton(S.t("cancel"), null).show()
    }

    private fun backupActions(i: CityBackup.Info) {
        AlertDialog.Builder(this).setTitle(i.file.name)
            .setItems(arrayOf(tr("Pulihkan data game ke cadangan ini", "Restore game data to this backup"), tr("Hapus cadangan", "Delete backup"))) { _, w ->
                if (w == 0) AlertDialog.Builder(this).setTitle(tr("Pulihkan?", "Restore?"))
                    .setMessage(tr("Data game saat ini akan ditimpa dengan cadangan ini. Cadangan pengaman dibuat otomatis lebih dulu, jadi bisa dibatalkan. Tutup Township sepenuhnya sebelum lanjut.",
                        "Current game data will be overwritten by this backup. A safety backup is made first, so you can undo. Fully close Township before continuing."))
                    .setPositiveButton(tr("Pulihkan", "Restore")) { _, _ -> background { CityBackup.restore(this, i.file) } }
                    .setNegativeButton(S.t("cancel"), null).show()
                else AlertDialog.Builder(this).setTitle(tr("Hapus cadangan?", "Delete backup?")).setMessage(i.file.name)
                    .setPositiveButton(tr("Hapus", "Delete")) { _, _ -> CityBackup.delete(i); toast(tr("Dihapus", "Deleted")); show(stack.last(), false) }
                    .setNegativeButton(S.t("cancel"), null).show()
            }.setNegativeButton(S.t("cancel"), null).show()
    }

    private fun run(feature: String, value: Int? = null) {
        when (feature) {
            F_BACKUP -> background { CityBackup.backup(this) }
            F_FETCH -> background { CityBackup.fetch(this) }
            else -> gated {
                work(tr("Menerapkan $feature…", "Applying $feature…")) {
                    val ok = GameBridge.apply(this@MainActivity, feature, value)
                    val msg = if (ok) tr("$feature disiapkan ✔ (tekan SIMPAN & KIRIM)", "$feature staged ✔ (tap SAVE & SEND)") else "$feature: ${S.t("engine")}"
                    log(listOf(StatsEngine.line(msg)), ok)
                    runOnUiThread { refreshHeader() }
                }
            }
        }
    }

    private fun open(n: Node) {
        when (n.kind) {
            Kind.MENU -> if (n.children.isEmpty()) run(n.title) else show(n)
            Kind.INFO, Kind.HELP, Kind.STATS, Kind.BACKUP, Kind.EDITOR -> show(n)
            Kind.ACTION -> run(n.title)
            Kind.NUMBER -> {
                val et = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; hint = "0 – ${n.max}" }
                AlertDialog.Builder(this).setTitle(n.title).setView(et)
                    .setPositiveButton(S.t("apply")) { _, _ -> run(n.title, (et.text.toString().toIntOrNull() ?: 0).coerceIn(0, n.max)) }
                    .setNegativeButton(S.t("cancel"), null).show()
            }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onBackPressed() {
        if (loads > 0) return
        if (stack.size > 1) { stack.removeAt(stack.size - 1); show(stack.last(), false) } else {
            val now = System.currentTimeMillis()
            if (now - lastBack < 2000) super.onBackPressed() else { lastBack = now; toast(S.t("exitAgain")) }
        }
    }
}
