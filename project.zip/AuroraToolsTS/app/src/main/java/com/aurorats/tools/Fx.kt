package com.aurorats.tools

import android.animation.*
import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import android.view.animation.*
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.*
import kotlin.random.Random

/** Kumpulan efek gerak. Semua animasi terus-menerus mengikuti saklar "Efek latar" (S.effects) dan berhenti otomatis saat view dilepas. */
object Fx {
    private fun dens(v: View) = v.resources.displayMetrics.density

    /** Jalankan animator tanpa akhir & batalkan otomatis saat view lepas dari layar. */
    fun run(v: View, a: Animator) {
        a.start()
        v.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(x: View) {}
            override fun onViewDetachedFromWindow(x: View) { a.cancel() }
        })
    }

    private fun loop(a: ObjectAnimator, ms: Long, reverse: Boolean = true, interp: TimeInterpolator = AccelerateDecelerateInterpolator()) = a.apply {
        duration = ms; repeatCount = ValueAnimator.INFINITE
        repeatMode = if (reverse) ValueAnimator.REVERSE else ValueAnimator.RESTART; interpolator = interp
    }

    /** Melayang naik-turun. */
    fun float(v: View, ampDp: Float = 4f, ms: Long = 2600) {
        if (!S.effects) return
        val a = dens(v) * ampDp
        run(v, loop(ObjectAnimator.ofFloat(v, View.TRANSLATION_Y, -a, a), ms))
    }

    /** Denyut membesar-mengecil (untuk halo / cahaya). */
    fun pulse(v: View, from: Float = 0.92f, to: Float = 1.18f, ms: Long = 1600) {
        if (!S.effects) return
        run(v, loop(ObjectAnimator.ofPropertyValuesHolder(v,
            PropertyValuesHolder.ofFloat(View.SCALE_X, from, to), PropertyValuesHolder.ofFloat(View.SCALE_Y, from, to),
            PropertyValuesHolder.ofFloat(View.ALPHA, 0.55f, 0.2f)), ms))
    }

    /** Transparansi bernapas. */
    fun breathe(v: View, a0: Float = 0.5f, a1: Float = 1f, ms: Long = 1800) {
        if (!S.effects) return
        run(v, loop(ObjectAnimator.ofFloat(v, View.ALPHA, a0, a1), ms))
    }

    /** Menggeser kecil ke kanan-kiri (panah ›). */
    fun nudge(v: View, ms: Long = 900) {
        if (!S.effects) return
        run(v, loop(ObjectAnimator.ofFloat(v, View.TRANSLATION_X, -dens(v) * 5f, 0f), ms))
    }

    /** Berputar terus. */
    fun spin(v: View, ms: Long = 6000) {
        if (!S.effects) return
        run(v, loop(ObjectAnimator.ofFloat(v, View.ROTATION, 0f, 360f), ms, false, LinearInterpolator()))
    }

    /** Zoom pelan + geser (Ken Burns) untuk gambar banner. */
    fun kenBurns(v: View, ms: Long = 7000) {
        if (!S.effects) return
        val d = dens(v)
        run(v, loop(ObjectAnimator.ofPropertyValuesHolder(v,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1.03f, 1.16f), PropertyValuesHolder.ofFloat(View.SCALE_Y, 1.03f, 1.16f),
            PropertyValuesHolder.ofFloat(View.TRANSLATION_X, -8 * d, 8 * d)), ms))
    }

    /** Pita kilau yang menyapu melintasi [w] piksel lalu jeda. */
    fun sweep(v: View, w: Int, ms: Long = 5500) {
        if (!S.effects) { v.visibility = View.GONE; return }
        val x0 = -dens(v) * 140
        val a = ObjectAnimator.ofPropertyValuesHolder(v, PropertyValuesHolder.ofKeyframe(View.TRANSLATION_X,
            Keyframe.ofFloat(0f, x0), Keyframe.ofFloat(0.3f, w.toFloat()), Keyframe.ofFloat(1f, w.toFloat())))
        a.duration = ms; a.repeatCount = ValueAnimator.INFINITE; a.interpolator = LinearInterpolator(); a.startDelay = Random.nextLong(300, 2000)
        run(v, a)
    }

    /** Kartu jatuh ke tempatnya: naik dari bawah sambil miring ke depan, memantul pegas lalu diam. Berurutan berdasarkan [i]. */
    fun enter(v: View, i: Int, fromDp: Float = 26f) {
        if (!S.effects) return
        v.cameraDistance = dens(v) * 9000f
        v.alpha = 0f; v.translationY = dens(v) * fromDp; v.scaleX = .94f; v.scaleY = .94f; v.rotationX = -14f
        v.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).rotationX(0f)
            .setStartDelay(min(i, 12) * 55L).setDuration(640).setInterpolator(Spring(1.6f, 5.5f)).start()
    }

    /**
     * Efek sentuh 3D: kartu miring mengikuti jari (sisi yang ditekan menjauh), sedikit mengecil dan "tenggelam" (bayangan menipis),
     * lalu kembali dengan pegas saat dilepas. Tidak menelan sentuhan, jadi klik & gulir tetap normal.
     */
    fun tilt(v: View, maxDeg: Float = 6f) {
        v.cameraDistance = dens(v) * 9000f
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    val w = view.width.coerceAtLeast(1); val h = view.height.coerceAtLeast(1)
                    val nx = ((e.x - w / 2f) / (w / 2f)).coerceIn(-1f, 1f); val ny = ((e.y - h / 2f) / (h / 2f)).coerceIn(-1f, 1f)
                    if (e.actionMasked == MotionEvent.ACTION_DOWN) {
                        view.animate().rotationY(nx * maxDeg).rotationX(-ny * maxDeg).scaleX(.975f).scaleY(.975f).translationZ(-view.elevation * .5f)
                            .setStartDelay(0).setDuration(90).setInterpolator(DecelerateInterpolator()).start()
                    } else {
                        view.animate().cancel(); view.rotationY = nx * maxDeg; view.rotationX = -ny * maxDeg
                        view.scaleX = .975f; view.scaleY = .975f; view.translationZ = -view.elevation * .5f
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().rotationX(0f).rotationY(0f).scaleX(1f).scaleY(1f).translationZ(0f)
                        .setStartDelay(0).setDuration(520).setInterpolator(Spring(2f, 6f)).start()
            }
            false
        }
    }
}

/** Pegas teredam: melewati target sedikit, memantul, lalu menetap (seperti benda sungguhan). [cycles] = jumlah ayunan, [decay] = redaman. */
class Spring(private val cycles: Float = 2.5f, private val decay: Float = 6f) : TimeInterpolator {
    override fun getInterpolation(t: Float): Float = (1.0 - exp(-decay.toDouble() * t) * cos(cycles * 2.0 * PI * t)).toFloat()
}

/** Penyapu kilau diagonal yang dipakai kartu & tombol. */
class Shine(private val v: View, private val radiusDp: Int, private val period: Long = 5200) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF(); private val m = Matrix(); private var rad = 0f
    private var shader: LinearGradient? = null
    private var bw = 0f; private var phase = 1f
    private var anim: ValueAnimator? = null
    private val sweepPart = 0.28f

    fun size(w: Int, h: Int) {
        bw = max(w * 0.35f, 70f * v.resources.displayMetrics.density)
        shader = LinearGradient(0f, 0f, bw, 0f, intArrayOf(0x00FFFFFF, 0x38FFFFFF, 0x00FFFFFF), null, Shader.TileMode.CLAMP)
        rad = radiusDp * v.resources.displayMetrics.density
        rect.set(0f, 0f, w.toFloat(), h.toFloat())
    }

    fun attach() {
        if (!S.effects) return
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = period + Random.nextLong(0, 2500); repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener { phase = it.animatedValue as Float; if (phase < sweepPart) v.invalidate() }
            setCurrentFraction(Random.nextFloat()); start()
        }
    }

    fun detach() { anim?.cancel(); anim = null }

    fun draw(cv: Canvas) {
        val sh = shader ?: return
        if (!S.effects || phase >= sweepPart) return
        val x = -bw + (rect.width() + bw) * (phase / sweepPart)
        m.setSkew(-0.35f, 0f); m.postTranslate(x, 0f); sh.setLocalMatrix(m)
        p.shader = sh
        cv.drawRoundRect(rect, rad, rad, p)
    }
}

/** Kartu menu dengan kilau yang lewat berkala. */
class FxCard(c: Context, radiusDp: Int = 18) : LinearLayout(c) {
    private val shine = Shine(this, radiusDp)
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { super.onSizeChanged(w, h, ow, oh); shine.size(w, h) }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); shine.attach() }
    override fun onDetachedFromWindow() { shine.detach(); super.onDetachedFromWindow() }
    override fun dispatchDraw(canvas: Canvas) { super.dispatchDraw(canvas); shine.draw(canvas) }
}

/** Tombol teks dengan kilau yang lewat berkala. */
class FxButton(c: Context, radiusDp: Int = 14) : TextView(c) {
    private val shine = Shine(this, radiusDp, 4200)
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { super.onSizeChanged(w, h, ow, oh); shine.size(w, h) }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); shine.attach() }
    override fun onDetachedFromWindow() { shine.detach(); super.onDetachedFromWindow() }
    override fun onDraw(canvas: Canvas) { super.onDraw(canvas); shine.draw(canvas) }
}

/** Teks dengan gradasi warna yang mengalir. */
class GlowText(c: Context) : TextView(c) {
    private val m = Matrix()
    private var sh: LinearGradient? = null
    private var anim: ValueAnimator? = null
    private var shift = 0f

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (w > 0) sh = LinearGradient(0f, 0f, w.toFloat(), 0f,
            intArrayOf(Color.WHITE, Color.parseColor("#9FB8FF"), Color.parseColor("#D49BFF"), Color.WHITE), null, Shader.TileMode.MIRROR)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!S.effects) return
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 3600; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener { shift = it.animatedValue as Float; invalidate() }; start()
        }
    }

    override fun onDetachedFromWindow() { anim?.cancel(); anim = null; super.onDetachedFromWindow() }

    override fun onDraw(canvas: Canvas) {
        val s = sh
        if (s != null && S.effects) { m.setTranslate(shift * width * 2f, 0f); s.setLocalMatrix(m); paint.shader = s } else paint.shader = null
        super.onDraw(canvas)
    }
}

/** Titik-titik cahaya berekor yang mengorbit logo (splash). */
class OrbitView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var a = 0f
    private var last = 0L
    private val cols = intArrayOf(Color.parseColor("#35D6FF"), Color.parseColor("#B46BFF"), Color.parseColor("#6D8DFF"))
    private val rad = floatArrayOf(0.47f, 0.43f, 0.40f)
    private val spd = floatArrayOf(1.5f, -1.1f, 2.0f)

    override fun onDraw(cv: Canvas) {
        val now = System.nanoTime(); val dt = if (last == 0L) 0f else ((now - last) / 1e9f).coerceAtMost(0.05f); last = now
        if (!S.effects) return
        a += dt
        val cx = width / 2f; val cy = height / 2f; val d = resources.displayMetrics.density
        for (j in 0..2) for (k in 0 until 14) {
            val ang = a * spd[j] - k * 0.10f * sign(spd[j])
            val x = cx + width * rad[j] * cos(ang); val y = cy + height * rad[j] * sin(ang)
            p.color = cols[j]; p.alpha = (255 * (1f - k / 14f)).toInt()
            cv.drawCircle(x, y, (4.2f - k * 0.25f).coerceAtLeast(0.8f) * d, p)
        }
        postInvalidateOnAnimation()
    }
}

/** Lapisan efek di atas layar: ledakan partikel saat tombol ditekan & animasi centang/silang hasil. Tidak menangkap sentuhan. */
class FxOverlay(c: Context) : View(c) {
    private class P(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, val col: Int, val r: Float)
    private val d = c.resources.displayMetrics.density
    private val ps = ArrayList<P>()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path(); private val seg = Path()
    private var checkT = -1f; private var ok = true
    private var last = 0L
    private val cols = intArrayOf(Color.parseColor("#35D6FF"), Color.parseColor("#9B4DFF"), Color.parseColor("#3D6BFF"), Color.parseColor("#E26BFF"), Color.WHITE)

    fun burst(x: Float, y: Float) {
        if (!S.effects) return
        repeat(24) {
            val a = Random.nextFloat() * 6.283f; val sp = (120f + Random.nextFloat() * 260f) * d
            ps.add(P(x, y, cos(a) * sp, sin(a) * sp - 80f * d, 1f, cols[Random.nextInt(cols.size)], (1.5f + Random.nextFloat() * 2.5f) * d))
        }
        invalidate()
    }

    fun check(success: Boolean) { checkT = 0f; ok = success; invalidate() }

    override fun onDraw(cv: Canvas) {
        val now = System.nanoTime(); val dt = if (last == 0L) 0f else ((now - last) / 1e9f).coerceAtMost(0.05f); last = now
        val it = ps.iterator()
        while (it.hasNext()) {
            val q = it.next(); q.x += q.vx * dt; q.y += q.vy * dt; q.vy += 620f * d * dt; q.life -= dt * 1.5f
            if (q.life <= 0f) { it.remove(); continue }
            p.style = Paint.Style.FILL; p.color = q.col; p.alpha = (q.life * 255).toInt().coerceIn(0, 255)
            cv.drawCircle(q.x, q.y, q.r * (0.5f + q.life * 0.5f), p)
        }
        if (checkT >= 0f) {
            checkT += dt
            val T = 1.2f; val u = checkT / T
            if (u >= 1f) checkT = -1f else {
                val cx = width / 2f; val cy = height * 0.42f
                val grow = (checkT / 0.35f).coerceIn(0f, 1f)
                val sc = OvershootInterpolator(2.2f).getInterpolation(grow)
                val fade = if (u > 0.75f) (1f - (u - 0.75f) / 0.25f) else 1f
                val col = if (ok) Color.parseColor("#6DFFB0") else Color.parseColor("#FF7A9A")
                val r = 46f * d * sc
                p.style = Paint.Style.FILL; p.color = Color.parseColor("#E6080B22"); p.alpha = (230 * fade).toInt(); cv.drawCircle(cx, cy, r, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = 4f * d; p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
                p.color = col; p.alpha = (255 * fade).toInt(); cv.drawCircle(cx, cy, r, p)
                val prog = ((checkT - 0.15f) / 0.4f).coerceIn(0f, 1f)
                path.reset()
                if (ok) { path.moveTo(cx - r * 0.42f, cy + r * 0.02f); path.lineTo(cx - r * 0.1f, cy + r * 0.34f); path.lineTo(cx + r * 0.46f, cy - r * 0.3f) }
                else { path.moveTo(cx - r * 0.32f, cy - r * 0.32f); path.lineTo(cx + r * 0.32f, cy + r * 0.32f); path.moveTo(cx + r * 0.32f, cy - r * 0.32f); path.lineTo(cx - r * 0.32f, cy + r * 0.32f) }
                val pm = PathMeasure(path, false); var len = 0f; do { len += pm.length } while (pm.nextContour())
                val pm2 = PathMeasure(path, false); var left = len * prog
                seg.reset()
                do { val l = pm2.length; if (left <= 0f) break; pm2.getSegment(0f, min(l, left), seg, true); left -= l } while (pm2.nextContour())
                cv.drawPath(seg, p)
            }
        }
        if (ps.isNotEmpty() || checkT >= 0f) postInvalidateOnAnimation()
    }
}

/** Lingkaran loading berputar (gradasi biru-ungu-cyan). Selalu bergerak, tidak bergantung pada saklar "Efek latar". */
class SpinnerView(c: Context) : View(c) {
    private val d = c.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val rect = RectF()
    private val m = Matrix()
    private var sh: SweepGradient? = null
    private var t0 = 0L

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        p.strokeWidth = 4.5f * d
        val pad = p.strokeWidth
        rect.set(pad, pad, w - pad, h - pad)
        sh = SweepGradient(w / 2f, h / 2f,
            intArrayOf(0x003D6BFF, Color.parseColor("#3D6BFF"), Color.parseColor("#9B4DFF"), Color.parseColor("#35D6FF")), floatArrayOf(0f, 0.45f, 0.8f, 1f))
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); t0 = System.nanoTime() }

    override fun onDraw(cv: Canvas) {
        val s = sh ?: return
        val ang = ((System.nanoTime() - t0) / 1e9f * 520f) % 360f
        m.setRotate(ang, width / 2f, height / 2f); s.setLocalMatrix(m)
        p.shader = s
        cv.drawArc(rect, 0f, 360f, false, p)
        postInvalidateOnAnimation()
    }
}
