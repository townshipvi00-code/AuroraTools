package com.aurorats.tools

import java.io.ByteArrayOutputStream

/**
 * Codec file XML game Township:
 *   decode : 0x79 (XOR + delta, tabel MurmurHash2) -> [frame LZ4 opsional] -> XML polos
 *   encode : XML polos -> frame LZ4 (magic 04224D18 + ukuran asli) -> 0x79
 */
object AuroraCodec {
    private const val TABLE_SIZE = 0x2D7
    private const val DEFAULT_SEED = 0x12345678
    @Volatile var lastSeed: Int = DEFAULT_SEED
    @Volatile var lastHashLength: Int = 0
    /** Ukuran isi (setelah 0x79) save asli bila berisi padding nol di ekor (game memakai berkas berukuran tetap); 0 = tanpa padding. */
    @Volatile var lastPadTo: Int = 0

    fun isXml(b: ByteArray): Boolean {
        if (b.isEmpty()) return false
        var i = 0
        if (b.size >= 3 && (b[0].toInt() and 0xFF) == 0xEF && (b[1].toInt() and 0xFF) == 0xBB && (b[2].toInt() and 0xFF) == 0xBF) i = 3
        else if (b.size >= 2 && (b[0].toInt() and 0xFF) == 0xFF && (b[1].toInt() and 0xFF) == 0xFE) return true
        else if (b.size >= 2 && (b[0].toInt() and 0xFF) == 0xFE && (b[1].toInt() and 0xFF) == 0xFF) return true
        while (i < b.size && (b[i] == ' '.code.toByte() || b[i] == '\t'.code.toByte() || b[i] == '\r'.code.toByte() || b[i] == '\n'.code.toByte())) i++
        return i < b.size && b[i] == '<'.code.toByte()
    }

    fun is0x79(b: ByteArray): Boolean = b.size >= 8 && (b[0].toInt() and 0xFF) == 0x79

    fun isLz4(b: ByteArray): Boolean = b.size >= 8 && b[0] == 0x04.toByte() && b[1] == 0x22.toByte() && b[2] == 0x4D.toByte() && b[3] == 0x18.toByte()

    /** Decode berkas Township: tangani 0x79, LZ4 frame, GZIP, ZLIB, atau kombinasi keduanya. */
    fun decode(bytes: ByteArray): ByteArray {
        var cur = bytes
        for (round in 0 until 5) {
            if (isXml(cur)) return finish(cur)
            if (isLz4(cur)) {
                cur = try { lz4Frame(cur) } catch (_: Exception) { break }
            } else if (is0x79(cur)) {
                cur = try { decode79(cur) } catch (_: Exception) { break }
                lastPadTo = if (cur.isNotEmpty() && cur[cur.size - 1] == 0.toByte()) cur.size else 0
            } else if (cur.size >= 2 && cur[0] == 0x1f.toByte() && cur[1] == 0x8b.toByte()) {
                val u = try { java.util.zip.GZIPInputStream(cur.inputStream()).use { it.readBytes() } } catch (_: Exception) { null }
                if (u != null) cur = u else break
            } else if (cur.size >= 2 && (cur[0].toInt() and 0x0f) == 8 && (((cur[0].toInt() and 0xff) shl 8) or (cur[1].toInt() and 0xff)) % 31 == 0) {
                val u = try {
                    val inf = java.util.zip.Inflater(false); inf.setInput(cur)
                    val o = java.io.ByteArrayOutputStream(); val buf = ByteArray(8192)
                    while (!inf.finished()) { val n = inf.inflate(buf); if (n == 0 && (inf.needsInput() || inf.needsDictionary())) break; o.write(buf, 0, n) }
                    inf.end(); if (o.size() > 0) o.toByteArray() else null
                } catch (_: Exception) { null }
                if (u != null) cur = u else break
            } else {
                break
            }
        }
        if (isXml(cur)) return finish(cur)
        throw Exception("Format bukan XML Township yang dikenali (byte awal: 0x${if (cur.isNotEmpty()) "%02x".format(cur[0]) else "--"})")
    }

    /** Encode XML polos menjadi format Township terenkripsi (LZ4 frame + 0x79 MurmurHash2 table). */
    fun encode(xml: ByteArray, customSeed: Int = lastSeed, customHashLength: Int = lastHashLength): ByteArray {
        var end = xml.size
        while (end > 0 && xml[end - 1] == 0.toByte()) end--
        val payload = xml.copyOf(end)
        val block = lz4Compress(payload)
        val frame0 = ByteArray(8 + block.size)
        frame0[0] = 0x04; frame0[1] = 0x22; frame0[2] = 0x4D; frame0[3] = 0x18
        putLE32(frame0, 4, payload.size)
        System.arraycopy(block, 0, frame0, 8, block.size)
        // Samakan ukuran dengan save asli (berkas game berukuran tetap, sisa diisi nol); bila lebih besar, biarkan.
        val frame = if (lastPadTo > frame0.size) frame0.copyOf(lastPadTo) else frame0
        val sz = frame.size
        val hashLength = if (customHashLength > 0) customHashLength else (((sz xor 0x396A8) + ((sz + 8) xor 0xC5EED)) and 0xFFFFFF)
        val seed = if (customSeed != 0) customSeed else DEFAULT_SEED
        return encode79(frame, hashLength, seed)
    }

    fun encodeLz4Only(xml: ByteArray): ByteArray {
        var end = xml.size
        while (end > 0 && xml[end - 1] == 0.toByte()) end--
        val payload = xml.copyOf(end)
        val block = lz4Compress(payload)
        val frame = ByteArray(8 + block.size)
        frame[0] = 0x04; frame[1] = 0x22; frame[2] = 0x4D; frame[3] = 0x18
        putLE32(frame, 4, payload.size)
        System.arraycopy(block, 0, frame, 8, block.size)
        return frame
    }

    private fun finish(b: ByteArray): ByteArray {
        var end = b.size
        while (end > 0 && b[end - 1] == 0.toByte()) end--
        return if (end == b.size) b else b.copyOf(end)
    }

    private fun putLE32(a: ByteArray, o: Int, v: Int) {
        a[o] = v.toByte()
        a[o + 1] = (v ushr 8).toByte()
        a[o + 2] = (v ushr 16).toByte()
        a[o + 3] = (v ushr 24).toByte()
    }

    private fun getLE32(a: ByteArray, o: Int): Int =
        (a[o].toInt() and 0xFF) or
        ((a[o + 1].toInt() and 0xFF) shl 8) or
        ((a[o + 2].toInt() and 0xFF) shl 16) or
        ((a[o + 3].toInt() and 0xFF) shl 24)

    private fun mmh2of4(data: Int, seed: Int): Int {
        val m = 0x5BD1E995
        var h = seed xor 4
        var k = data * m
        k = k xor (k ushr 24)
        k *= m
        h *= m
        h = h xor k
        h = h xor (h ushr 13)
        h *= m
        h = h xor (h ushr 15)
        return h
    }

    private fun hashTable(length: Int, seed: Int): ByteArray {
        val t = ByteArray(TABLE_SIZE)
        var h = seed
        var i = 0
        while (i < TABLE_SIZE) {
            h = mmh2of4(h, length)
            var j = 0
            while (j < 4 && i + j < TABLE_SIZE) {
                t[i + j] = (h ushr (8 * j)).toByte()
                j++
            }
            i += 4
        }
        return t
    }

    fun decode79(bytes: ByteArray): ByteArray {
        val hashLength = (bytes[1].toInt() and 0xFF) or ((bytes[2].toInt() and 0xFF) shl 8) or ((bytes[3].toInt() and 0xFF) shl 16)
        val seed = getLE32(bytes, 4)
        lastSeed = seed
        lastHashLength = hashLength
        val table = hashTable(hashLength, seed + 4)
        val out = ByteArray(bytes.size - 8)
        System.arraycopy(bytes, 8, out, 0, out.size)
        var j = 0
        for (i in out.indices) {
            if (i > 0) out[i] = (out[i] - out[i - 1]).toByte()
            out[i] = (out[i].toInt() xor (table[j].toInt() and 0xFF)).toByte()
            if (++j == TABLE_SIZE) j = 0
        }
        return out
    }

    fun encode79(src: ByteArray, hashLength: Int, seed: Int): ByteArray {
        val out = ByteArray(8 + src.size)
        out[0] = 0x79.toByte()
        out[1] = hashLength.toByte()
        out[2] = (hashLength ushr 8).toByte()
        out[3] = (hashLength ushr 16).toByte()
        putLE32(out, 4, seed)
        val table = hashTable(hashLength, seed + 4)
        var prev = 0
        var j = 0
        for (i in src.indices) {
            val curr = src[i].toInt() and 0xFF
            out[8 + i] = (prev + (curr xor (table[j].toInt() and 0xFF))).toByte()
            prev = curr
            if (++j == TABLE_SIZE) j = 0
        }
        return out
    }

    private fun lz4Frame(b: ByteArray): ByteArray {
        val rawSize = getLE32(b, 4)
        return lz4Decompress(b, 8, rawSize)
    }

    private fun lz4Decompress(src: ByteArray, startOffset: Int, expected: Int): ByteArray {
        var s = startOffset
        val n = src.size
        val out = ByteArray(expected)
        var o = 0
        while (s < n && o < expected) {
            val token = src[s++].toInt() and 0xFF
            var lit = token ushr 4
            if (lit == 15) {
                var x: Int
                do {
                    if (s >= n) throw Exception("LZ4 rusak")
                    x = src[s++].toInt() and 0xFF
                    lit += x
                } while (x == 255)
            }
            if (s + lit > n || o + lit > expected) throw Exception("LZ4 rusak (literal)")
            System.arraycopy(src, s, out, o, lit)
            s += lit
            o += lit
            if (s >= n || o >= expected) break
            if (s + 2 > n) throw Exception("LZ4 rusak (offset)")
            val off = (src[s].toInt() and 0xFF) or ((src[s + 1].toInt() and 0xFF) shl 8)
            s += 2
            if (off == 0 || off > o) throw Exception("LZ4 rusak (offset tidak valid)")
            var ml = token and 15
            if (ml == 15) {
                var x: Int
                do {
                    if (s >= n) throw Exception("LZ4 rusak")
                    x = src[s++].toInt() and 0xFF
                    ml += x
                } while (x == 255)
            }
            ml += 4
            if (o + ml > expected) ml = expected - o
            val from = o - off
            for (k in 0 until ml) out[o++] = out[from + k]
        }
        if (o != expected) throw Exception("Ukuran hasil LZ4 tidak cocok ($o vs $expected)")
        return out
    }

    private fun hash4(a: ByteArray, i: Int): Int = (getLE32(a, i) * -1640531535) ushr 16

    private fun writeLen(o: ByteArrayOutputStream, lengthVal: Int) {
        var len = lengthVal
        while (len >= 255) {
            o.write(255)
            len -= 255
        }
        o.write(len)
    }

    private fun lz4Compress(src: ByteArray): ByteArray {
        val n = src.size
        val o = ByteArrayOutputStream(n / 4 + 64)
        var anchor = 0
        var i = 0
        if (n >= 13) {
            val table = IntArray(1 shl 16) { -1 }
            val mfLimit = n - 12
            val matchEnd = n - 5
            while (i < mfLimit) {
                val h = hash4(src, i)
                val ref = table[h]
                table[h] = i
                if (ref >= 0 && i - ref < 65536 && getLE32(src, ref) == getLE32(src, i)) {
                    var m = 4
                    while (i + m < matchEnd && src[ref + m] == src[i + m]) m++
                    val lit = i - anchor
                    val ml = m - 4
                    o.write(((if (lit >= 15) 15 else lit) shl 4) or (if (ml >= 15) 15 else ml))
                    if (lit >= 15) writeLen(o, lit - 15)
                    o.write(src, anchor, lit)
                    val off = i - ref
                    o.write(off and 0xFF)
                    o.write(off ushr 8)
                    if (ml >= 15) writeLen(o, ml - 15)
                    i += m
                    anchor = i
                } else {
                    i++
                }
            }
        }
        val lit = n - anchor
        o.write((if (lit >= 15) 15 else lit) shl 4)
        if (lit >= 15) writeLen(o, lit - 15)
        o.write(src, anchor, lit)
        return o.toByteArray()
    }
}
