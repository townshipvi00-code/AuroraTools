package com.aurorats.tools

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.*
import kotlin.random.Random

/**
 * Latar Aurora ultra-lancar 60 FPS:
 * Dioptimalkan khusus untuk ruang virtual (VPhoneOS, VMOS) & HP asli.
 * Menggunakan kurva Bezier perangkat keras tanpa drawVertices (bebas crash),
 * bebas alokasi memori pada loop onDraw (anti-stuttering/jank).
 */
class AuroraBackground(c: Context) : View(c) {
    private val d = c.resources.displayMetrics.density
    private val pFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val pStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val pStar = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val pOrb = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    private val wavePath1 = Path()
    private val wavePath2 = Path()
    private val wavePath3 = Path()

    private val BLUE = Color.parseColor("#3D6BFF")
    private val PURPLE = Color.parseColor("#9B4DFF")
    private val CYAN = Color.parseColor("#35D6FF")
    private val PINK = Color.parseColor("#E26BFF")

    private var bgShader: LinearGradient? = null
    private var waveShader1: LinearGradient? = null
    private var waveShader2: LinearGradient? = null
    private var waveShader3: LinearGradient? = null

    // 24 bintang pre-allocated (x, y, phase, radius)
    private val stars = List(24) {
        floatArrayOf(
            Random.nextFloat(),
            Random.nextFloat(),
            Random.nextFloat() * 6.28f,
            0.8f + Random.nextFloat() * 1.5f
        )
    }

    private class Orb(var x: Float, var y: Float, val r: Float, val sp: Float, val ph: Float, val col: Int)
    private val orbCols = intArrayOf(CYAN, PURPLE, BLUE, PINK)
    // 8 partikel melayang (ringan untuk virtual display)
    private val orbs = List(8) {
        Orb(Random.nextFloat(), Random.nextFloat(), 1.5f + Random.nextFloat() * 2f, 0.02f + Random.nextFloat() * 0.04f, Random.nextFloat() * 6.28f, orbCols[it % 4])
    }

    private var t = 0f
    private var last = 0L

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w > 0 && h > 0) {
            bgShader = LinearGradient(0f, 0f, 0f, h.toFloat(),
                intArrayOf(Color.parseColor("#060914"), Color.parseColor("#0E1634"), Color.parseColor("#070B1A")),
                null, Shader.TileMode.CLAMP)

            waveShader1 = LinearGradient(0f, 0f, w.toFloat(), h * 0.5f,
                intArrayOf(Color.parseColor("#3035D6FF"), Color.parseColor("#153D6BFF"), Color.TRANSPARENT),
                null, Shader.TileMode.CLAMP)

            waveShader2 = LinearGradient(w.toFloat(), 0f, 0f, h * 0.65f,
                intArrayOf(Color.parseColor("#359B4DFF"), Color.parseColor("#18E26BFF"), Color.TRANSPARENT),
                null, Shader.TileMode.CLAMP)

            waveShader3 = LinearGradient(0f, h * 0.2f, w.toFloat(), h * 0.8f,
                intArrayOf(Color.parseColor("#283D6BFF"), Color.parseColor("#2035D6FF"), Color.TRANSPARENT),
                null, Shader.TileMode.CLAMP)
        }
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val now = System.nanoTime()
        val dt = if (last == 0L) 0.016f else ((now - last) / 1e9f).coerceIn(0.008f, 0.033f)
        last = now

        val fx = S.effects
        if (fx) t += dt * 0.65f

        // 1. Gambar latar gradasi bersih & cepat
        val bg = bgShader
        if (bg != null) {
            pFill.shader = bg
            cv.drawRect(0f, 0f, w, h, pFill)
            pFill.shader = null
        } else {
            cv.drawColor(Color.parseColor("#070B18"))
        }

        // 2. Gambar pita gelombang aurora dengan Bezier Curve hardware-accelerated
        if (fx) {
            drawWave(cv, wavePath1, waveShader1, w, h, 0.22f, 0.05f, 1.4f, 0.8f, t * 0.8f)
            drawWave(cv, wavePath2, waveShader2, w, h, 0.38f, 0.06f, 1.1f, -0.6f, t * 0.6f)
            drawWave(cv, wavePath3, waveShader3, w, h, 0.52f, 0.045f, 1.6f, 0.5f, t * 0.7f)
        }

        // 3. Bintang berkelip halus
        for (s in stars) {
            val a = if (fx) (120 + 130 * sin(t * 2.5f + s[2])).toInt().coerceIn(40, 255) else 160
            val px = s[0] * w
            val py = s[1] * h
            pStar.color = Color.WHITE
            pStar.alpha = a
            cv.drawCircle(px, py, s[3] * d, pStar)
        }

        // 4. Partikel cahaya melayang (orbs)
        if (fx) {
            for (o in orbs) {
                o.y -= o.sp * dt
                if (o.y < -0.05f) {
                    o.y = 1.05f
                    o.x = Random.nextFloat()
                }
                val ox = o.x * w + sin(t * 0.7f + o.ph) * 10f * d
                val oy = o.y * h
                val fade = sin(PI.toFloat() * o.y.coerceIn(0f, 1f))
                val alpha = (fade * 180).toInt().coerceIn(0, 255)

                pOrb.color = o.col
                pOrb.alpha = alpha
                cv.drawCircle(ox, oy, o.r * d * 1.5f, pOrb)
            }
            postInvalidateOnAnimation()
        }
    }

    private fun drawWave(cv: Canvas, path: Path, shader: Shader?, w: Float, h: Float,
                         baseY: Float, amp: Float, freq: Float, spd: Float, time: Float) {
        if (shader == null) return
        path.reset()

        val y0 = h * baseY + h * amp * sin(time * spd)
        val y1 = h * baseY + h * amp * sin(time * spd + 1.8f * freq)
        val y2 = h * baseY + h * amp * sin(time * spd + 3.6f * freq)
        val y3 = h * baseY + h * amp * sin(time * spd + 5.2f * freq)

        path.moveTo(0f, y0)
        path.cubicTo(w * 0.33f, y1, w * 0.66f, y2, w, y3)
        path.lineTo(w, h * (baseY + 0.28f))
        path.cubicTo(w * 0.66f, h * (baseY + 0.26f) + y2 * 0.2f,
                     w * 0.33f, h * (baseY + 0.27f) + y1 * 0.2f,
                     0f, h * (baseY + 0.28f))
        path.close()

        pFill.shader = shader
        cv.drawPath(path, pFill)
        pFill.shader = null
    }

    fun refresh() { invalidate() }
}
