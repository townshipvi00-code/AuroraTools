package com.aurorats.tools

import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * Klien lisensi AuroraToolsTS:
 * Mendukung login lisensi penuh di ruang virtual VPhoneOS (versi Play Store & APK)
 * serta verifikasi offline cerdas tanpa terhambat status server.
 */
object License {
    class Result(val ok: Boolean, val error: String?)

    val MASTER_KEYS = setOf(
        "VIP-26122005-LIFE",
        "VIP-12072005-LIFE",
        "VPHONE-VIP-LIFE",
        "VIP-AURORA-LIFE",
        "AURORA-VIP-LIFE",
        "AURORA-2026-LIFE",
        "VIP-TOWNSHIP-LIFE",
        "TOWNSHIP-VIP-LIFE",
        "VPHONEOS-VIP-2026",
        "AURORA-PRO-VIP",
        "VPHONEOS-60FPS-VIP",
        "AURORA-VPHONE-2026",
        "VPHONE-PLAYSTORE-VIP",
        "AURORA-LIFETIME-VIP"
    )

    /**
     * Memeriksa apakah kunci lisensi valid untuk aktivasi VIP.
     * Menerima format VIP standar, master keys, format VPHONE, maupun lisensi kustom.
     */
    fun isMasterOrVip(key: String): Boolean {
        val clean = key.trim().uppercase()
        if (clean.length < 3) return false
        if (clean in MASTER_KEYS) return true
        if (clean.startsWith("VIP") || clean.startsWith("VPHONE") || clean.startsWith("AURORA") ||
            clean.startsWith("TOWNSHIP") || clean.startsWith("TS") || clean.startsWith("PRO") ||
            clean.startsWith("LIFE")) return true
        // Kunci alphanumeric dengan panjang >= 4 karakter dianggap valid untuk VphoneOS
        if (clean.length >= 4 && clean.matches(Regex("^[A-Z0-9_.-]+$"))) return true
        return clean.length >= 4
    }

    fun deviceId(c: Context): String {
        val raw = try {
            val aid = Settings.Secure.getString(c.contentResolver, Settings.Secure.ANDROID_ID)
            if (!aid.isNullOrBlank()) aid else "${Build.BRAND}-${Build.MODEL}-${Build.HARDWARE}"
        } catch (_: Exception) {
            "${Build.BRAND}-${Build.MODEL}"
        }
        return try {
            MessageDigest.getInstance("SHA-256")
                .digest((c.packageName + raw).toByteArray())
                .joinToString("") { "%02x".format(it) }
        } catch (_: Exception) {
            raw.hashCode().toString()
        }
    }

    /**
     * Panggilan verifikasi lisensi (thread latar).
     * Jika server Render tidak aktif / 404 atau VphoneOS offline, kunci valid tetap diterima sebagai VIP Lifetime.
     */
    fun call(c: Context, path: String, key: String): Result {
        val clean = key.trim().uppercase()
        if (clean.isEmpty()) return Result(false, "empty")
        if (isMasterOrVip(clean)) return Result(true, null)

        return try {
            val srv = c.getString(R.string.license_server)
            val u = URL(srv + path)
            val con = (u.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                connectTimeout = 4000
                readTimeout = 4000
                setRequestProperty("Content-Type", "application/json")
            }
            con.outputStream.use {
                it.write(JSONObject().put("key", clean).put("device", deviceId(c)).toString().toByteArray())
            }
            val code = con.responseCode
            val stream = if (code in 200..299) con.inputStream else con.errorStream
            val body = stream?.bufferedReader()?.readText().orEmpty()
            
            try {
                val j = JSONObject(body)
                val ok = j.optBoolean("ok", false)
                val err = if (j.isNull("error")) null else j.optString("error")
                if (ok) Result(true, null)
                else if (clean.length >= 4) Result(true, null) // fallback ramah VphoneOS
                else Result(false, err)
            } catch (_: Exception) {
                // Respons non-JSON (seperti 404 Not Found dari Render): tetap izinkan jika format kunci wajar
                if (clean.length >= 3) Result(true, null) else Result(false, "invalid")
            }
        } catch (e: Exception) {
            // Server offline atau tidak ada koneksi di VphoneOS: tetap berikan akses jika kunci wajar
            if (clean.length >= 3) Result(true, null) else Result(false, "neterr")
        }
    }

    private fun async(c: Context, path: String, key: String, cb: (Result) -> Unit) {
        val ui = Handler(Looper.getMainLooper())
        Thread {
            val r = call(c, path, key)
            ui.post { cb(r) }
        }.start()
    }

    fun activate(c: Context, key: String, cb: (Result) -> Unit) = async(c, "/activate", key, cb)

    fun verify(c: Context, key: String, cb: (Result) -> Unit) {
        val clean = key.trim().uppercase()
        if (isMasterOrVip(clean)) {
            cb(Result(true, null))
            return
        }
        async(c, "/verify", key, cb)
    }

    class Update(val code: Long, val name: String, val url: String)

    /** Cek versi terbaru di server. Tidak pernah melempar pengecualian. */
    fun latest(c: Context, cb: (Update?) -> Unit) {
        val ui = Handler(Looper.getMainLooper())
        Thread {
            val u = try {
                val con = (URL(c.getString(R.string.license_server) + "/version").openConnection() as HttpURLConnection).apply {
                    connectTimeout = 3000
                    readTimeout = 3000
                }
                val j = JSONObject(con.inputStream.bufferedReader().readText())
                Update(j.optLong("version_code"), j.optString("version_name"), j.optString("url"))
            } catch (_: Throwable) { null }
            ui.post { cb(u) }
        }.start()
    }

    fun checkUpdate(c: Context, cb: (Update?) -> Unit) = latest(c, cb)
}
