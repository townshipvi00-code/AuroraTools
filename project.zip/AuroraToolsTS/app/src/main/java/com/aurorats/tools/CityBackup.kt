package com.aurorats.tools

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Cadangan, pemulihan & pengambilan (fetch) data kota Township di dalam ruang virtual.
 * Nama berkas: township_YYYYMMDD_HHMMSS_<label>.tar|zip  (label: manual, auto, pengaman, atau catatan sendiri).
 */
object CityBackup {
    class Result(val ok: Boolean, val message: String)
    class Info(val file: File, val time: Long, val label: String) { val ext: String get() = file.extension }

    private const val KEEP_AUTO = 10
    private val AUTO_LABELS = setOf("auto", "pengaman")
    private val NAME = Regex("""township_(\d{8}_\d{6})(?:_([a-z0-9-]+))?\.(?:tar|zip)""")

    private val SRC = "/data/data/${GameBridge.PACKAGE}"
    private fun stampFmt() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
    private fun stamp() = stampFmt().format(Date())
    private fun root(c: Context) = File(c.getExternalFilesDir(null) ?: c.filesDir, "AuroraTS").apply { mkdirs() }
    fun backupDir(c: Context) = File(root(c), "backup").apply { mkdirs() }
    fun fetchDir(c: Context) = File(root(c), "fetch").apply { mkdirs() }

    private fun gateMsg(@Suppress("UNUSED_PARAMETER") g: Env.Gate) = S.t("gateVirt")
    private fun useRoot() = Env.rootVerified == true
    private fun clean(l: String) = l.lowercase(Locale.US).replace(Regex("[^a-z0-9-]"), "").take(20)

    fun size(b: Long) = if (b >= 1_048_576) "%.1f MB".format(Locale.US, b / 1_048_576.0) else "${maxOf(1, b / 1024)} KB"

    /** Semua cadangan, terbaru di atas. */
    fun list(c: Context): List<Info> = backupDir(c).listFiles { f -> f.isFile && (f.extension == "tar" || f.extension == "zip") }.orEmpty().map { f ->
        val m = NAME.matchEntire(f.name)
        val t = m?.groupValues?.get(1)?.let { try { stampFmt().parse(it)?.time } catch (_: Exception) { null } } ?: f.lastModified()
        Info(f, t, m?.groupValues?.get(2)?.ifEmpty { null } ?: "manual")
    }.sortedByDescending { it.time }

    fun delete(i: Info): Boolean = i.file.delete()

    /** Jumlah entri di dalam cadangan; -1 bila tidak bisa dihitung. */
    private fun count(f: File): Int =
        if (f.extension == "zip") try { java.util.zip.ZipFile(f).use { it.size() } } catch (_: Exception) { 0 }
        else RootShell.exec("tar -tf '${f.absolutePath}'", 30_000)?.text?.lines()?.count { it.isNotBlank() } ?: -1

    /** Hapus cadangan otomatis yang lama (sisakan 10 terbaru). Cadangan manual dan cadangan paling lama (asli) tidak pernah dihapus. */
    private fun prune(c: Context) {
        val all = list(c); val oldest = all.lastOrNull()
        all.filter { it.label in AUTO_LABELS && it !== oldest }.drop(KEEP_AUTO).forEach { it.file.delete() }
    }

    private fun finish(c: Context, out: File, doPrune: Boolean): Result {
        val n = count(out)
        if (n == 0 || out.length() == 0L) { out.delete(); return Result(false, S.t("backupFail")) }
        if (doPrune) prune(c)
        val files = if (n > 0) "$n ${if (S.lang == "id") "berkas" else "files"} • " else ""
        return Result(true, "${S.t("backupOk")}\n${out.name}\n$files${size(out.length())}")
    }

    /** Cadangan data game (files + shared_prefs + databases bila ada). Root -> .tar; tanpa root -> .zip lewat akses file langsung. */
    fun backup(c: Context, label: String = "manual", doPrune: Boolean = true): Result {
        val g = Env.gate(c); if (g != Env.Gate.OK) return Result(false, gateMsg(g))
        val base = "township_${stamp()}_${clean(label).ifEmpty { "manual" }}"
        if (useRoot()) {
            val ls = RootShell.exec("ls $SRC")
            val parts = ls?.text?.lines()?.map { it.trim() }?.filter { it in GameFiles.PARTS }.orEmpty()
            if (parts.isNotEmpty()) {
                val out = File(backupDir(c), "$base.tar")
                if (RootShell.pipeTo("tar -cf - -C $SRC ${parts.joinToString(" ")}", out)) return finish(c, out, doPrune)
            }
        }
        val dir = GameFiles.dataDir(c) ?: return Result(false, S.t("noAccess"))
        val out = File(backupDir(c), "$base.zip")
        return if (GameFiles.zipTo(dir, GameFiles.parts(dir), out)) finish(c, out, doPrune) else Result(false, S.t("backupFail"))
    }

    /** Pulihkan data game dari satu cadangan. Cadangan pengaman dibuat dulu supaya pemulihan bisa dibatalkan. */
    fun restore(c: Context, file: File): Result {
        val g = Env.gate(c); if (g != Env.Gate.OK) return Result(false, gateMsg(g))
        if (!file.isFile) return Result(false, if (S.lang == "id") "Cadangan tidak ditemukan" else "Backup not found")
        val safety = backup(c, "pengaman", doPrune = false)
        if (!safety.ok) return Result(false, (if (S.lang == "id") "Cadangan pengaman gagal, pemulihan dibatalkan.\n" else "Safety backup failed, restore cancelled.\n") + safety.message)
        var done = false
        if (useRoot()) {
            RootShell.exec("am force-stop ${GameBridge.PACKAGE}")
            if (file.extension == "tar") {
                val own = RootShell.exec("stat -c %u:%g $SRC")?.text?.trim()
                val r = RootShell.exec("tar -xf '${file.absolutePath}' -C $SRC", 120_000)
                if (r != null && r.code == 0) {
                    if (own != null && Regex("\\d+:\\d+").matches(own)) RootShell.exec("chown -R $own $SRC/files $SRC/shared_prefs $SRC/databases $SRC/saves 2>/dev/null")
                    done = true
                }
            }
        }
        if (!done) {
            val dir = GameFiles.dataDir(c) ?: return Result(false, S.t("noAccess"))
            if (file.extension != "zip") return Result(false, if (S.lang == "id") "Cadangan .tar hanya bisa dipulihkan dengan root" else ".tar backups need root to restore")
            try {
                var n = 0
                java.util.zip.ZipInputStream(file.inputStream().buffered()).use { z ->
                    var e = z.nextEntry
                    while (e != null) {
                        val out = File(dir, e.name)
                        if (!e.isDirectory && out.canonicalPath.startsWith(dir.canonicalPath + File.separator)) { out.parentFile?.mkdirs(); out.outputStream().use { z.copyTo(it) }; n++ }
                        z.closeEntry(); e = z.nextEntry
                    }
                }
                if (n == 0) return Result(false, if (S.lang == "id") "Cadangan kosong" else "Backup is empty")
            } catch (e: Exception) { return Result(false, "${if (S.lang == "id") "Gagal memulihkan" else "Restore failed"}: ${e.message}") }
        }
        prune(c)
        StatsEngine.disconnect()   // sesi lama sudah usang setelah data dipulihkan
        val v = StatsEngine.load(c, fromDisk = true)
        val chk = if (S.lang == "id") "Verifikasi: ${v.values.size}/${Stats.LIST.size} nilai terbaca" else "Verified: ${v.values.size}/${Stats.LIST.size} values readable"
        val warn = if (v.values.isEmpty()) "\n" + (if (S.lang == "id") "Peringatan: save belum terbaca, coba buka Township sekali." else "Warning: save not readable yet, try opening Township once.") else ""
        val undo = if (S.lang == "id") "Cadangan pengaman: ${safety.message.lines().getOrNull(1) ?: "-"}\nBuka Township lagi." else "Safety backup: ${safety.message.lines().getOrNull(1) ?: "-"}\nOpen Township again."
        return Result(true, "${if (S.lang == "id") "Cadangan dipulihkan" else "Backup restored"}: ${file.name}\n$chk$warn\n$undo")
    }

    /** Ambil file save kota (mGameInfo.xml) ke folder fetch. Root bila ada, kalau tidak lewat akses file langsung. */
    fun fetch(c: Context): Result {
        val g = Env.gate(c); if (g != Env.Gate.OK) return Result(false, gateMsg(g))
        val dir = File(fetchDir(c), stamp()).apply { mkdirs() }
        val lines = ArrayList<String>()
        if (useRoot()) {
            val found = RootShell.exec("find $SRC -name mGameInfo.xml")?.text?.lines()?.map { it.trim() }?.filter { it.startsWith(SRC) }.orEmpty()
            found.forEachIndexed { i, path ->
                val f = File(dir, if (i == 0) "mGameInfo.xml" else "mGameInfo_$i.xml")
                if (RootShell.pipeTo("cat '$path'", f, 30_000)) lines.add("${f.name} (${f.length() / 1024} KB)")
            }
        }
        if (lines.isEmpty()) {
            val src = GameFiles.dataDir(c)
            if (src == null) { dir.delete(); return Result(false, S.t("noAccess")) }
            GameFiles.find(src, "mGameInfo.xml").forEachIndexed { i, f ->
                val o = File(dir, if (i == 0) "mGameInfo.xml" else "mGameInfo_$i.xml")
                try { f.copyTo(o, true); lines.add("${o.name} (${o.length() / 1024} KB)") } catch (_: Exception) {}
            }
        }
        if (lines.isEmpty()) { dir.delete(); return Result(false, S.t("noGameData")) }
        return Result(true, "${S.t("fetchOk")}\n${lines.joinToString("\n")}\n${dir.absolutePath}")
    }
}
