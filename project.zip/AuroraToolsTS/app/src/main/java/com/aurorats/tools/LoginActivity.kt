package com.aurorats.tools

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.text.TextUtils
import android.view.*
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*

/** Layar login key. Key diperiksa server & diikat ke perangkat; masa aktif diatur di server (lifetime = tanpa batas). */
class LoginActivity : Activity() {
    private var destroyed = false
    private var busy = false
    private var keyField: EditText? = null
    private lateinit var sp: android.content.SharedPreferences
    private val ui = Handler(Looper.getMainLooper())
    private var autoplay: Runnable? = null
    private var refreshBtn: (() -> Unit)? = null
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    companion object {
        /** Isi kolom key dipertahankan saat tema/bahasa diganti (activity dibuat ulang). */
        private var draft = ""
        /** Hitungan gagal & waktu kunci bertahan saat activity dibuat ulang (ganti tema/bahasa/rotasi). */
        private var fails = 0
        private var lockUntil = 0L
        private var firstShow = true
    }

    private class Pal(
        val bg: Int, val card: Int, val cardStroke: Int, val text: Int, val sub: Int, val accent: Int,
        val chip: Int, val pill: Int, val lang: Int, val langStroke: Int, val langSel: Int,
        val panel: Int, val panelStroke: Int, val iconBg: Int, val circle: Int, val dotOff: Int
    )
    private val DAY = Pal(
        bg = c("#F4F8FC"), card = c("#FFFFFF"), cardStroke = c("#DCE8F3"), text = c("#0F1A2B"), sub = c("#6B7A8C"), accent = c("#0A84C6"),
        chip = c("#D6EAF7"), pill = c("#F7FAFD"), lang = c("#EEF2F8"), langStroke = c("#D9E1EC"), langSel = c("#DDF0FA"),
        panel = c("#EEF3FA"), panelStroke = c("#7CC4EA"), iconBg = c("#D3ECF6"), circle = c("#FFFFFF"), dotOff = c("#9ED3EE")
    )
    private val NIGHT = Pal(
        bg = c("#070B18"), card = c("#121A33"), cardStroke = c("#26325A"), text = c("#F2F5FF"), sub = c("#9AA7C7"), accent = c("#4DB8FF"),
        chip = c("#1B3350"), pill = c("#141C38"), lang = c("#1A2344"), langStroke = c("#2B3868"), langSel = c("#173A5A"),
        panel = c("#0F1730"), panelStroke = c("#2D6A96"), iconBg = c("#173A5A"), circle = c("#1A2344"), dotOff = c("#2D4F72")
    )
    private fun c(s: String) = Color.parseColor(s)
    private val GREEN = Color.parseColor("#1DBF73")
    private val ERR = Color.parseColor("#E5484D")
    private val OK = Color.parseColor("#12A150")

    /** Teks khusus layar ini (ID / EN). */
    private fun tx(k: String): String {
        val id = S.lang == "id"
        return when (k) {
            "gate" -> "AURORA SECURE GATE"
            "tagline" -> if (id) "Solusi Lengkap VIP Township Anda" else "Your Complete VIP Township Solution"
            "card" -> if (id) "MASUK KE AKUN" else "SIGN IN TO ACCOUNT"
            "keyLabel" -> if (id) "Masukkan kunci lisensi Anda" else "Enter your license key"
            "remember" -> if (id) "Ingat kunci" else "Remember key"
            "langHead" -> if (id) "BAHASA" else "LANGUAGE"
            "langName" -> if (id) "Bahasa" else "English"
            "langSoon" -> if (id) "Bahasa ini segera hadir" else "This language is coming soon"
            "featHead" -> if (id) "FITUR TOWNSHIP TOOL" else "TOWNSHIP TOOL FEATURES"
            "vip" -> "VIP FEATURE"
            "tap" -> if (id) "Tap untuk lihat" else "Tap to view"
            "needLogin" -> if (id) "Masuk dulu untuk memakai fitur ini" else "Sign in first to use this feature"
            "premium" -> if (id) "Coba Premium (Gratis)" else "Try Premium (Free)"
            "premiumSub" -> if (id) "Rasakan fitur & alat VIP tanpa risiko" else "Experience VIP features & tools risk-free"
            "premiumMsg" -> if (id) "Percobaan gratis belum tersedia. Hubungi admin untuk mendapatkan key." else "Free trial is not available yet. Contact the admin to get a key."
            "reset" -> if (id) "Ganti HP" else "New phone"
            "perm" -> if (id) "BERIKAN IZIN" else "GRANT PERMISSION"
            "permHint" -> if (id) "Akses penyimpanan diperlukan untuk menemukan dan mengedit data save Township." else "Storage access is required to locate and edit Township save data."
            "dayLbl" -> if (id) "SIANG" else "DAY"
            "nightLbl" -> if (id) "MALAM" else "NIGHT"
            "clear" -> if (id) "Hapus" else "Clear"
            "resetSub" -> if (id) "Pindah ke HP baru? Minta admin reset key" else "Moved to a new phone? Ask the admin to reset your key"
            "pasteEmpty" -> if (id) "Clipboard kosong" else "Clipboard is empty"
            "paste" -> if (id) "Tempel dari clipboard" else "Paste from clipboard"
            "show" -> if (id) "Tampilkan kunci" else "Show key"
            "hide" -> if (id) "Sembunyikan kunci" else "Hide key"
            "prev" -> if (id) "Fitur sebelumnya" else "Previous feature"
            "next" -> if (id) "Fitur berikutnya" else "Next feature"
            "modeDesc" -> if (id) "Ganti tema siang/malam" else "Toggle day/night theme"
            "ok" -> "OK"
            else -> S.t(k)
        }
    }

    private fun hasStorage(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun askStorage() {
        sp.edit().putBoolean("permAsked", true).apply()
        if (Build.VERSION.SDK_INT >= 30) {
            try { startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))) }
            catch (e: Exception) { try { startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) } catch (_: Exception) {} }
        } else requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 7)
    }
    /** Tombol izin tampil sampai izin diberikan atau sudah pernah diminta sekali (agar login tidak pernah terkunci). */
    private fun needPerm() = !hasStorage() && !sp.getBoolean("permAsked", false)

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) { super.onRequestPermissionsResult(rc, p, r); refreshBtn?.invoke() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); S.load(this)
        sp = getSharedPreferences("aurora", Context.MODE_PRIVATE)
        val day = sp.getBoolean("loginDay", true)
        val P = if (day) DAY else NIGHT
        var remember = sp.getBoolean("remember", true)
        window.statusBarColor = Color.BLACK; window.navigationBarColor = Color.BLACK

        val root = FrameLayout(this)
        root.addView(if (day) SoftBackground(this) else AuroraBackground(this))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(14), dp(20), dp(24)) }
        val scroll = ScrollView(this).apply {
            isFillViewport = true; overScrollMode = View.OVER_SCROLL_NEVER; isVerticalScrollBarEnabled = false
            addView(col, FrameLayout.LayoutParams(-1, -2))
        }

        // ---------- Bilah atas: indikator gerbang + saklar siang/malam ----------
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(View(this).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(GREEN) } }, LinearLayout.LayoutParams(dp(10), dp(10)))
        top.addView(TextView(this).apply { text = tx("gate"); textSize = 13f; typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.14f; setTextColor(P.sub); maxLines = 1; setPadding(dp(10), 0, 0, 0) }, LinearLayout.LayoutParams(0, -2, 1f))
        val mode = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(10), dp(18), dp(10))
            background = rr(P.pill, 26, P.cardStroke, 1); isClickable = true
        }
        mode.addView(icon(if (day) R.drawable.ic_sun else R.drawable.ic_moon, if (day) c("#F59E0B") else c("#22D3EE")), LinearLayout.LayoutParams(dp(24), dp(24)))
        mode.addView(TextView(this).apply { text = if (day) tx("dayLbl") else tx("nightLbl"); textSize = 15f; typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.08f; setTextColor(P.text); setPadding(dp(10), 0, 0, 0) })
        top.addView(mode)
        col.addView(top)

        // ---------- Merek: logo + nama + versi + tagline ----------
        val brand = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(2), dp(26), 0, dp(24)) }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.logo_rounded); clipToOutline = true; elevation = dp(6).toFloat()
            outlineProvider = object : ViewOutlineProvider() { override fun getOutline(v: View, o: Outline) = o.setRoundRect(0, 0, v.width, v.height, dp(20).toFloat()) }
        }
        brand.addView(logo, LinearLayout.LayoutParams(dp(76), dp(76)))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), 0, 0, 0) }
        val titleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        titleRow.addView(TextView(this).apply { text = "AuroraToolsTS"; textSize = 25f; typeface = Typeface.DEFAULT_BOLD; setTextColor(P.text); maxLines = 1; ellipsize = TextUtils.TruncateAt.END }, LinearLayout.LayoutParams(-2, -2, 1f))
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
        if (ver.isNotEmpty()) titleRow.addView(TextView(this).apply {
            text = "v$ver"; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setTextColor(P.accent); setPadding(dp(10), dp(5), dp(10), dp(5)); background = rr(P.chip, 10, P.panelStroke, 1); maxLines = 1
        }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })
        titles.addView(titleRow)
        titles.addView(TextView(this).apply { text = tx("tagline"); textSize = 12f; typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.1f; setTextColor(P.accent); setPadding(0, dp(8), 0, 0) })
        brand.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        col.addView(brand)

        // ---------- Kartu login ----------
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rr(P.card, 30, P.cardStroke, 1); elevation = dp(8).toFloat(); setPadding(dp(20), dp(24), dp(20), dp(24)) }
        card.addView(TextView(this).apply { text = tx("card"); textSize = 26f; typeface = Typeface.DEFAULT_BOLD; setTextColor(P.text); setPadding(dp(2), 0, 0, dp(14)) })

        val et = EditText(this).apply {
            background = null; setTextColor(P.text); textSize = 16f; typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.06f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
            isSingleLine = true; imeOptions = EditorInfo.IME_ACTION_DONE; setPadding(0, 0, 0, 0)
            transformationMethod = android.text.method.PasswordTransformationMethod.getInstance()
        }
        val clearIc = icon(R.drawable.ic_close, P.sub)
        val clearBtn = FrameLayout(this).apply { isClickable = true; addView(clearIc, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER)) }
        val eyeIc = icon(R.drawable.ic_eye, P.sub)
        val eyeBtn = FrameLayout(this).apply { isClickable = true; addView(eyeIc, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER)) }
        val fieldRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(18), 0, dp(6), 0)
            background = rr(Color.TRANSPARENT, 24, P.cardStroke, 2)
        }
        fieldRow.addView(icon(R.drawable.ic_key, P.accent), LinearLayout.LayoutParams(dp(26), dp(26)))
        fieldRow.addView(et, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(16); marginEnd = dp(4) })
        fieldRow.addView(clearBtn, LinearLayout.LayoutParams(dp(44), dp(52)))
        fieldRow.addView(eyeBtn, LinearLayout.LayoutParams(dp(44), dp(52)))
        val fieldBox = FrameLayout(this)
        fieldBox.addView(fieldRow, FrameLayout.LayoutParams(-1, dp(64)).apply { topMargin = dp(11) })
        fieldBox.addView(TextView(this).apply {
            text = tx("keyLabel"); textSize = 15f; setTextColor(P.sub); background = ColorDrawable(P.card); setPadding(dp(8), 0, dp(8), 0)
        }, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { marginStart = dp(18) })
        card.addView(fieldBox, LinearLayout.LayoutParams(-1, -2))

        val msg = TextView(this).apply { text = " "; textSize = 13f; gravity = Gravity.CENTER; setPadding(0, dp(10), 0, 0); visibility = View.INVISIBLE }
        card.addView(msg, LinearLayout.LayoutParams(-1, -2))
        fun say(color: Int, t: String) { msg.setTextColor(color); msg.text = t; msg.visibility = View.VISIBLE }

        // Kotak centang "Ingat kunci"
        val box = FrameLayout(this)
        val tick = icon(R.drawable.ic_check, Color.WHITE)
        box.addView(tick, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
        fun renderBox() {
            box.background = if (remember) rr(P.accent, 8) else rr(Color.TRANSPARENT, 8, P.sub, 2)
            tick.visibility = if (remember) View.VISIBLE else View.GONE
        }
        renderBox()
        val remRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(14), 0, dp(26)); isClickable = true }
        remRow.addView(box, LinearLayout.LayoutParams(dp(32), dp(32)))
        remRow.addView(TextView(this).apply { text = tx("remember"); textSize = 18f; setTextColor(P.text); setPadding(dp(16), 0, 0, 0) })
        remRow.setOnClickListener {
            remember = !remember; renderBox()
            val ed = sp.edit().putBoolean("remember", remember)
            if (!remember) ed.remove("lastKey")   // matikan "ingat kunci" = hapus kunci tersimpan sekarang juga
            ed.apply()
        }
        card.addView(remRow, LinearLayout.LayoutParams(-1, -2))

        // Pilihan bahasa: judul + 2 baris x 3 kolom
        val langHead = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(2), 0, dp(2), dp(12)) }
        langHead.addView(TextView(this).apply { text = tx("langHead"); textSize = 14f; typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.12f; setTextColor(P.sub) }, LinearLayout.LayoutParams(0, -2, 1f))
        langHead.addView(TextView(this).apply { text = tx("langName"); textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(P.accent) })
        card.addView(langHead)
        val codes = listOf("EN", "PT", "ID", "VI", "RU", "AR")
        for (r in 0..1) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (cI in 0..2) {
                val code = codes[r * 3 + cI]; val sel = code == S.lang.uppercase()
                row.addView(TextView(this).apply {
                    text = code; gravity = Gravity.CENTER; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; isClickable = true
                    setTextColor(if (sel) P.accent else P.sub)
                    background = if (sel) rr(P.langSel, 18, P.accent, 2) else rr(P.lang, 18, P.langStroke, 1)
                    setOnClickListener {
                        if (code == "EN" || code == "ID") { if (!sel) { draft = et.text.toString(); S.setLang(code.lowercase()); recreate() } }
                        else Toast.makeText(this@LoginActivity, tx("langSoon"), Toast.LENGTH_SHORT).show()
                    }
                }, LinearLayout.LayoutParams(0, dp(58), 1f).apply { setMargins(if (cI == 0) 0 else dp(6), dp(6), if (cI == 2) 0 else dp(6), dp(6)) })
            }
            card.addView(row)
        }

        // Tombol utama: "BERIKAN IZIN" sampai izin penyimpanan diberikan, lalu "MASUK"
        val btn = FxButton(this, 30).apply {
            elevation = dp(6).toFloat()
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(c("#0287CE"), c("#6A6BF0"))).apply { cornerRadius = dp(30).toFloat() }
        }
        val btnLabel = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; elevation = dp(8).toFloat() }
        btnLabel.addView(icon(R.drawable.ic_lock, Color.WHITE), LinearLayout.LayoutParams(dp(24), dp(24)))
        val btnText = TextView(this).apply { textSize = 18f; typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.14f; setTextColor(Color.WHITE); setPadding(dp(14), 0, 0, 0) }
        btnLabel.addView(btnText)
        val btnBox = FrameLayout(this)
        btnBox.addView(btn, FrameLayout.LayoutParams(-1, -1))
        btnBox.addView(btnLabel, FrameLayout.LayoutParams(-1, -1))
        card.addView(btnBox, LinearLayout.LayoutParams(-1, dp(64)).apply { topMargin = dp(18) })
        val permHint = TextView(this).apply { text = tx("permHint"); textSize = 15f; setTextColor(P.sub); gravity = Gravity.CENTER; setLineSpacing(dp(4).toFloat(), 1f); setPadding(dp(6), dp(16), dp(6), 0) }
        card.addView(permHint, LinearLayout.LayoutParams(-1, -2))
        refreshBtn = {
            val np = needPerm()
            btnText.text = if (np) tx("perm") else S.t("loginBtn")
            permHint.visibility = if (np) View.VISIBLE else View.GONE
        }
        refreshBtn?.invoke()
        col.addView(card, LinearLayout.LayoutParams(-1, -2))

        // ---------- Carousel fitur ----------
        val feats = Menus.root.children.map { it.title }
        var idx = 0
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rr(P.panel, 28, P.panelStroke, 2); setPadding(dp(20), dp(18), dp(16), dp(18)); isClickable = true }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(View(this).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(GREEN) } }, LinearLayout.LayoutParams(dp(10), dp(10)))
        head.addView(TextView(this).apply { text = tx("featHead"); textSize = 14f; typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.1f; setTextColor(P.accent); maxLines = 1; setPadding(dp(10), 0, 0, 0) }, LinearLayout.LayoutParams(0, -2, 1f))
        val counter = TextView(this).apply { textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(P.sub); setPadding(0, 0, dp(10), 0) }
        head.addView(counter)
        fun circleBtn(res: Int) = FrameLayout(this).apply {
            background = rr(P.circle, 22, P.langStroke, 1); isClickable = true
            addView(icon(res, P.text), FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
        }
        val prev = circleBtn(R.drawable.ic_chev_l); val next = circleBtn(R.drawable.ic_chev_r)
        head.addView(prev, LinearLayout.LayoutParams(dp(44), dp(44)))
        head.addView(next, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginStart = dp(8) })
        panel.addView(head)

        val body = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(16), 0, dp(14)) }
        val vipBg = if (day) c("#FDE3EA") else c("#3A1830"); val vipFg = if (day) c("#D6336C") else c("#F0527A")
        body.addView(FrameLayout(this).apply {
            background = rr(vipBg, 18, vipFg, 1)
            addView(icon(R.drawable.ic_lock, vipFg), FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER))
        }, LinearLayout.LayoutParams(dp(60), dp(60)))
        val featTxt = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), 0, 0, 0) }
        val featTitle = TextView(this).apply { textSize = 18f; typeface = Typeface.DEFAULT_BOLD; setTextColor(P.text); maxLines = 2; ellipsize = TextUtils.TruncateAt.END }
        featTxt.addView(featTitle)
        val sub = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, 0) }
        sub.addView(TextView(this).apply { text = tx("vip"); textSize = 14f; typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.06f; setTextColor(P.accent) })
        sub.addView(TextView(this).apply { text = "  •  " + tx("tap"); textSize = 14f; setTextColor(P.sub) })
        featTxt.addView(sub)
        body.addView(featTxt, LinearLayout.LayoutParams(0, -2, 1f))
        panel.addView(body)

        val dots = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val dotViews = (0 until 6).map { View(this) }
        dotViews.forEach { dots.addView(it, LinearLayout.LayoutParams(dp(8), dp(5)).apply { marginEnd = dp(6) }) }
        panel.addView(dots)

        fun render(animate: Boolean) {
            val n = feats.size
            featTitle.text = feats[idx]; counter.text = "${idx + 1}/$n"
            val active = idx * dotViews.size / n
            dotViews.forEachIndexed { i, v ->
                v.background = rr(if (i == active) P.accent else P.dotOff, 3)
                v.layoutParams = (v.layoutParams as LinearLayout.LayoutParams).apply { width = dp(if (i == active) 26 else 9) }
            }
            if (animate && S.effects) { body.alpha = 0f; body.animate().alpha(1f).setDuration(220).start() }
        }
        fun step(d: Int, animate: Boolean = true) { idx = (idx + d + feats.size) % feats.size; render(animate) }
        fun restartAuto() {
            autoplay?.let { ui.removeCallbacks(it) }
            autoplay = object : Runnable { override fun run() { step(1); ui.postDelayed(this, 3500) } }.also { ui.postDelayed(it, 3500) }
        }
        render(false)
        if (feats.size > 1) restartAuto()
        else { prev.visibility = View.GONE; next.visibility = View.GONE; counter.visibility = View.GONE; dots.visibility = View.GONE }
        prev.setOnClickListener { step(-1); restartAuto() }
        next.setOnClickListener { step(1); restartAuto() }
        panel.setOnClickListener { Toast.makeText(this, tx("needLogin"), Toast.LENGTH_SHORT).show() }
        col.addView(panel, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(22) })

        val dlg = if (day) android.R.style.Theme_Material_Light_Dialog_Alert else android.R.style.Theme_Material_Dialog_Alert

        // ---------- Aksi bawah: dua kartu lebar ----------
        fun action(res: Int, title: String, subtitle: String, onClick: () -> Unit): View {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = rr(P.panel, 28, P.panelStroke, 2); setPadding(dp(18), dp(18), dp(18), dp(18)); isClickable = true }
            row.addView(FrameLayout(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(P.iconBg) }
                addView(icon(res, P.accent), FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER))
            }, LinearLayout.LayoutParams(dp(64), dp(64)))
            val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), 0, dp(8), 0) }
            t.addView(TextView(this).apply { text = title.uppercase(); textSize = 18f; typeface = Typeface.DEFAULT_BOLD; setTextColor(P.text); maxLines = 2 })
            t.addView(TextView(this).apply { text = subtitle; textSize = 15f; setTextColor(P.sub); maxLines = 2; setPadding(0, dp(4), 0, 0) })
            row.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(icon(R.drawable.ic_chev_r, P.sub), LinearLayout.LayoutParams(dp(28), dp(28)))
            row.setOnClickListener { onClick() }
            return row
        }
        col.addView(action(R.drawable.ic_gem, tx("premium"), tx("premiumSub")) {
            AlertDialog.Builder(this, dlg).setTitle(tx("premium")).setMessage(tx("premiumMsg")).setPositiveButton(tx("ok"), null).show()
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) })
        col.addView(action(R.drawable.ic_phone, tx("reset"), tx("resetSub")) {
            AlertDialog.Builder(this, dlg).setTitle(S.t("h2t")).setMessage(S.t("h2")).setPositiveButton(tx("ok"), null).show()
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        col.addView(TextView(this).apply { text = "Powered by AuroraTS"; setTextColor(P.sub); textSize = 12f; gravity = Gravity.CENTER; setPadding(0, dp(20), 0, 0) }, LinearLayout.LayoutParams(-1, -2))

        // ---------- Perilaku ----------
        keyField = et
        et.contentDescription = tx("keyLabel")
        clearBtn.contentDescription = tx("clear"); eyeBtn.contentDescription = tx("show")
        prev.contentDescription = tx("prev"); next.contentDescription = tx("next")
        mode.contentDescription = tx("modeDesc")
        et.setText(if (draft.isNotEmpty()) draft else if (remember) sp.getString("lastKey", "") ?: "" else "")
        et.setSelection(et.text.length); draft = ""
        // Pesan status hilang begitu pengguna mulai mengetik lagi (tanpa menggeser tata letak).
        et.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                clearBtn.visibility = if (s.isNullOrEmpty()) View.INVISIBLE else View.VISIBLE
                if (!busy && msg.visibility == View.VISIBLE) msg.visibility = View.INVISIBLE
            }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        clearBtn.visibility = if (et.text.isEmpty()) View.INVISIBLE else View.VISIBLE
        var hidden = true
        eyeBtn.setOnClickListener {
            hidden = !hidden
            et.transformationMethod = if (hidden) android.text.method.PasswordTransformationMethod.getInstance() else null
            et.setSelection(et.text.length)
            eyeIc.setImageResource(if (hidden) R.drawable.ic_eye else R.drawable.ic_eye_off)
            eyeBtn.contentDescription = tx(if (hidden) "show" else "hide")
        }
        clearBtn.setOnClickListener { et.setText(""); et.requestFocus() }
        mode.setOnClickListener { draft = et.text.toString(); sp.edit().putBoolean("loginDay", !day).apply(); recreate() }

        fun submit() {
            if (busy) return
            val now = SystemClock.elapsedRealtime()
            if (now < lockUntil) { say(ERR, "${S.t("wait")} ${(lockUntil - now) / 1000 + 1}s"); return }
            val k = et.text.toString().trim().uppercase()
            if (k.isEmpty()) { say(ERR, S.t("empty")); return }
            (getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)?.hideSoftInputFromWindow(et.windowToken, 0)
            busy = true; btn.isEnabled = false; btnLabel.alpha = 0.6f; say(P.accent, S.t("checking"))
            License.activate(this, k) { r ->
                busy = false
                if (destroyed || isFinishing) return@activate   // layar sudah dibuat ulang/ditutup: jangan sentuh view lama
                if (r.ok) {
                    fails = 0
                    S.setActivated(true, k)
                    if (remember) sp.edit().putString("lastKey", k).apply() else sp.edit().remove("lastKey").apply()
                    say(OK, S.t("welcome"))   // tombol tetap nonaktif agar tidak bisa diketuk ulang
                    ui.postDelayed({
                        if (!destroyed && !isFinishing) {
                            startActivity(Intent(this, MainActivity::class.java))
                            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                            finish()
                        }
                    }, 400)
                } else {
                    btn.isEnabled = true; btnLabel.alpha = 1f
                    say(ERR, S.t(r.error ?: "invalid"))
                    if (r.error != "neterr") {
                        fails++
                        fieldBox.animate().translationX(dp(10).toFloat()).setDuration(60).withEndAction { fieldBox.animate().translationX(0f).setDuration(120).start() }.start()
                        if (fails >= 5) { fails = 0; lockUntil = SystemClock.elapsedRealtime() + 15000 }
                    }
                }
            }
        }
        btn.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            if (needPerm()) askStorage() else submit()
        }
        et.setOnEditorActionListener { _, _, _ -> submit(); true }

        if (firstShow) { firstShow = false; for (i in 0 until col.childCount) Fx.enter(col.getChildAt(i), i) }
        root.addView(scroll, FrameLayout.LayoutParams(if (resources.configuration.screenWidthDp >= 600) dp(480) else -1, -1, Gravity.CENTER_HORIZONTAL))
        setContentView(root)
    }

    override fun onResume() { super.onResume(); Perf.lock60(this); refreshBtn?.invoke(); autoplay?.let { ui.removeCallbacks(it); ui.postDelayed(it, 3500) } }
    override fun onPause() { autoplay?.let { ui.removeCallbacks(it) }; super.onPause() }
    override fun onDestroy() { destroyed = true; ui.removeCallbacksAndMessages(null); super.onDestroy() }

    /** Rotasi tidak membuat activity baru (configChanges); bangun ulang agar lebar kartu (tablet/landscape) ikut menyesuaikan. */
    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        draft = keyField?.text?.toString().orEmpty()
        super.onConfigurationChanged(newConfig)
        recreate()
    }

    private fun rr(fill: Int, r: Int, stroke: Int = 0, sw: Int = 0) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(r).toFloat(); if (sw > 0) setStroke(dp(sw), stroke)
    }
    private fun icon(res: Int, tint: Int) = ImageView(this).apply { setImageResource(res); setColorFilter(tint); scaleType = ImageView.ScaleType.FIT_CENTER }

    /** Latar mode siang dioptimalkan bebas alokasi onDraw. */
    private class SoftBackground(ctx: Context) : View(ctx) {
        private val d = ctx.resources.displayMetrics.density
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private var bgShader: LinearGradient? = null

        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
            super.onSizeChanged(w, h, oldw, oldh)
            if (h > 0) {
                bgShader = LinearGradient(0f, 0f, 0f, h.toFloat(), Color.parseColor("#F8FBFE"), Color.parseColor("#EAF2FA"), Shader.TileMode.CLAMP)
            }
        }

        override fun onDraw(cv: Canvas) {
            val w = width.toFloat(); val h = height.toFloat()
            p.style = Paint.Style.FILL; p.shader = bgShader
            cv.drawRect(0f, 0f, w, h, p); p.shader = null
            p.style = Paint.Style.FILL; p.color = Color.parseColor("#14A7E0F8"); cv.drawCircle(-0.1f * w, 0.62f * h, 0.7f * w, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f * d
            p.color = Color.parseColor("#66A9DDF5"); cv.drawCircle(0.62f * w, 0.02f * h, 0.52f * w, p)
            p.color = Color.parseColor("#44A9DDF5"); cv.drawCircle(1.05f * w, 0.3f * h, 0.42f * w, p)
            p.color = Color.parseColor("#33C6B8F5"); cv.drawCircle(-0.15f * w, 0.5f * h, 0.45f * w, p)
        }
    }
}
