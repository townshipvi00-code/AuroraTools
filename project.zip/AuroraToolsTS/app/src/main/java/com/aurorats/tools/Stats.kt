package com.aurorats.tools

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Satu baris pada halaman Statistik Profil (urutan mengikuti TsVip). */
class Stat(val key: String, val label: String, val icon: String, val hint: String, val max: Long = 2_147_483_647L, val monthYear: Boolean = false)

object Stats {
    val LIST = listOf(
        Stat("tcash", "T-CASH", "💲", "0 – 2147483647", 2147483647L),
        Stat("coin", "KOIN", "🪙", "0 – 1000000000", 1000000000L),
        Stat("level", "LEVEL", "★", "1 – 1089", 1089L),
        Stat("levelm3", "LEVEL M3", "🧩", "0 – 10000000", 10000000L),
        Stat("firstwin", "MENANG PERTAMA", "🏅", "0 – 10000000", 10000000L),
        Stat("lives", "NYAWA", "♥", "0 – 10000000", 10000000L),
        Stat("help", "HELP", "👥", "0 – 10000000", 10000000L),
        Stat("cards", "KARTU", "🃏", "0 – 10000", 10000L),
        Stat("regatta", "REGATA", "🏆", "0 – 10000000", 10000000L),
        Stat("monthyear", "BULAN/TAHUN", "📅", "MM/YYYY", monthYear = true),
        Stat("expenergy", "ENERGI EKSPEDISI", "⚡", "0 – 999999999", 999999999L),
        Stat("minedepth", "KEDALAMAN TAMBANG", "⛰", "0 – 2147483647")
    )
}

/**
 * Sesi edit: HUBUNGKAN mendekode save satu kali, semua editan menumpuk di memori (belum menyentuh game),
 * lalu SIMPAN & KIRIM mengenkode dan menulis balik ke data game sebelum Township diluncurkan.
 */
class Change(val idx: Int, val old: String, val new: String)

object Session {
    @Volatile var xml: String? = null
    @Volatile var rawSize = 0           // ukuran berkas save asli saat HUBUNGKAN (game memakai berkas berukuran tetap)
    @Volatile var rawSig = 0L          // sidik berkas sumber saat didekode, untuk mendeteksi save yang berubah
    @Volatile var edits = 0
    @Volatile var cityId = ""                  // ID kota yang dipakai saat HUBUNGKAN (kosong = save terbaru)
    @Volatile var srcRoot: String? = null      // path save yang dipakai saat HUBUNGKAN (root)
    @Volatile var srcFile: File? = null        // ... atau berkas langsung; penulisan selalu ke berkas yang sama
    @Volatile var untracked = false            // ada edit yang tidak bisa dicatat per token
    val changes = ArrayList<Change>()          // catatan edit, untuk diterapkan ulang bila save di disk berubah
    val connected get() = xml != null
    val dirty get() = edits > 0
    fun reset() { synchronized(this) { xml = null; edits = 0; cityId = ""; rawSig = 0L; rawSize = 0; srcRoot = null; srcFile = null; untracked = false; changes.clear() } }
}

/**
 * Baca/tulis statistik profil di mGameInfo.xml.
 * Format save (sesuai berkas contoh): XML polos, tiap statistik berupa
 * `<Var name="NAMA" v="NILAI" t="i"/>` di dalam <Global>.
 */
object StatsEngine {
    /** Encode/decode berkas save. */
    interface Codec {
        fun decode(raw: ByteArray): String?
        fun encode(xml: String): ByteArray?
    }

    /**
     * Pembaca save serba-bisa: XML polos (UTF-8/UTF-16), gzip, zlib, deflate mentah, dan semuanya yang dibungkus base64.
     * Cara membuka diingat, lalu dipakai terbalik saat menyimpan supaya format asli berkas tidak berubah.
     */
    object PlainCodec : Codec {
        @Volatile private var comp = 0            // 0 polos, 1 gzip, 2 zlib, 3 deflate mentah
        @Volatile private var b64 = false
        @Volatile private var cs: java.nio.charset.Charset = Charsets.UTF_8
        @Volatile private var bom = false

        private fun inflate(b: ByteArray, nowrap: Boolean): ByteArray? = try {
            val inf = java.util.zip.Inflater(nowrap); inf.setInput(b)
            val o = java.io.ByteArrayOutputStream(); val buf = ByteArray(8192)
            while (!inf.finished()) { val n = inf.inflate(buf); if (n == 0 && (inf.needsInput() || inf.needsDictionary())) break; o.write(buf, 0, n) }
            inf.end(); if (o.size() > 0) o.toByteArray() else null
        } catch (_: Exception) { null }

        private fun text(b: ByteArray): String? {
            val s = when {
                b.size >= 2 && b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte() -> { cs = Charsets.UTF_16LE; bom = true; String(b, 2, b.size - 2, Charsets.UTF_16LE) }
                b.size >= 2 && b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte() -> { cs = Charsets.UTF_16BE; bom = true; String(b, 2, b.size - 2, Charsets.UTF_16BE) }
                else -> { cs = Charsets.UTF_8; bom = false; String(b, Charsets.UTF_8).removePrefix("\uFEFF") }
            }
            return if (s.trimStart().startsWith("<")) s else null
        }

        private fun body(b: ByteArray): String? {
            text(b)?.let { comp = 0; return it }
            if (b.size > 2 && b[0] == 0x1f.toByte() && b[1] == 0x8b.toByte()) {
                val u = try { java.util.zip.GZIPInputStream(b.inputStream()).use { it.readBytes() } } catch (_: Exception) { null }
                if (u != null) text(u)?.let { comp = 1; return it }
            }
            if (b.size > 2 && (b[0].toInt() and 0x0f) == 8 && (((b[0].toInt() and 0xff) shl 8) or (b[1].toInt() and 0xff)) % 31 == 0) {
                inflate(b, false)?.let { u -> text(u)?.let { comp = 2; return it } }
            }
            inflate(b, true)?.let { u -> text(u)?.let { comp = 3; return it } }
            return null
        }

        override fun decode(raw: ByteArray): String? {
            b64 = false
            body(raw)?.let { return it }
            val t = String(raw, Charsets.ISO_8859_1).trim()
            if (t.length >= 16 && Regex("^[A-Za-z0-9+/=_\\r\\n-]+$").matches(t)) {
                val d = try { android.util.Base64.decode(t, android.util.Base64.DEFAULT) } catch (_: Exception) { null }
                if (d != null) body(d)?.let { b64 = true; return it }
            }
            return null
        }

        override fun encode(xml: String): ByteArray? {
            var b = xml.toByteArray(cs)
            if (bom) b = (if (cs == Charsets.UTF_16LE) byteArrayOf(0xFF.toByte(), 0xFE.toByte()) else byteArrayOf(0xFE.toByte(), 0xFF.toByte())) + b
            b = when (comp) {
                1 -> java.io.ByteArrayOutputStream().also { o -> java.util.zip.GZIPOutputStream(o).use { it.write(b) } }.toByteArray()
                2, 3 -> { val d = java.util.zip.Deflater(java.util.zip.Deflater.DEFAULT_COMPRESSION, comp == 3); d.setInput(b); d.finish()
                    val o = java.io.ByteArrayOutputStream(); val buf = ByteArray(8192); while (!d.finished()) o.write(buf, 0, d.deflate(buf)); d.end(); o.toByteArray() }
                else -> b
            }
            return if (b64) android.util.Base64.encode(b, android.util.Base64.NO_WRAP) else b
        }
    }

    /**
     * Codec Universal: Mendukung format terenkripsi Township (0x79 + LZ4 Frame) via AuroraCodec
     * dan format XML polos / GZIP / ZLIB / Base64 via PlainCodec.
     */
    object UniversalCodec : Codec {
        @Volatile var mode = 0

        override fun decode(raw: ByteArray): String? {
            if (raw.isEmpty()) return null

            // 1. Cek apakah XML polos langsung (UTF-8, UTF-16, atau ada BOM)
            val sHead = String(raw, 0, minOf(raw.size, 64), Charsets.UTF_8).trimStart()
            if (sHead.startsWith("<") || (raw.size >= 3 && (raw[0].toInt() and 0xFF) == 0xEF && (raw[1].toInt() and 0xFF) == 0xBB && (raw[2].toInt() and 0xFF) == 0xBF)) {
                val p = PlainCodec.decode(raw)
                if (p != null) {
                    mode = 0
                    return p
                }
            }

            // 2. Format terenkripsi Township: 0x79 (MurmurHash2 table) atau 0x04 0x22 (LZ4 Frame)
            if (raw.size >= 8 && ((raw[0].toInt() and 0xFF) == 0x79 || (raw[0] == 0x04.toByte() && raw[1] == 0x22.toByte()))) {
                try {
                    val dec = AuroraCodec.decode(raw)
                    val s = String(dec, Charsets.UTF_8).removePrefix("\uFEFF")
                    if (s.trimStart().startsWith("<")) {
                        mode = if ((raw[0].toInt() and 0xFF) == 0x79) 1 else 2
                        return s
                    }
                } catch (_: Exception) {}
            }

            // 3. Cek format GZIP (0x1f 0x8b) atau ZLIB (0x78)
            if (raw.size >= 2 && ((raw[0] == 0x1f.toByte() && raw[1] == 0x8b.toByte()) || (raw[0] == 0x78.toByte()))) {
                val p = PlainCodec.decode(raw)
                if (p != null) {
                    mode = 0
                    return p
                }
            }

            // 4. Cek Base64
            val t = String(raw, Charsets.ISO_8859_1).trim()
            if (t.length >= 16 && Regex("^[A-Za-z0-9+/=_\\r\\n-]+$").matches(t)) {
                val d = try { android.util.Base64.decode(t, android.util.Base64.DEFAULT) } catch (_: Exception) { null }
                if (d != null && d.isNotEmpty()) {
                    if (d.size >= 8 && ((d[0].toInt() and 0xFF) == 0x79 || (d[0] == 0x04.toByte() && d[1] == 0x22.toByte()))) {
                        try {
                            val dec = AuroraCodec.decode(d)
                            val s = String(dec, Charsets.UTF_8).removePrefix("\uFEFF")
                            if (s.trimStart().startsWith("<")) {
                                mode = 6
                                return s
                            }
                        } catch (_: Exception) {}
                    }
                    val plainD = PlainCodec.decode(d)
                    if (plainD != null) {
                        mode = 7
                        return plainD
                    }
                }
            }

            // 5. Coba AuroraCodec.decode secara umum jika belum berhasil
            try {
                val dec = AuroraCodec.decode(raw)
                val s = String(dec, Charsets.UTF_8).removePrefix("\uFEFF")
                if (s.trimStart().startsWith("<")) {
                    mode = 1
                    return s
                }
            } catch (_: Exception) {}

            // 6. Terakhir: PlainCodec coba semua kemungkinan (deflate mentah, charset alternatif)
            val p = PlainCodec.decode(raw)
            if (p != null) {
                mode = 0
                return p
            }

            return null
        }

        override fun encode(xml: String): ByteArray? {
            return when (mode) {
                1 -> {
                    try {
                        AuroraCodec.encode(xml.toByteArray(Charsets.UTF_8))
                    } catch (_: Exception) { PlainCodec.encode(xml) }
                }
                2 -> {
                    try {
                        AuroraCodec.encodeLz4Only(xml.toByteArray(Charsets.UTF_8))
                    } catch (_: Exception) { PlainCodec.encode(xml) }
                }
                6 -> {
                    try {
                        val enc = AuroraCodec.encode(xml.toByteArray(Charsets.UTF_8))
                        android.util.Base64.encode(enc, android.util.Base64.NO_WRAP)
                    } catch (_: Exception) { PlainCodec.encode(xml) }
                }
                7 -> {
                    val p = PlainCodec.encode(xml)
                    if (p != null) android.util.Base64.encode(p, android.util.Base64.NO_WRAP) else null
                }
                else -> PlainCodec.encode(xml)
            }
        }
    }

    var codec: Codec? = UniversalCodec

    /**
     * Nama <Var> di mGameInfo.xml untuk tiap statistik (kunci = Stat.key).
     * monthyear = gameStartDate (detik Unix) diubah dari/ke MM/YYYY lewat [monthYearOf] dan [withMonthYear].
     * help = Achievement_Teamwork (nilai Help 100000000), minedepth = Achievement_EarthCenter (kedalaman tambang 163134); keduanya dicocokkan dari nilai di save contoh.
     */
    val TAGS: Map<String, String> = mapOf(
        "tcash" to "moneyCash",
        "coin" to "money",
        "level" to "levelup",
        "firstwin" to "FirstAttemptM3Levels",
        "lives" to "LivesSent",
        "cards" to "CardsSent",
        "expenergy" to "expeditionEnergy",
        "regatta" to "RegataTasksCompleted",
        "levelm3" to "m3_comp_lvls",
        "monthyear" to "gameStartDate",
        "help" to "Achievement_Teamwork",
        "minedepth" to "Achievement_EarthCenter"
    )

    class Loaded(val values: Map<String, String>, val log: List<String>)

    private fun ts() = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
    fun line(s: String) = "${ts()}  $s"

    /** Lokasi file save yang bisa ditulis langsung (tanpa root), bila ada. */
    private fun directFile(c: Context): File? {
        // Folder pertama (urutan: data internal/virtual dulu, eksternal terakhir) yang punya mGameInfo.xml; di dalamnya ambil yang terbaru.
        // Dulu memilih yang terbaru di SEMUA folder, sehingga berkas tiruan di /sdcard/Android/data (buatan versi lama) ikut terpilih.
        for (d in GameFiles.allDataDirs(c)) {
            val f = GameFiles.find(d, "mGameInfo.xml").maxByOrNull { it.lastModified() }
            if (f != null) return f
        }
        return null
    }

    /** Semua mGameInfo.xml di data game lewat root. */
    private fun rootPaths(): List<String> {
        if (Env.rootVerified != true) return emptyList()
        val src = "/data/data/${GameBridge.PACKAGE}"
        return RootShell.exec("find $src -name mGameInfo.xml")?.text?.lines()?.map { it.trim() }?.filter { it.startsWith(src) }.orEmpty()
    }

    /** Satu save yang bisa dipilih (lewat root atau berkas langsung). */
    class Cand(val root: String?, val file: File?) { val path get() = root ?: file?.absolutePath ?: "" }

    private fun candidates(c: Context): List<Cand> {
        val out = ArrayList<Cand>()
        rootPaths().forEach { out.add(Cand(it, null)) }
        GameFiles.allDataDirs(c).map { d -> GameFiles.find(d, "mGameInfo.xml") }.firstOrNull { it.isNotEmpty() }
            ?.forEach { f -> if (out.none { it.path.endsWith(f.absolutePath.substringAfter(GameBridge.PACKAGE)) && it.root != null }) out.add(Cand(null, f)) }
        return out
    }

    /** Path mGameInfo.xml di data game lewat root (yang terbaru), atau null. */
    private fun rootPath(): String? {
        val found = rootPaths()
        if (found.size <= 1) return found.firstOrNull()
        // Beberapa salinan: pilih yang paling baru diubah (itu yang dipakai game).
        val st = RootShell.exec("stat -c '%Y %n' " + found.joinToString(" ") { "'$it'" })?.text?.lines().orEmpty()
        return st.mapNotNull { l -> val i = l.trim().indexOf(' '); if (i > 0) (l.trim().substring(0, i).toLongOrNull() ?: return@mapNotNull null) to l.trim().substring(i + 1) else null }
            .maxByOrNull { it.first }?.second ?: found.first()
    }

    /** Salin mGameInfo.xml ke cache (root bila ada, kalau tidak akses file langsung). */
    @Volatile private var lastSrc = ""
    @Volatile private var lastRoot: String? = null
    @Volatile private var lastFile: File? = null
    /** [pin]: pakai berkas yang sama dengan saat HUBUNGKAN (bukan memilih ulang). */
    private fun locate(c: Context, pin: Boolean = false, cand: Cand? = null): File? {
        val out = File(c.cacheDir, "mGameInfo.work")
        if (cand != null) {
            cand.root?.let { p -> if (RootShell.pipeTo("cat '$p'", out, 30_000)) { lastSrc = "root: $p"; lastRoot = p; lastFile = null; return out } }
            cand.file?.let { f -> lastSrc = "langsung: ${f.absolutePath}"; lastRoot = null; lastFile = f; return try { f.copyTo(out, true) } catch (_: Exception) { null } }
            return null
        }
        val rp = (if (pin) Session.srcRoot else null) ?: if (pin && Session.srcFile != null) null else rootPath()
        if (rp != null && RootShell.pipeTo("cat '$rp'", out, 30_000)) { lastSrc = "root: $rp"; lastRoot = rp; lastFile = null; return out }
        val f = (if (pin) Session.srcFile else null) ?: directFile(c) ?: return null
        lastSrc = "langsung: ${f.absolutePath}"; lastRoot = null; lastFile = f
        return try { f.copyTo(out, true) } catch (_: Exception) { null }
    }

    private fun peek(b: ByteArray): List<String> {
        val hex = b.take(16).joinToString(" ") { "%02x".format(it) }
        val txt = String(b, 0, minOf(b.size, 32), Charsets.ISO_8859_1).map { if (it in ' '..'~') it else '.' }.joinToString("")
        return listOf("Sumber: $lastSrc • ${b.size} byte", "Awal (hex): $hex", "Awal (teks): $txt")
    }

    /** Baca & dekode save langsung dari data game (tanpa sesi). @return xml + byte mentah, atau null. */
    private fun readDisk(c: Context, log: MutableList<String>, pin: Boolean = false, cand: Cand? = null): Pair<String, ByteArray>? {
        val g = Env.gate(c); if (g != Env.Gate.OK) { log.add(line(S.t("gateVirt"))); return null }
        val f = locate(c, pin, cand) ?: run { log.add(line(S.t("noGameData"))); return null }
        val cd = codec ?: UniversalCodec
        log.add(line("Decoding game data..."))
        var raw = f.readBytes()
        if (raw.isEmpty()) {
            val parent = f.parentFile
            if (parent != null) {
                val ed = File(parent, "_ed_source")
                if (ed.exists() && ed.length() > 0) {
                    val edRaw = ed.readBytes()
                    if (edRaw.isNotEmpty()) {
                        val edXml = cd.decode(edRaw) ?: UniversalCodec.decode(edRaw) ?: PlainCodec.decode(edRaw)
                        if (edXml != null) {
                            log.add(line("Save mGameInfo.xml kosong — memuat dari berkas cermin _ed_source ✔"))
                            return edXml to edRaw
                        }
                    }
                }
            }
            log.add(line("Berkas save kosong (0 byte) — buka Township sekali sampai masuk kota, tutup, lalu coba lagi"))
            return null
        }
        val xml = cd.decode(raw) ?: run {
            val fallback = if (cd === UniversalCodec) PlainCodec.decode(raw) else UniversalCodec.decode(raw)
            if (fallback != null) return fallback to raw
            log.add(line("Decode gagal"))
            peek(raw).forEach { log.add(line(it)) }
            return null
        }
        return xml to raw
    }

    private fun sig(b: ByteArray) = (b.size.toLong() shl 32) xor (b.contentHashCode().toLong() and 0xffffffffL)

    /** XML kerja dari sesi (hasil HUBUNGKAN). Tanpa sesi: null + pesan di log. */
    private fun readXml(@Suppress("UNUSED_PARAMETER") c: Context, log: MutableList<String>): String? =
        Session.xml ?: run { log.add(line("Belum terhubung — tekan HUBUNGKAN dulu")); null }

    private fun needSession(log: MutableList<String>): Boolean =
        Session.connected.also { if (!it) log.add(line("Belum terhubung — tekan HUBUNGKAN dulu")) }

    // ---------- Pencatatan edit & penerapan ulang ----------
    private val tokRe = Regex("<[^>]*>|[^<]+")
    private fun tokens(x: String) = tokRe.findAll(x).map { it.value }.toList()
    private val keyRe = Regex("""^<(\w+)[^>]*?\b(?:name|id)="([^"]*)"""")
    private fun keyOf(t: String) = keyRe.find(t)?.let { it.groupValues[1] + "|" + it.groupValues[2] }

    /** Jadikan [new] XML kerja sesi dan catat token yang berubah (struktur tag tidak berubah pada semua editor). */
    private fun stage(new: String) = synchronized(Session) {
        val old = Session.xml ?: return@synchronized
        val a = tokens(old); val b = tokens(new)
        if (a.size == b.size) { for (i in a.indices) if (a[i] != b[i]) Session.changes.add(Change(i, a[i], b[i])) }
        else Session.untracked = true
        Session.xml = new; Session.edits++
    }

    /** Terapkan ulang semua edit sesi ke save [fresh] yang lebih baru. @return xml baru + daftar konflik. */
    private fun rebase(fresh: String): Pair<String, List<String>> {
        val t = tokens(fresh).toMutableList(); val bad = ArrayList<String>()
        for (ch in Session.changes) {
            val i = when {
                ch.idx < t.size && t[ch.idx] == ch.old -> ch.idx
                else -> {
                    val same = t.indices.filter { t[it] == ch.old }
                    if (same.size == 1) same[0] else {
                        val k = keyOf(ch.old)
                        val byKey = if (k == null) emptyList() else t.indices.filter { keyOf(t[it]) == k }
                        if (byKey.size == 1) byKey[0] else if (ch.idx < t.size && t[ch.idx] == ch.new) ch.idx else -1
                    }
                }
            }
            if (i < 0) bad.add(ch.new.take(60)) else t[i] = ch.new
        }
        return t.joinToString("") to bad
    }

    class Outcome(val ok: Boolean, val log: List<String>, val launch: Boolean = true)

    fun disconnect() = Session.reset()

    /** Pilih save berdasarkan ID kota: cocok di path berkas atau di isi XML. */
    private fun pickByCity(c: Context, id: String, log: MutableList<String>): Cand? {
        val cands = candidates(c)
        if (cands.isEmpty()) return null
        log.add(line("Mencari ID kota $id di ${cands.size} save..."))
        val cd = codec ?: return null
        val hit = cands.firstOrNull { cand ->
            cand.path.contains(id) || (locate(c, false, cand)?.let { f -> try { cd.decode(f.readBytes())?.contains(id) == true } catch (_: Exception) { false } } == true)
        }
        if (hit != null) { log.add(line("ID kota $id cocok ✔ ${hit.path.substringAfter(GameBridge.PACKAGE, hit.path)}")); return hit }
        if (cands.size == 1) { log.add(line("ID kota $id tidak tertulis di save; memakai satu-satunya save yang ada.")); return cands[0] }
        log.add(line("ID kota $id tidak ada di ${cands.size} save yang ditemukan ✘ gagal"))
        return null
    }

    /** Diagnosis (tidak menulis apa pun): enkode ulang XML TANPA perubahan lalu bandingkan dengan berkas asli byte demi byte. */
    private fun roundTrip(raw: ByteArray, xml: String): List<String> {
        val out = ArrayList<String>()
        try {
            if (!AuroraCodec.is0x79(raw)) return out
            val enc = AuroraCodec.encode(xml.toByteArray(Charsets.UTF_8))
            val padded = if (raw.size > enc.size) enc.copyOf(raw.size) else enc
            var diff = 0; var first = -1
            for (i in 0 until minOf(raw.size, padded.size)) if (raw[i] != padded[i]) { diff++; if (first < 0) first = i }
            out.add(line("Uji bolak-balik: asli ${raw.size} B • enkode ulang ${enc.size} B • beda $diff byte" + (if (first >= 0) " (pertama di offset $first)" else " ✔ identik")))
            val sv = intArrayOf(AuroraCodec.lastSeed, AuroraCodec.lastHashLength, AuroraCodec.lastPadTo, AuroraCodec.lastTrail)
            try {
                val o = AuroraCodec.decode(raw); val oTrail = AuroraCodec.lastTrail
                val b = AuroraCodec.decode(enc); val bTrail = AuroraCodec.lastTrail
                out.add(line("XML: asli ${o.size} B + $oTrail NUL • enkode ulang ${b.size} B + $bTrail NUL • isi identik: ${if (o.contentEquals(b)) "ya" else "TIDAK"}"))
            } finally { AuroraCodec.lastSeed = sv[0]; AuroraCodec.lastHashLength = sv[1]; AuroraCodec.lastPadTo = sv[2]; AuroraCodec.lastTrail = sv[3] }
            AuroraCodec.analyzeTail(raw).forEach { out.add(line(it)) }
        } catch (e: Throwable) { out.add(line("Uji bolak-balik gagal: ${e.javaClass.simpleName}: ${e.message}")) }
        return out
    }

    /** HUBUNGKAN: dekode save game (bila [cityId] diisi, pilih save milik kota itu), simpan ke sesi, buat cadangan pengaman. */
    fun connect(c: Context, cityId: String = ""): Outcome {
        val log = ArrayList<String>()
        try { log.add(line("Versi aplikasi: " + c.packageManager.getPackageInfo(c.packageName, 0).versionName)) } catch (_: Throwable) {}
        Session.reset()
        val id = cityId.trim()
        var cand: Cand? = null
        if (id.isNotEmpty()) {
            if (Env.gate(c) != Env.Gate.OK) return Outcome(false, listOf(line(S.t("gateVirt"))))
            cand = pickByCity(c, id, log) ?: return Outcome(false, log.ifEmpty { listOf(line(S.t("noGameData"))) })
        }
        val (xml0, raw) = readDisk(c, log, false, cand) ?: return Outcome(false, log)
        val root = lastRoot; val file = lastFile
        val b = CityBackup.backup(c, "auto")
        log.add(line(if (b.ok) "Cadangan dibuat" else "Cadangan gagal, dibatalkan"))
        if (!b.ok) return Outcome(false, log)
        Session.srcRoot = root; Session.srcFile = file; Session.cityId = id
        Session.xml = xml0; Session.rawSig = sig(raw); Session.rawSize = raw.size; Session.edits = 0
        log.add(line("Ukuran berkas save asli: ${raw.size} B"))
        log.addAll(roundTrip(raw, xml0))
        log.add(line("Sumber: $lastSrc"))
        if (file != null && GameFiles.isExternal(file))
            log.add(line("⚠ Save yang terbaca ada di penyimpanan eksternal (${file.absolutePath}), kemungkinan bukan save asli Township. Hapus berkas mGameInfo.xml/_ed_source di folder itu, buka Township sekali sampai masuk kota, lalu HUBUNGKAN lagi."))
        // Tutup Township otomatis: game yang masih hidup akan menimpa save lagi dan membuat editan tidak berubah.
        when (GameBridge.stop(c)) {
            true -> log.add(line("Township ditutup otomatis ✔"))
            false -> log.add(line("Peringatan: Township masih berjalan, tutup manual dari Recent Apps sebelum SIMPAN & KIRIM"))
            null -> log.add(line("Status Township tidak bisa dipastikan (sudah dicoba ditutup)"))
        }
        // Game bisa sempat menulis save saat ditutup: baca ulang supaya sesi memakai data final di disk.
        val fresh = readDisk(c, ArrayList(), true)
        if (fresh != null && sig(fresh.second) != Session.rawSig) {
            Session.xml = fresh.first; Session.rawSig = sig(fresh.second)
            log.add(line("Save diperbarui setelah game ditutup ✔"))
        }
        val xml = Session.xml ?: xml0
        val n = Stats.LIST.count { s -> TAGS[s.key]?.let { attr(xml, it) } != null }
        log.add(line("Dekode berhasil ✔ ${xml.length} karakter • $n/${Stats.LIST.size} statistik terbaca"))
        try { log.addAll(saveCopies(c)) } catch (e: Throwable) { log.add(line("Diagnosis salinan save gagal: ${e.javaClass.simpleName}: ${e.message}")) }
        try { log.addAll(valueProbe(c)) } catch (_: Throwable) {}
        try { log.addAll(ledgerProbe(xml)) } catch (_: Throwable) {}
        try { log.addAll(integrityProbe(c, xml)) } catch (_: Throwable) {}
        log.add(line("Terhubung ✔ ${if (id.isNotEmpty()) "ID kota $id. " else ""}Ubah data, lalu tekan SIMPAN & KIRIM."))
        return Outcome(true, log)
    }

    /** SIMPAN: enkode XML sesi, timpa save game, baca ulang untuk verifikasi. Tidak meluncurkan game. */
    fun saveBack(c: Context): Outcome {
        val log = ArrayList<String>()
        var xml = Session.xml ?: return Outcome(false, listOf(line("Belum terhubung — tekan HUBUNGKAN dulu")))
        if (!Session.dirty) return Outcome(false, listOf(line("Tidak ada perubahan yang diterapkan — nilai di kolom sama dengan isi save. Ubah angka lalu SIMPAN & KIRIM.")))
        val g = Env.gate(c); if (g != Env.Gate.OK) return Outcome(false, listOf(line(S.t("gateVirt"))))

        // 1. Matikan Township sebelum penulisan save
        when (GameBridge.stop(c)) {
            true -> log.add(line("Township dihentikan ✔"))
            false -> log.add(line("Peringatan: Township masih berjalan, penghentian otomatis gagal"))
            null -> log.add(line("Status Township tidak bisa dipastikan, tetap dilanjutkan"))
        }

        // 2. Sinkronkan ke disk bila save berubah
        val now = locate(c, true)?.let { try { it.readBytes() } catch (_: Exception) { null } }
        if (now != null && sig(now) != Session.rawSig) {
            val fresh = codec?.decode(now) ?: UniversalCodec.decode(now) ?: PlainCodec.decode(now)
            if (fresh != null && !Session.untracked) {
                val (merged, bad) = rebase(fresh)
                if (bad.isEmpty()) {
                    xml = merged
                    log.add(line("Save di disk disinkronkan dengan ${Session.changes.size} perubahan ✔"))
                }
            }
        }

        val enc = codec?.encode(xml) ?: UniversalCodec.encode(xml) ?: PlainCodec.encode(xml)
            ?: return Outcome(false, log + line("Encode gagal"))
        // Game memakai berkas save berukuran tetap: isi sisa ruang dengan byte nol agar ukurannya sama dengan save asli.
        val bytes = if (Session.rawSize > enc.size) enc.copyOf(Session.rawSize) else enc
        log.add(line("Ukuran enkode ${enc.size} B → ditulis ${bytes.size} B (asli ${Session.rawSize} B)"))

        // Proteksi Data: verifikasi integritas paket save sebelum menyentuh file game
        if (!verifyIntegrity(bytes)) {
            return Outcome(false, log + line("✘ Verifikasi integritas enkripsi gagal — penulisan dibatalkan demi keamanan data save."))
        }

        // Buat cadangan pengaman otomatis sebelum penulisan
        try {
            CityBackup.backup(c, "auto-safety", doPrune = true)
            log.add(line("Cadangan pengaman otomatis dibuat ✔"))
        } catch (_: Exception) {}

        val out = File(CityBackup.fetchDir(c), "mGameInfo.edited.xml")
        return try {
            try { out.writeBytes(bytes) } catch (_: Exception) {}
            val saved = writeBack(c, bytes, log)
                ?: return Outcome(false, log + line("Gagal menulis ke data game (tidak ada izin tulis) ✘"), launch = false)

            // 3. VERIFIKASI NYATA: baca ulang berkas yang SAMA, dekode, dan pastikan isinya = hasil editan.
            //    (Dulu "berhasil" hanya berarti ada satu berkas yang bisa ditulis -- bisa saja salinan di folder lain.)
            fun same(): Boolean? {
                val back = readDisk(c, ArrayList(), true) ?: return null
                return back.first.trim() == xml.trim()
            }
            if (same() != true) {
                return Outcome(false, log + line("✘ Verifikasi gagal: isi save di game tidak sama dengan editan ($saved). Township tidak diluncurkan."), launch = false)
            }
            try { Thread.sleep(1500) } catch (_: InterruptedException) {}
            if (same() != true) {
                return Outcome(false, log + line("✘ Save ditimpa kembali setelah ditulis (Township/ruang virtual masih menulis). Tutup Township dari Recent Apps lalu HUBUNGKAN ulang."), launch = false)
            }
            val back = readDisk(c, ArrayList(), true)
            Session.xml = xml
            if (back != null) Session.rawSig = sig(back.second)
            Session.edits = 0
            Session.changes.clear()
            log.add(line("Enkode & simpan berhasil ✔ terverifikasi (${bytes.size} byte, $saved)"))

            try { log.addAll(saveCopies(c)) } catch (e: Throwable) { log.add(line("Diagnosis salinan save gagal: ${e.javaClass.simpleName}: ${e.message}")) }

            // 4. Pastikan game mati sebelum peluncuran bersih
            GameBridge.stop(c)
            Outcome(true, log, launch = true)
        } catch (e: Exception) { Outcome(false, log + line("Gagal menulis: ${e.message}"), launch = false) }
    }

    val ALIASES: Map<String, List<String>> = mapOf(
        "moneyCash" to listOf("moneyCash", "cash", "Cash"),
        "money" to listOf("money", "coins", "coin", "Coins"),
        "levelup" to listOf("levelup", "level", "Level"),
        "expeditionEnergy" to listOf("expeditionEnergy", "energy", "Energy"),
        "m3_comp_lvls" to listOf("m3_comp_lvls", "m3_cur_lvl", "levelm3"),
        "FirstAttemptM3Levels" to listOf("FirstAttemptM3Levels", "firstwin"),
        "LivesSent" to listOf("LivesSent", "lives"),
        "CardsSent" to listOf("CardsSent", "cards"),
        "RegataTasksCompleted" to listOf("RegataTasksCompleted", "regatta"),
        "Achievement_Teamwork" to listOf("Achievement_Teamwork", "help"),
        "Achievement_EarthCenter" to listOf("Achievement_EarthCenter", "minedepth"),
        "gameStartDate" to listOf("gameStartDate")
    )

    /** Cocokkan `<Var ... name="tag" ... v="..."` (urutan atribut bebas), cadangan: atribut/tag polos. Grup 1 = awalan, 2 = nilai, 3 = akhiran. */
    private fun patterns(tag: String): List<Regex> {
        val t = Regex.escape(tag)
        return listOf(
            Regex("""(<Var\b[^>]*?\bname="$t"[^>]*?\bv=")([^"]*)(")"""),
            Regex("""(<Var\b[^>]*?\bv=")([^"]*)("[^>]*?\bname="$t"[^>]*?>)"""),
            Regex("""(\b$t\s*=\s*")([^"]*)(")"""),
            Regex("""(<$t>)([^<]*)(</$t>)""")
        )
    }

    private fun attr(xml: String, tag: String): String? {
        val allTags = ALIASES[tag] ?: listOf(tag)
        for (t in allTags) {
            val v = patterns(t).firstNotNullOfOrNull { it.find(xml)?.groupValues?.get(2) }
            if (v != null) return v
        }
        return null
    }

    private fun utc(sec: Long) = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC")).apply { timeInMillis = sec * 1000 }

    /** Detik Unix -> "MM/YYYY" (UTC). */
    fun monthYearOf(raw: String): String? = raw.trim().toDoubleOrNull()?.toLong()?.let {
        val c = utc(it); "%02d/%04d".format(c.get(java.util.Calendar.MONTH) + 1, c.get(java.util.Calendar.YEAR))
    }

    /** Ganti bulan & tahun pada detik Unix lama; hari (dibatasi ke akhir bulan) dan jam dipertahankan. */
    fun withMonthYear(oldRaw: String, my: String): String? {
        val old = oldRaw.trim().toDoubleOrNull()?.toLong() ?: return null
        val (mm, yy) = my.split("/").let { it[0].toInt() to it[1].toInt() }
        val c = utc(old); val day = c.get(java.util.Calendar.DAY_OF_MONTH)
        c.set(java.util.Calendar.DAY_OF_MONTH, 1); c.set(java.util.Calendar.YEAR, yy); c.set(java.util.Calendar.MONTH, mm - 1)
        c.set(java.util.Calendar.DAY_OF_MONTH, minOf(day, c.getActualMaximum(java.util.Calendar.DAY_OF_MONTH)))
        return (c.timeInMillis / 1000).toString()
    }

    private fun display(s: Stat, raw: String) = if (s.monthYear) monthYearOf(raw) else raw

    fun load(c: Context, fromDisk: Boolean = false): Loaded {
        val log = ArrayList<String>(); log.add(line("Membaca statistik profil..."))
        val xml = (if (fromDisk) readDisk(c, log)?.first else readXml(c, log)) ?: return Loaded(emptyMap(), log)
        val vals = LinkedHashMap<String, String>()
        for (s in Stats.LIST) { val t = TAGS[s.key] ?: continue; attr(xml, t)?.let { r -> display(s, r)?.let { vals[s.key] = it } } }
        log.add(line("Terbaca ${vals.size}/${Stats.LIST.size} nilai"))
        return Loaded(vals, log)
    }

    /** Ubah satu nilai, simpan ke save game, lalu baca ulang untuk memastikan. Cadangan otomatis dibuat dulu. @return pesan log. */
    fun apply(c: Context, s: Stat, input: String): List<String> {
        val log = ArrayList<String>()
        val tag = TAGS[s.key] ?: return listOf(line("${s.label}: belum dipetakan ke save (StatsEngine.TAGS)"))
        val n = if (s.monthYear) null else input.trim().toLongOrNull()
        val v = if (s.monthYear) input.trim().takeIf { Regex("""(0[1-9]|1[0-2])/\d{4}""").matches(it) }
                else n?.coerceIn(0, s.max)?.toString()
        if (v == null) return listOf(line("${s.label}: nilai tidak valid (${s.hint})"))
        if (n != null && n > s.max) log.add(line("${s.label}: melebihi batas aman, dipakai ${s.max}"))
        if (!needSession(log)) return log
        val xml = readXml(c, log) ?: return log

        val allTags = ALIASES[tag] ?: listOf(tag)
        var m: MatchResult? = null
        for (t in allTags) {
            val hit = patterns(t).firstNotNullOfOrNull { it.find(xml) }
            if (hit != null) {
                m = hit
                break
            }
        }

        val raw = if (s.monthYear) {
            val old = m?.groupValues?.get(2) ?: ""
            withMonthYear(old, v) ?: return log + line("${s.label}: nilai lama tidak bisa dibaca")
        } else v

        if (m != null) {
            val old = m.groupValues[2]
            var nx = xml.replaceRange(m.groups[2]!!.range, raw)
            if (s.key == "tcash" || s.key == "coin") {
                val oldN = old.trim().toLongOrNull()
                val newN = v.toLongOrNull()
                if (oldN != null && newN != null) nx = syncLedger(nx, s.key, newN - oldN, newN, log)
                else log.add(line("Buku kas ${s.label} dilewati: nilai lama '$old' bukan angka bulat — save mungkin ditolak game"))
            }
            stage(nx)
            return log + line("${s.label}: ${display(s, old)} → $v  ✔ disiapkan (belum disimpan)") + line("Tekan SIMPAN & KIRIM untuk menulis ke game.")
        } else {
            val globalMatch = Regex("""(<Global\b[^>]*>)""").find(xml)
            if (globalMatch != null) {
                val newVar = "\n    <Var name=\"$tag\" v=\"$raw\" t=\"i\"/>"
                stage(xml.replaceRange(globalMatch.range, globalMatch.value + newVar))
                return log + line("${s.label}: $v  ✔ ditambahkan ke save (belum disimpan)") + line("Tekan SIMPAN & KIRIM untuk menulis ke game.")
            }
            return log + line("${s.label}: '$tag' tidak ada di save")
        }
    }

    private val varAny = Regex("""(<Var\b[^>]*?\bname="[^"]*"[^>]*?\bv=")([^"]*)(")""")
    private val nameOf = Regex("""\bname="([^"]*)"""")

    private fun numOf(s: String?): Long? = s?.trim()?.let { it.toLongOrNull() ?: it.toDoubleOrNull()?.toLong() }

    /** Cari Var buku kas: nama baku dulu, bila tidak ada cari Var yang namanya cocok [like]. Grup 2 = nilai. */
    private fun findLedger(xml: String, name: String, like: Regex): MatchResult? =
        patterns(name).firstNotNullOfOrNull { it.find(xml) }
            ?: varAny.findAll(xml).firstOrNull { m -> nameOf.find(m.value)?.groupValues?.get(1)?.let { like.containsMatchIn(it) } == true }

    /**
     * Game menyimpan buku kas anti-edit: T-Cash: startCash + earnedCash - spentCash = moneyCash;
     * Koin: (awal) + EarnedCoins - Achievement_SpentCoins = money. Mengubah saldo tanpa buku kas membuat save dianggap
     * tidak sah (game memuat cadangan). Di sini selisih saldo dimasukkan ke earnedCash / EarnedCoins sehingga selisihnya tetap konsisten.
     */
    private fun syncLedger(xml: String, key: String, delta: Long, balance: Long, log: MutableList<String>): String {
        if (delta == 0L) return xml
        val cash = key == "tcash"
        val earnedName = if (cash) "earnedCash" else "EarnedCoins"
        val spentName = if (cash) "spentCash" else "Achievement_SpentCoins"
        val earnedLike = if (cash) Regex("(?i)earned.*cash|cash.*earn") else Regex("(?i)earned.*coin|coin.*earn")
        val spentLike = if (cash) Regex("(?i)spent.*cash|cash.*spen") else Regex("(?i)spent.*coin|coin.*spen")
        val me = findLedger(xml, earnedName, earnedLike); val ms = findLedger(xml, spentName, spentLike)
        val e0 = numOf(me?.groupValues?.get(2))
        if (me == null || e0 == null) { log.add(line("Buku kas $earnedName tidak ditemukan — nilai diubah tanpa buku kas (game mungkin menolak)")); return xml }
        val sp0 = numOf(ms?.groupValues?.get(2))
        var e = e0 + delta
        var sp = sp0
        if (e < 0) { if (sp != null) sp -= e; e = 0 }                       // saldo turun lebih dari total pendapatan: naikkan pengeluaran
        val cap = 2147483647L
        if (e > cap) { log.add(line("Buku kas $earnedName melebihi batas int32 — dipotong (buku kas jadi tidak cocok dengan saldo)")); e = cap }
        var out = xml
        // ganti dari belakang agar rentang indeks tidak bergeser
        val edits = ArrayList<Pair<IntRange, String>>()
        edits.add(me.groups[2]!!.range to e.toString())
        if (ms != null && sp != null && sp != sp0) edits.add(ms.groups[2]!!.range to sp.toString())
        for ((r, t) in edits.sortedByDescending { it.first.first }) out = out.replaceRange(r, t)
        log.add(line("Buku kas: $earnedName $e0 → $e" + (if (ms != null && sp != null) " (spent=$sp)" else " (Var spent tidak ditemukan)")))
        // Pemeriksaan mandiri: awal tersirat = saldo - earned + spent harus sama sebelum & sesudah edit.
        if (sp0 != null && sp != null) {
            val before = (balance - delta) - e0 + sp0
            val after = balance - e + sp
            log.add(line("Cek buku kas ${if (cash) "T-Cash" else "Koin"}: awal tersirat sebelum=$before, sesudah=$after " + if (before == after) "✔ cocok" else "✘ TIDAK cocok (game kemungkinan menolak save)"))
        }
        return out
    }

    /** Diagnosis (hanya baca): semua Var terkait koin/uang/kas + peringatan bila satu nama muncul lebih dari sekali. */
    private fun ledgerProbe(xml: String): List<String> {
        val out = ArrayList<String>()
        val sus = Regex("(?i)coin|money|cash|earn|spent|spend")
        val hits = varAny.findAll(xml).mapNotNull { m ->
            val n = nameOf.find(m.value)?.groupValues?.get(1) ?: return@mapNotNull null
            if (sus.containsMatchIn(n)) n + "=" + m.groupValues[2].take(20) else null
        }.take(60).toList()
        out.add(line("Var terkait koin/uang/kas (${hits.size}): " + hits.joinToString(", ")))
        for (nm in listOf("money", "moneyCash", "EarnedCoins", "Achievement_SpentCoins", "earnedCash", "spentCash")) {
            val n = Regex("""\bname="${Regex.escape(nm)}"""").findAll(xml).count()
            if (n > 1) out.add(line("⚠ Var '$nm' muncul $n kali di save — editan hanya mengubah yang pertama"))
        }
        return out
    }

    /** Verifikasi integritas paket byte save sebelum ditulis ke disk (mencegah korupsi data). */
    fun verifyIntegrity(bytes: ByteArray): Boolean {
        if (bytes.size < 32) return false
        val dec = UniversalCodec.decode(bytes) ?: PlainCodec.decode(bytes) ?: return false
        val trimmed = dec.trimStart()
        if (!trimmed.startsWith("<")) return false
        return dec.contains("<Global") || dec.contains("<Var") || dec.contains("<Township")
    }

    /** Cek apakah data save di disk telah berubah secara eksternal (oleh game). */
    fun checkDiskSync(c: Context): Boolean {
        if (!Session.connected || Session.rawSig == 0L) return false
        val f = locate(c, pin = true) ?: return false
        val raw = try { f.readBytes() } catch (_: Exception) { return false }
        if (raw.isEmpty()) return false
        return sig(raw) != Session.rawSig
    }

    /**
     * Timpa HANYA save yang dipakai saat HUBUNGKAN (berkas yang sama dengan yang didekode), plus cermin `_ed_source`
     * di folder yang sama bila memang sudah ada. Tidak lagi menulis ke semua folder kandidat: itu membuat berkas
     * "tiruan" di /sdcard/Android/data dan menimpa save kota lain, sambil melaporkan sukses palsu.
     * @return deskripsi target ("root: path" / "langsung: path") bila berhasil, null bila gagal.
     */
    private fun writeBack(c: Context, bytes: ByteArray, log: MutableList<String>): String? {
        if (!verifyIntegrity(bytes)) return null
        val tmp = File(c.cacheDir, "mGameInfo.push.${System.currentTimeMillis()}.tmp")
        try {
            tmp.writeBytes(bytes)
            tmp.setReadable(true, false)

            val rootDst = Session.srcRoot
            val fileDst = Session.srcFile
            if (rootDst != null) {
                // `cat >` mempertahankan inode, pemilik & label SELinux berkas game (cp -f bisa membuat ulang sebagai root).
                val parent = rootDst.substringBeforeLast('/')
                var ok = RootShell.exec("cat '${tmp.absolutePath}' > '$rootDst'", 30_000)?.code == 0
                if (!ok) ok = RootShell.exec("cp '${tmp.absolutePath}' '$rootDst'", 30_000)?.code == 0
                if (!ok) { log.add(line("Tulis root gagal: $rootDst")); return null }
                RootShell.exec("[ -f '$parent/_ed_source' ] && cat '${tmp.absolutePath}' > '$parent/_ed_source'", 30_000)
                return "root: $rootDst"
            }
            if (fileDst != null) {
                if (!writeFile(fileDst, bytes)) { log.add(line("Tulis langsung gagal: ${fileDst.absolutePath}")); return null }
                File(fileDst.parentFile, "_ed_source").let { if (it.exists()) writeFile(it, bytes) }
                return "langsung: ${fileDst.absolutePath}"
            }
            log.add(line("Sumber save tidak diketahui — HUBUNGKAN ulang"))
            return null
        } finally {
            try { tmp.delete() } catch (_: Exception) {}
        }
    }

    /** Diagnosis (hanya baca): cari tanda pengaman/checksum di XML save dan intip berkas pendamping yang ditulis game bersamaan. */
    private fun integrityProbe(c: Context, xml: String): List<String> {
        val out = ArrayList<String>()
        fun clip(t: String, n: Int) = t.replace(Regex("\\s+"), " ").take(n)
        out.add(line("Awal XML: " + clip(xml, 260)))
        out.add(line("Akhir XML: " + clip(xml.takeLast(260), 260)))
        for (nm in listOf("money", "moneyCash")) {
            val m = Regex("<Var\\b[^>]*\\bname=\"$nm\"[^>]*>").find(xml)
            if (m != null) {
                val a = maxOf(0, m.range.first - 120); val b = minOf(xml.length, m.range.last + 120)
                out.add(line("Sekitar $nm: " + clip(xml.substring(a, b), 360)))
            }
        }
        val sus = Regex("(?i)hash|sign|sig\\b|check|crc|md5|sha|sum|valid|secure|tamper|cheat|salt|counter|saveid|savecount|version|lastsave|savetime|timestamp")
        val names = Regex("<Var\\b[^>]*\\bname=\"([^\"]+)\"[^>]*\\bv=\"([^\"]*)\"").findAll(xml)
            .filter { sus.containsMatchIn(it.groupValues[1]) }.take(40)
            .map { it.groupValues[1] + "=" + it.groupValues[2].take(30) }.toList()
        out.add(line("Var bernama pengaman/versi (${names.size}): " + names.joinToString(", ")))
        if (Env.rootVerified == true) {
            val src = "/data/data/${GameBridge.PACKAGE}/saves"
            val m0 = UniversalCodec.mode; val s0 = AuroraCodec.lastSeed; val h0 = AuroraCodec.lastHashLength; val p0 = AuroraCodec.lastPadTo; val t0 = AuroraCodec.lastTrail
            try {
                for (n in listOf("ProgressComplainer.xml", "StartupConsts.xml", "LocalInfo.xml")) {
                    val f = File(c.cacheDir, "probe2_$n.tmp")
                    try {
                        if (!RootShell.pipeTo("cat '$src/$n'", f, 30_000)) { out.add(line("$n: tidak terbaca")); continue }
                        val raw = f.readBytes()
                        val txt = UniversalCodec.decode(raw) ?: String(raw, Charsets.ISO_8859_1).map { if (it in ' '..'~') it else '.' }.joinToString("")
                        out.add(line("$n (${raw.size} B): " + clip(txt, if (n == "LocalInfo.xml") 400 else 500)))
                    } finally { try { f.delete() } catch (_: Exception) {} }
                }
                val f = File(c.cacheDir, "probe2_cm.tmp")
                try {
                    if (RootShell.pipeTo("head -c 48 '$src/cmtracking.bin'", f, 10_000))
                        out.add(line("cmtracking.bin awal (hex): " + f.readBytes().joinToString(" ") { "%02x".format(it) }))
                } finally { try { f.delete() } catch (_: Exception) {} }
            } catch (e: Throwable) {
                out.add(line("Diagnosis berkas pendamping gagal: ${e.message}"))
            } finally {
                UniversalCodec.mode = m0; AuroraCodec.lastSeed = s0; AuroraCodec.lastHashLength = h0; AuroraCodec.lastPadTo = p0; AuroraCodec.lastTrail = t0
            }
        }
        return out
    }

    /** Diagnosis: nilai money/moneyCash di tiap berkas save (didekode terpisah; state codec dipulihkan agar tidak mengganggu penyimpanan). */
    private fun valueProbe(c: Context): List<String> {
        val out = ArrayList<String>()
        if (Env.rootVerified != true) return out
        val src = "/data/data/${GameBridge.PACKAGE}/saves"
        val m0 = UniversalCodec.mode; val s0 = AuroraCodec.lastSeed; val h0 = AuroraCodec.lastHashLength; val p0 = AuroraCodec.lastPadTo; val t0 = AuroraCodec.lastTrail
        try {
            out.add(line("Nilai money / moneyCash di tiap berkas save:"))
            for (n in listOf("mGameInfo.xml", "mGameInfo.bak", "_ed_source", "LocalInfo.xml", "GlobalVars.xml")) {
                val f = File(c.cacheDir, "probe_$n.tmp")
                try {
                    if (!RootShell.pipeTo("cat '$src/$n'", f, 30_000)) { out.add(line("  $n: tidak terbaca")); continue }
                    val raw = f.readBytes()
                    val xml = UniversalCodec.decode(raw)
                    if (xml == null) { out.add(line("  $n: ${raw.size} B, tidak bisa didekode")); continue }
                    val vals = listOf("money", "moneyCash").map { t -> t + "=" + (patterns(t).firstNotNullOfOrNull { it.find(xml)?.groupValues?.get(2) } ?: "-") }
                    out.add(line("  $n: ${raw.size} B • ${vals.joinToString("  ")}"))
                } finally { try { f.delete() } catch (_: Exception) {} }
            }
        } catch (e: Throwable) {
            out.add(line("Diagnosis nilai gagal: ${e.message}"))
        } finally {
            UniversalCodec.mode = m0; AuroraCodec.lastSeed = s0; AuroraCodec.lastHashLength = h0; AuroraCodec.lastPadTo = p0; AuroraCodec.lastTrail = t0
        }
        return out
    }

    /** Daftar semua berkas save/cermin di data Township (waktu ubah, ukuran, path) untuk mendeteksi salinan lain yang dibaca game. */
    fun saveCopies(c: Context): List<String> {
        val out = ArrayList<String>()
        val fmt = SimpleDateFormat("dd/MM HH:mm:ss", Locale.US)
        val src = "/data/data/${GameBridge.PACKAGE}"
        val used = Session.srcRoot ?: Session.srcFile?.absolutePath
        fun row(sec: Long, size: Long, path: String) {
            val mark = if (path == used) "  ◀ ditulis tool" else ""
            out.add(line("  ${fmt.format(Date(sec * 1000))} • $size B • ${path.substringAfter(GameBridge.PACKAGE, path)}$mark"))
        }
        if (Env.rootVerified == true) {
            val t = RootShell.exec("find $src \\( -name 'mGameInfo*' -o -name '_ed_source*' -o -name '*.sav' \\) -type f -exec stat -c '%Y %s %n' {} +", 15000)
                ?.text?.lines()?.map { it.trim() }?.filter { it.isNotEmpty() }.orEmpty()
            for (l in t) {
                val p = l.split(" ", limit = 3)
                if (p.size == 3) row(p[0].toLongOrNull() ?: 0L, p[1].toLongOrNull() ?: 0L, p[2])
            }
            out.add(line("  -- semua berkas di saves/ & files/ (waktu • ukuran • path) --"))
            val all = RootShell.exec("find $src/saves $src/files $src/shared_prefs -type f -exec stat -c '%y %s %n' {} + 2>&1 | sort -r | head -60", 20000)
            if (all == null) out.add(line("  (perintah root tidak menghasilkan apa pun / root tidak tersedia)"))
            else all.text.lines().map { it.trim() }.filter { it.isNotEmpty() }.forEach { out.add(line("  " + it.replace(src + "/", "").replace(Regex("\\.\\d+ \\+\\d+"), ""))) }
            val dirs = RootShell.exec("ls -A '$src' 2>/dev/null", 8000)?.text?.lines()?.map { it.trim() }?.filter { it.isNotEmpty() }.orEmpty()
            if (dirs.isNotEmpty()) out.add(line("  Isi $src: ${dirs.joinToString(", ")}"))
        } else {
            for (d in GameFiles.allDataDirs(c)) for (n in listOf("mGameInfo.xml", "_ed_source"))
                GameFiles.find(d, n).forEach { row(it.lastModified() / 1000, it.length(), it.absolutePath) }
        }
        val xmlCount = out.count { it.contains("mGameInfo") && !it.contains("_ed_source") }
        if (xmlCount > 1) out.add(0, line("⚠ Ada $xmlCount salinan mGameInfo — game bisa membaca salinan lain. Daftar:"))
        else out.add(0, line("Salinan save yang ditemukan:"))
        return out
    }

    private fun writeFile(f: File, bytes: ByteArray): Boolean = try {
        if (f.exists() && !f.canWrite()) f.setWritable(true, false)
        java.io.FileOutputStream(f, false).use { it.write(bytes); it.flush(); it.fd.sync() }
        f.setLastModified(System.currentTimeMillis())
        true
    } catch (_: Exception) { false }

    /** Ubah semua `<Var name="PREFIX..." v="0">` di save menjadi 1 (bendera "terbuka"). Cadangan otomatis dibuat dulu. */
    fun unlockFlags(c: Context, label: String, prefix: String): List<String> {
        val log = ArrayList<String>()
        if (!needSession(log)) return log
        val xml = readXml(c, log) ?: return log
        val p = Regex.escape(prefix)
        val all = Regex("<Var\\s+name=\"" + p + "[^\"]*\"")
        val locked = Regex("(<Var\\s+name=\"" + p + "[^\"]*\"\\s+v=\")0(\")")
        val total = all.findAll(xml).count()
        if (total == 0) return log + line("$label: data '$prefix' tidak ada di save")
        val n = locked.findAll(xml).count()
        if (n == 0) return log + line("$label: semua $total sudah terbuka ✔")
        val new = locked.replace(xml) { it.groupValues[1] + "1" + it.groupValues[2] }
        return commit(c, new, "$label: $n dibuka dari $total", log) { true }
    }

    // ---------- Editor elemen (kupon, upgrade), Zoo, dan alat XML ----------
    class Elem(val name: String, val id: String, val attrs: Map<String, String>)
    class Paddock(val type: String, val done: Int, val total: Int)

    private val attrRe = Regex("(\\w+)=\"([^\"]*)\"")

    /** Rentang isi `<name ...> ... </name>` pertama. */
    private fun section(xml: String, name: String): IntRange? =
        Regex("<" + name + "(\\s[^>]*)?>(.*?)</" + name + ">", RegexOption.DOT_MATCHES_ALL).find(xml)?.groups?.get(2)?.range

    private fun withAttr(tag: String, k: String, v: String): String? {
        val re = Regex("(\\b" + k + "=\")([^\"]*)(\")")
        val m = re.find(tag) ?: return null
        return tag.replaceRange(m.range, m.groupValues[1] + v + m.groupValues[3])
    }

    /** Simpan XML hasil edit ke sesi (belum ke game; SIMPAN & KIRIM yang menulis), lalu periksa dengan [check]. */
    @Suppress("UNUSED_PARAMETER")
    private fun commit(c: Context, new: String, label: String, log: MutableList<String>, check: (String) -> Boolean): List<String> {
        if (!check(new)) return log + line("$label: perubahan tidak tercatat ✘ gagal")
        stage(new)
        return log + line("$label  ✔ disiapkan (belum disimpan)") + line("Tekan SIMPAN & KIRIM untuk menulis ke game.")
    }

    /** Daftar elemen bernama [names] yang punya atribut id di dalam bagian [sec]. */
    fun listElems(c: Context, sec: String, names: List<String>): Pair<List<Elem>, List<String>> {
        val log = ArrayList<String>()
        val xml = readXml(c, log) ?: return emptyList<Elem>() to log
        val r = section(xml, sec) ?: return emptyList<Elem>() to (log + line("Bagian '$sec' tidak ada di save"))
        val tagRe = Regex("<(" + names.joinToString("|") + ")\\s([^>]*?)/?>")
        val out = tagRe.findAll(xml.substring(r.first, r.last + 1)).mapNotNull { m ->
            val a = attrRe.findAll(m.groupValues[2]).associate { it.groupValues[1] to it.groupValues[2] }
            a["id"]?.let { Elem(m.groupValues[1], it, a) }
        }.toList()
        log.add(line("$sec: ${out.size} item terbaca"))
        return out to log
    }

    /** Ubah satu atribut pada elemen (sec › name[id]). [syncSlx]: jaga selisih `slx` terhadap `level` seperti data asli. */
    fun setElem(c: Context, sec: String, name: String, id: String, attr: String, value: String, syncSlx: Boolean = false): List<String> {
        val log = ArrayList<String>()
        if (!needSession(log)) return log
        val xml = readXml(c, log) ?: return log
        val r = section(xml, sec) ?: return log + line("Bagian '$sec' tidak ada di save")
        val tagRe = Regex("<" + name + "\\s([^>]*?)/?>")
        val m = tagRe.findAll(xml, r.first).takeWhile { it.range.first <= r.last }.firstOrNull { x ->
            attrRe.findAll(x.groupValues[1]).any { it.groupValues[1] == "id" && it.groupValues[2] == id }
        } ?: return log + line("$id: tidak ditemukan di $sec")
        val tag = m.value
        val old = attrRe.findAll(tag).firstOrNull { it.groupValues[1] == attr }?.groupValues?.get(2)
        var nt = withAttr(tag, attr, value) ?: return log + line("$id: atribut '$attr' tidak ada")
        if (syncSlx) {
            val slx = attrRe.findAll(tag).firstOrNull { it.groupValues[1] == "slx" }?.groupValues?.get(2)?.toLongOrNull()
            val o = old?.toLongOrNull(); val n = value.toLongOrNull()
            if (slx != null && o != null && n != null) nt = withAttr(nt, "slx", (slx - o + n).toString()) ?: nt
        }
        val new = xml.replaceRange(m.range, nt)
        return commit(c, new, "$id: $attr ${old ?: "-"} → $value", log) { it.contains(nt) }
    }

    private val zooRe = Regex("(<ZooInfo\\b[^>]*?\\bPaddocks=\")([^\"]*)(\")")
    private fun unesc(s: String) = s.replace("&quot;", "\"").replace("&lt;", "<").replace("&gt;", ">").replace("&apos;", "'").replace("&amp;", "&")
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
    private val ZOO_PIECES = intArrayOf(30, 30, 15, 10)

    fun zooList(c: Context): Pair<List<Paddock>, List<String>> {
        val log = ArrayList<String>()
        val xml = readXml(c, log) ?: return emptyList<Paddock>() to log
        val m = zooRe.find(xml) ?: return emptyList<Paddock>() to (log + line("Data kandang zoo tidak ada di save"))
        val arr = try { org.json.JSONObject(unesc(m.groupValues[2])).getJSONArray("list") } catch (e: Exception) { return emptyList<Paddock>() to (log + line("Data zoo tidak terbaca")) }
        val out = (0 until arr.length()).map { i ->
            val p = arr.getJSONObject(i); val mem = p.optJSONArray("members"); val t = mem?.length() ?: 0
            var d = 0; for (j in 0 until t) if (mem!!.getJSONObject(j).optInt("status") >= 3) d++
            Paddock(p.optString("type"), d, t)
        }
        log.add(line("Zoo: ${out.size} kandang")); return out to log
    }

    /** Selesaikan anggota kandang (status 3 + jumlah kepingan penuh). [only] = tipe kandang, null = semua. */
    fun zooComplete(c: Context, only: String?): List<String> {
        val log = ArrayList<String>()
        if (!needSession(log)) return log
        val xml = readXml(c, log) ?: return log
        val m = zooRe.find(xml) ?: return log + line("Data kandang zoo tidak ada di save")
        val json = try { org.json.JSONObject(unesc(m.groupValues[2])) } catch (e: Exception) { return log + line("Data zoo tidak terbaca") }
        val arr = json.getJSONArray("list"); var n = 0
        for (i in 0 until arr.length()) {
            val p = arr.getJSONObject(i); if (only != null && p.optString("type") != only) continue
            val mem = p.optJSONArray("members") ?: continue
            for (j in 0 until mem.length()) {
                val mo = mem.getJSONObject(j); val need = ZOO_PIECES[minOf(j, 3)]
                if (mo.optInt("status") < 3 || mo.optInt("piecesCount") < need) { mo.put("status", 3); mo.put("piecesCount", maxOf(need, mo.optInt("piecesCount"))); n++ }
            }
        }
        if (n == 0) return log + line("Zoo: semuanya sudah selesai ✔")
        val enc = esc(json.toString())
        return commit(c, xml.replaceRange(m.groups[2]!!.range, enc), "Zoo: $n anggota diselesaikan", log) { it.contains(enc) }
    }

    /** Dekode save ke XML terbaca di folder fetch. */
    fun decodeToFile(c: Context): List<String> {
        val log = ArrayList<String>()
        val xml = readDisk(c, log)?.first ?: return log
        val out = File(CityBackup.fetchDir(c), "mGameInfo.decoded.xml")
        return try { out.writeText(xml, Charsets.UTF_8); log + line("Dekode selesai ✔ ${xml.length} karakter") + line(out.absolutePath) } catch (e: Exception) { log + line("Gagal menulis: ${e.message}") }
    }

    /** Enkode `mGameInfo.decoded.xml` ke format game (disimpan di folder fetch, tidak menimpa data game). */
    fun encodeFromFile(c: Context): List<String> {
        val log = ArrayList<String>()
        val src = File(CityBackup.fetchDir(c), "mGameInfo.decoded.xml")
        if (!src.exists()) return log + line("mGameInfo.decoded.xml belum ada — jalankan Dekode dulu")
        readDisk(c, log) ?: return log   // mengenali format asli save lebih dulu
        val bytes = codec?.encode(src.readText(Charsets.UTF_8)) ?: return log + line("Encode gagal")
        val out = File(CityBackup.fetchDir(c), "mGameInfo.encoded")
        return try { out.writeBytes(bytes); log + line("Enkode selesai ✔ ${bytes.size} byte") + line(out.absolutePath) } catch (e: Exception) { log + line("Gagal menulis: ${e.message}") }
    }

    /** Tutorial macet: induk `X_state` bernilai 13/15 (sedang berjalan) dijadikan 18 (selesai), anak `Xsq#_state` jadi 0 — pola yang sama dengan tutorial selesai di save. */
    fun fixTutorials(c: Context): List<String> {
        val log = ArrayList<String>()
        if (!needSession(log)) return log
        val xml = readXml(c, log) ?: return log
        val re = Regex("(<Var\\s+name=\")([^\"]+)(_state\"\\s+v=\")(\\d+)(\")")
        val sq = Regex("sq\\d+$")
        val stuck = re.findAll(xml).filter { !sq.containsMatchIn(it.groupValues[2]) && (it.groupValues[4] == "13" || it.groupValues[4] == "15") }.map { it.groupValues[2] }.toSet()
        if (stuck.isEmpty()) return log + line("Tutorial: tidak ada yang macet ✔")
        val new = re.replace(xml) { m ->
            val base = m.groupValues[2]; val root = base.replace(sq, "")
            if (root in stuck) m.groupValues[1] + base + m.groupValues[3] + (if (base == root) "18" else "0") + m.groupValues[5] else m.value
        }
        log.add(line("Tutorial macet: ${stuck.size} → ${stuck.take(6).joinToString(", ")}${if (stuck.size > 6) " …" else ""}"))
        return commit(c, new, "Tutorial: ${stuck.size} diperbaiki", log) { x -> stuck.none { Regex("name=\"" + Regex.escape(it) + "_state\"\\s+v=\"(13|15)\"").containsMatchIn(x) } }
    }

    fun setVar(xml: String, name: String, value: String, type: String = "i"): String {
        val t = Regex.escape(name)
        val p1 = Regex("""(<Var\b[^>]*?\bname="$t"[^>]*?\bv=")([^"]*)(")""")
        val m1 = p1.find(xml)
        if (m1 != null) {
            return xml.replaceRange(m1.groups[2]!!.range, value)
        }
        val p2 = Regex("""(<Var\b[^>]*?\bv=")([^"]*)("[^>]*?\bname="$t"[^>]*?>)""")
        val m2 = p2.find(xml)
        if (m2 != null) {
            return xml.replaceRange(m2.groups[2]!!.range, value)
        }
        val g = Regex("""(<Global\b[^>]*>)""").find(xml)
        if (g != null) {
            val entry = "\n    <Var name=\"$name\" v=\"$value\" t=\"$type\"/>"
            return xml.substring(0, g.range.last + 1) + entry + xml.substring(g.range.last + 1)
        }
        return xml
    }

    private fun setDataElem(xml: String, name: String, items: List<String>): String {
        val re = Regex("""(<DataElem\b[^>]*?\bname="$name"[^>]*?\bvalue=")([^"]*)(")""")
        val joined = items.joinToString(",")
        if (re.containsMatchIn(xml)) {
            return re.replace(xml) { it.groupValues[1] + joined + it.groupValues[3] }
        }
        val g = Regex("""(<Global\b[^>]*>)""").find(xml)
        if (g != null) {
            val elem = "\n    <DataElem name=\"$name\" type=\"string\" value=\"$joined\"/>"
            return xml.substring(0, g.range.last + 1) + elem + xml.substring(g.range.last + 1)
        }
        return xml
    }

    private const val PROFILE_KEY = "oKb7v5nKmwq5PCttj259Cw33D7zONrgV"
    private const val PROFILE_SUFFIX = "\nabcdefgh"

    private fun encodeProfileId(id: String): String {
        val p = id + PROFILE_SUFFIX
        val n = p.length
        val b = ByteArray(n) { i -> (p[i].code xor PROFILE_KEY[(n + i) % 32].code).toByte() }
        return android.util.Base64.encodeToString(b, android.util.Base64.NO_WRAP)
    }

    fun unlockMultiFlags(c: Context, label: String, prefixes: List<String>): List<String> {
        val log = ArrayList<String>()
        if (!needSession(log)) return log
        val xml = readXml(c, log) ?: return log
        var cur = xml
        var count = 0
        for (prefix in prefixes) {
            val p = Regex.escape(prefix)
            val locked = Regex("""(<Var\b[^>]*?\bname="$p[^"]*"[^>]*?\bv=")0(")""")
            val cFound = locked.findAll(cur).count()
            if (cFound > 0) {
                cur = locked.replace(cur) { it.groupValues[1] + "1" + it.groupValues[2] }
                count += cFound
            }
        }
        val msg = if (count > 0) "$label: $count item dibuka ✔" else "$label: semua sudah terbuka ✔"
        return commit(c, cur, msg, log) { true }
    }

    fun unlockDecor(c: Context): List<String> =
        unlockMultiFlags(c, "Dekorasi", listOf("Unlocked_dec", "Unlocked_decor", "Decor_", "Dec_"))

    fun unlockLand(c: Context): List<String> {
        val log = ArrayList<String>()
        if (!needSession(log)) return log
        val xml = readXml(c, log) ?: return log
        var cur = xml
        for (prefix in listOf("Expansion_", "Territory_", "Land_", "ExpansionPlot_")) {
            val p = Regex.escape(prefix)
            val locked = Regex("""(<Var\b[^>]*?\bname="$p[^"]*"[^>]*?\bv=")0(")""")
            cur = locked.replace(cur) { it.groupValues[1] + "1" + it.groupValues[2] }
        }
        cur = setVar(cur, "ExpansionsUnlocked", "1")
        cur = setVar(cur, "FreeExpansions", "100")
        cur = setVar(cur, "ToolsForExpansions", "0")
        return commit(c, cur, "Tanah: perluasan wilayah kota dibuka ✔", log) { true }
    }

    fun unlockMuseum(c: Context): List<String> {
        val log = ArrayList<String>()
        if (!needSession(log)) return log
        val xml = readXml(c, log) ?: return log
        var cur = xml
        for (prefix in listOf("Museum_", "Artifact_", "Exhibit_")) {
            val p = Regex.escape(prefix)
            val locked = Regex("""(<Var\b[^>]*?\bname="$p[^"]*"[^>]*?\bv=")0(")""")
            cur = locked.replace(cur) { it.groupValues[1] + "1" + it.groupValues[2] }
        }
        cur = setVar(cur, "MuseumCompleted", "1")
        return commit(c, cur, "Museum: semua pameran museum diselesaikan ✔", log) { true }
    }

    fun unlockAllCards(c: Context): List<String> {
        val log = ArrayList<String>()
        if (!needSession(log)) return log
        val xml = readXml(c, log) ?: return log
        var cur = setVar(xml, "CardsSent", "10000")
        cur = setVar(cur, "AllCardsCollected", "1")
        for (prefix in listOf("Unlocked_card_", "Card_")) {
            val p = Regex.escape(prefix)
            val locked = Regex("""(<Var\b[^>]*?\bname="$p[^"]*"[^>]*?\bv=")0(")""")
            cur = locked.replace(cur) { it.groupValues[1] + "1" + it.groupValues[2] }
        }
        return commit(c, cur, "Semua Kartu: koleksi kartu dibuka ✔", log) { true }
    }

    fun upgradeMyCards(c: Context): List<String> {
        val log = ArrayList<String>()
        val zooRes = zooComplete(c, null)
        log.addAll(zooRes)
        val xml = readXml(c, log) ?: return log
        val cur = setVar(xml, "CardsUpgraded", "1")
        return commit(c, cur, "Kartu Saya: level & kepingan kartu dimaksimalkan ✔", log) { true }
    }

    fun unlockSkins(c: Context): List<String> =
        unlockMultiFlags(c, "Skin", listOf("Unlocked_skin", "Skin_", "Unlocked_train_skin", "Unlocked_heli_skin", "Unlocked_plane_skin"))

    fun unlockStickers(c: Context): List<String> =
        unlockMultiFlags(c, "Stiker", listOf("Unlocked_sticker", "Unlocked_stick", "Sticker_", "ChatSticker_"))

    fun unlockProfile(c: Context): List<String> {
        val log = ArrayList<String>()
        if (!needSession(log)) return log
        val xml = readXml(c, log) ?: return log
        var cur = xml
        val frameIds = (1..60).map { "frame_$it" } + listOf("frame_vip", "frame_golden", "frame_default", "frame_holiday", "frame_regatta", "frame_anniversary", "frame_champion")
        cur = setDataElem(cur, "UnlockedFrames", frameIds.map { encodeProfileId(it) })
        val badgeIds = (1..40).map { "badge_$it" } + listOf("badge_vip", "badge_star", "badge_top")
        cur = setDataElem(cur, "UnlockedBadges", badgeIds.map { encodeProfileId(it) })
        val rankIds = (1..30).map { "rank_$it" }
        cur = setDataElem(cur, "UnlockedExpRanks", rankIds.map { encodeProfileId(it) })
        val styles = (1..20).map { "style_$it" } + listOf("default", "vip_style")
        cur = setDataElem(cur, "UnlockedStyles", styles)
        cur = setVar(cur, "MyFrame", "frame_1", "s")
        cur = setVar(cur, "MyStyle", "default", "s")
        return commit(c, cur, "Profil: semua frame, badge, style & rank dibuka ✔", log) { true }
    }

    fun unlockAchievements(c: Context): List<String> {
        val log = ArrayList<String>()
        if (!needSession(log)) return log
        val xml = readXml(c, log) ?: return log
        val re = Regex("""(<Var\b[^>]*?\bname="Achievement_[^"]*"[^>]*?\bv=")([^"]*)(")""")
        val matches = re.findAll(xml).toList()
        var cur = xml
        if (matches.isNotEmpty()) {
            cur = re.replace(cur) { it.groupValues[1] + "1000000" + it.groupValues[3] }
        }
        val achvs = listOf("Achievement_Teamwork", "Achievement_EarthCenter", "Achievement_Harvest", "Achievement_Delivery", "Achievement_Champion")
        for (a in achvs) {
            cur = setVar(cur, a, "1000000")
        }
        return commit(c, cur, "Pencapaian: semua pencapaian diselesaikan ke level maksimal ✔", log) { true }
    }

    fun unlockSeason(c: Context): List<String> {
        val log = ArrayList<String>()
        if (!needSession(log)) return log
        val xml = readXml(c, log) ?: return log
        var cur = setVar(xml, "GoldenPassActive", "1")
        cur = setVar(cur, "SeasonPassActive", "1")
        cur = setVar(cur, "HasGoldenTicket", "1")
        cur = setVar(cur, "GoldenTicketBought", "1")
        cur = setVar(cur, "GoldenPassPoints", "5000")
        cur = setVar(cur, "SeasonPoints", "5000")
        return commit(c, cur, "Tiket Musim: Golden Pass aktif (5000 poin) ✔", log) { true }
    }

    fun setWarehouse(c: Context, capacity: Long): List<String> {
        val log = ArrayList<String>()
        if (!needSession(log)) return log
        val xml = readXml(c, log) ?: return log
        val capStr = capacity.coerceIn(100L, 5_000_000L).toString()
        var cur = setVar(xml, "BarnCapacity", capStr)
        cur = setVar(cur, "WarehouseCapacity", capStr)
        cur = setVar(cur, "Barn_capacity", capStr)
        val bRe = Regex("""(<Building\b[^>]*?\bname="Barn"[^>]*?\bcapacity=")([^"]*)(")""")
        if (bRe.containsMatchIn(cur)) {
            cur = bRe.replace(cur) { it.groupValues[1] + capStr + it.groupValues[3] }
        }
        return commit(c, cur, "Gudang: kapasitas diset ke $capStr ✔", log) { true }
    }

    fun setMarket(c: Context, slots: Int): List<String> {
        val log = ArrayList<String>()
        if (!needSession(log)) return log
        val xml = readXml(c, log) ?: return log
        val slStr = slots.coerceIn(10, 2000).toString()
        var cur = setVar(xml, "MarketBoxes", slStr)
        cur = setVar(cur, "MarketSlots", slStr)
        cur = setVar(cur, "DealerHired", "1")
        cur = setVar(cur, "DealerTimeLeft", "8640000")
        return commit(c, cur, "Pasar: $slStr slot + Pedagang aktif ✔", log) { true }
    }

    fun unlockPerks(c: Context): List<String> {
        val log = ArrayList<String>()
        if (!needSession(log)) return log
        val xml = readXml(c, log) ?: return log
        val perks = listOf(
            "Perk_FastCrops" to "1",
            "Perk_FastFactory" to "1",
            "Perk_DoubleCrops" to "1",
            "Perk_SpaciousBarn" to "1",
            "Perk_HighSpeedTrains" to "1",
            "Perk_GenerousCustomer" to "1",
            "Perk_ActiveCoop" to "1",
            "Perk_HelicopterFast" to "1"
        )
        var cur = xml
        for ((k, v) in perks) {
            cur = setVar(cur, k, v)
        }
        return commit(c, cur, "Keuntungan: ${perks.size} keuntungan kota aktif ✔", log) { true }
    }

    fun speedupTrains(c: Context): List<String> {
        val log = ArrayList<String>()
        if (!needSession(log)) return log
        val xml = readXml(c, log) ?: return log
        var cur = setVar(xml, "TrainReturnTime", "0")
        cur = setVar(cur, "InstantTrains", "1")
        val tRe = Regex("""(<Train\b[^>]*?\btime=")([^"]*)(")""")
        if (tRe.containsMatchIn(cur)) {
            cur = tRe.replace(cur) { it.groupValues[1] + "0" + it.groupValues[3] }
        }
        return commit(c, cur, "Kereta: waktu tunggu di-reset (langsung tiba) ✔", log) { true }
    }

    fun boostRegatta(c: Context, score: Int = 2160): List<String> {
        val log = ArrayList<String>()
        if (!needSession(log)) return log
        val xml = readXml(c, log) ?: return log
        val scStr = score.coerceIn(0, 100000).toString()
        var cur = setVar(xml, "RegataTasksCompleted", "16")
        cur = setVar(cur, "RegataScore", scStr)
        cur = setVar(cur, "RegattaPoints", scStr)
        return commit(c, cur, "Regata: 16 tugas selesai, skor $scStr ✔", log) { true }
    }

    fun boostSendCards(c: Context): List<String> {
        val log = ArrayList<String>()
        if (!needSession(log)) return log
        val xml = readXml(c, log) ?: return log
        var cur = setVar(xml, "CardsSent", "10000")
        cur = setVar(cur, "DailyGiftsSent", "0")
        cur = setVar(cur, "HelpCount", "10000")
        cur = setVar(cur, "LivesSent", "10000")
        return commit(c, cur, "Kirim Kartu: kuota kirim kartu & bantuan dimaksimalkan ✔", log) { true }
    }

    fun boostEvents(c: Context): List<String> {
        val log = ArrayList<String>()
        if (!needSession(log)) return log
        val xml = readXml(c, log) ?: return log
        var cur = setVar(xml, "ExpeditionEnergy", "999999")
        cur = setVar(cur, "expenergy", "999999")
        cur = setVar(cur, "MiniGameLives", "999")
        cur = setVar(cur, "EventEnergy", "999999")
        cur = setVar(cur, "FirstWinStreak", "100")
        return commit(c, cur, "Event: Energi ekspedisi 999999, nyawa 999, win streak 100 ✔", log) { true }
    }

    fun resetNewCity(c: Context): List<String> {
        val log = ArrayList<String>()
        if (!needSession(log)) return log
        val xml = readXml(c, log) ?: return log
        CityBackup.backup(c, "sebelum-reset-kota-baru")
        var cur = setVar(xml, "moneyCash", "500")
        cur = setVar(cur, "money", "2000")
        cur = setVar(cur, "levelup", "1")
        cur = setVar(cur, "LevelM3", "1")
        cur = setVar(cur, "FirstWinCount", "0")
        cur = setVar(cur, "gameStartDate", (System.currentTimeMillis() / 1000).toString())
        return commit(c, cur, "Kota Baru: level direset ke 1 (T-Cash 500, Koin 2000) ✔", log) { true }
    }
}
