package com.aurorats.tools

import android.content.Context
import android.content.Intent

/**
 * Jembatan ke game Township.
 * - launch(): membuka Township langsung dari app.
 * - stop(): mematikan proses Township sebelum penulisan save.
 * - apply(): TITIK INTEGRASI - menghubungkan tiap fitur langsung ke StatsEngine.
 */
object GameBridge {
    const val PACKAGE = "com.playrix.township"
    var lastContext: Context? = null

    fun isInstalled(c: Context): Boolean {
        lastContext = c.applicationContext
        return c.packageManager.getLaunchIntentForPackage(PACKAGE) != null
    }

    fun launch(c: Context): Boolean {
        lastContext = c.applicationContext
        val i: Intent = c.packageManager.getLaunchIntentForPackage(PACKAGE) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        c.startActivity(i)
        return true
    }

    /** Apakah proses Township masih hidup. */
    fun isRunning(@Suppress("UNUSED_PARAMETER") c: Context): Boolean? {
        if (Env.rootVerified == true) {
            val n = RootShell.exec("(ps -A 2>/dev/null || ps) | grep -c '[c]om.playrix.township'", 5000)?.text?.trim()?.toIntOrNull()
            if (n != null) return n > 0
        }
        return try {
            val dirs = java.io.File("/proc").listFiles { f -> f.isDirectory && f.name.all { it.isDigit() } } ?: return null
            var readable = 0
            for (d in dirs) {
                val name = try { java.io.File(d, "cmdline").readText().substringBefore('\u0000').trim() } catch (_: Exception) { continue }
                readable++
                if (name == PACKAGE || name.startsWith("$PACKAGE:")) return true
            }
            if (readable > 2) false else null
        } catch (_: Exception) { null }
    }

    /**
     * Matikan Township sungguh-sungguh (BLOKIR, panggil dari thread latar).
     */
    fun stop(c: Context): Boolean? {
        if (isRunning(c) == false) return true
        var state: Boolean? = null
        repeat(3) {
            if (Env.rootVerified == true) RootShell.exec("am force-stop $PACKAGE; for p in \$(pidof $PACKAGE 2>/dev/null); do kill -9 \$p; done", 6000)
            else RootShell.sh("am force-stop $PACKAGE", 5000)
            try { (c.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager).killBackgroundProcesses(PACKAGE) } catch (_: Exception) {}
            try { Thread.sleep(700) } catch (_: InterruptedException) {}
            state = isRunning(c)
            if (state == false) return true
        }
        return state
    }

    /**
     * Jalankan fitur langsung di engine (StatsEngine).
     * @return true bila fitur berhasil disiapkan oleh engine; false = gagal / tidak dikenali.
     */
    fun apply(c: Context, feature: String, value: Int? = null): Boolean {
        lastContext = c.applicationContext
        val f = feature.lowercase().trim()
        val res: List<String>? = when {
            f.contains("avatar") -> StatsEngine.unlockFlags(c, "Avatar", "Unlocked_ava")
            f.contains("decor") || f.contains("dekorasi") -> StatsEngine.unlockDecor(c)
            f.contains("land") || f.contains("tanah") || f.contains("wilayah") -> StatsEngine.unlockLand(c)
            f.contains("museum") -> StatsEngine.unlockMuseum(c)
            f.contains("allcards") || f.contains("semua kartu") -> StatsEngine.unlockAllCards(c)
            f.contains("mycards") || f.contains("kartu saya") -> StatsEngine.upgradeMyCards(c)
            f.contains("skin") -> StatsEngine.unlockSkins(c)
            f.contains("sticker") || f.contains("stiker") -> StatsEngine.unlockStickers(c)
            f.contains("profile") || f.contains("profil") -> StatsEngine.unlockProfile(c)
            f.contains("achv") || f.contains("pencapaian") -> StatsEngine.unlockAchievements(c)
            f.contains("season") || f.contains("musim") || f.contains("tiket") || f.contains("golden") -> StatsEngine.unlockSeason(c)
            f.contains("warehouse") || f.contains("gudang") -> StatsEngine.setWarehouse(c, (value ?: 100000).toLong())
            f.contains("market") || f.contains("pasar") -> StatsEngine.setMarket(c, value ?: 200)
            f.contains("perk") || f.contains("keuntungan") -> StatsEngine.unlockPerks(c)
            f.contains("train") || f.contains("kereta") -> StatsEngine.speedupTrains(c)
            f.contains("zoo") -> StatsEngine.zooComplete(c, null)
            f.contains("tutorial") -> StatsEngine.fixTutorials(c)
            f.contains("regat") -> StatsEngine.boostRegatta(c, value ?: 2160)
            f.contains("sendcards") || f.contains("kirim kartu") -> StatsEngine.boostSendCards(c)
            f.contains("event") || f.contains("energi") -> StatsEngine.boostEvents(c)
            f.contains("newcity") || f.contains("kota baru") -> StatsEngine.resetNewCity(c)
            else -> {
                val stat = Stats.LIST.firstOrNull { it.key.equals(f, true) || it.label.equals(feature, true) }
                if (stat != null && value != null) {
                    StatsEngine.apply(c, stat, value.toString())
                } else null
            }
        }
        return res != null && res.any { it.contains("✔") }
    }

    /** Overload bila konteks tidak dikirim langsung (menggunakan lastContext). */
    fun apply(feature: String, value: Int? = null): Boolean {
        val c = lastContext ?: return false
        return apply(c, feature, value)
    }
}
