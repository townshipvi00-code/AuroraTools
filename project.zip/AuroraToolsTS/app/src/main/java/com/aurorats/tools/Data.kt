package com.aurorats.tools

enum class Kind { MENU, ACTION, NUMBER, INFO, HELP, STATS, BACKUP, EDITOR }

/** Satu node pada pohon menu. */
class Node(
    val title: String,
    val banner: String,
    val kind: Kind = Kind.MENU,
    val children: List<Node> = emptyList(),
    val max: Int = 0,
    val key: String = ""
)

const val F_BACKUP = "Backup City Data"
const val F_FETCH = "Fetch City Data"
const val F_RESTORE = "Restore City Data"

object Menus {
    /** Daftar semua fitur (daun) di bawah sebuah node beserta jalurnya, untuk pencarian. */
    fun flatten(n: Node, path: String = ""): List<Pair<Node, String>> {
        val here = if (n === root) "" else if (path.isEmpty()) n.title else "$path › ${n.title}"
        return n.children.flatMap { c -> if (c.kind == Kind.MENU && c.children.isNotEmpty()) flatten(c, here) else listOf(c to here) }
    }

    val root: Node = Node("AuroraToolsTS", "player", Kind.MENU,
        listOf(
            Node("Statistik Profil", "player", Kind.STATS),
            Node("Buka Avatar", "avatar", Kind.ACTION),
            Node("Buka Dekorasi", "decor", Kind.ACTION),
            Node("Buka Tanah & Wilayah", "land", Kind.ACTION),
            Node("Selesaikan Museum", "museum", Kind.ACTION),
            Node("Buka Semua Kartu", "cards", Kind.ACTION),
            Node("Buka Semua Skin", "skin", Kind.ACTION),
            Node("Buka Semua Stiker", "sticker", Kind.ACTION),
            Node("Buka Item Profil (Frame & Badge)", "profile", Kind.ACTION),
            Node("Selesaikan Semua Pencapaian", "achv", Kind.ACTION),
            Node("Buka Tiket Musim / Golden Pass", "season", Kind.ACTION),
            Node("Kapasitas Gudang", "warehouse", Kind.NUMBER, max = 2000000),
            Node("Slot Pasar", "market", Kind.NUMBER, max = 1000),
            Node("Keuntungan Kota (Town Perks)", "perks", Kind.ACTION),
            Node("Percepat Kereta", "train", Kind.ACTION),
            Node("Selesaikan Kandang Zoo", "zoo", Kind.ACTION),
            Node("Perbaiki Bug Tutorial", "tutorial", Kind.ACTION),
            Node("Booster Event & Energi", "events", Kind.ACTION),
            Node("Bebas Kirim Kartu", "sendcards", Kind.ACTION),
            Node("Poin Regata", "regata", Kind.NUMBER, max = 2160),
            Node("Cadangkan Data Kota", "backup", Kind.ACTION),
            Node("Reset Kota Baru Level 1", "newcity", Kind.ACTION)
        )
    )
}
