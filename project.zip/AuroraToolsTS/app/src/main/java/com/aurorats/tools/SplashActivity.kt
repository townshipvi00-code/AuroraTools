package com.aurorats.tools

import android.app.Activity
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.*
import android.widget.*

class SplashActivity : Activity() {
    override fun onResume() {
        super.onResume()
        Perf.lock60(this)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        S.load(this)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val d = resources.displayMetrics.density
        val root = FrameLayout(this)
        root.addView(AuroraBackground(this))

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        val stack = FrameLayout(this)
        val halo = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#3D6BFF"), Color.parseColor("#9B4DFF"))
            ).apply { shape = GradientDrawable.OVAL }
            alpha = 0.35f
        }
        stack.addView(halo, FrameLayout.LayoutParams((230 * d).toInt(), (230 * d).toInt(), Gravity.CENTER))

        val logo = ImageView(this).apply {
            setImageResource(R.drawable.logo_rounded)
            clipToOutline = true
            elevation = 12 * d
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) = o.setRoundRect(0, 0, v.width, v.height, 36 * d)
            }
        }
        stack.addView(logo, FrameLayout.LayoutParams((170 * d).toInt(), (170 * d).toInt(), Gravity.CENTER))
        stack.addView(OrbitView(this), FrameLayout.LayoutParams(-1, -1))
        box.addView(stack, LinearLayout.LayoutParams((240 * d).toInt(), (240 * d).toInt()))

        val title = GlowText(this).apply {
            text = "AuroraToolsTS"
            textSize = 28f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val sub = TextView(this).apply {
            text = "Powered by AuroraTS • 60 FPS VIP"
            textSize = 13f
            setTextColor(Color.parseColor("#C9B8FF"))
        }
        box.addView(title)
        box.addView(sub)

        // Bar loading bergradasi
        val track = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                cornerRadius = 4 * d
                setColor(Color.parseColor("#26FFFFFF"))
            }
        }
        val fill = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.parseColor("#35D6FF"), Color.parseColor("#3D6BFF"), Color.parseColor("#9B4DFF"))
            ).apply { cornerRadius = 4 * d }
            pivotX = 0f
            scaleX = 0f
        }
        track.addView(fill, FrameLayout.LayoutParams(-1, -1))
        box.addView(track, LinearLayout.LayoutParams((170 * d).toInt(), (4 * d).toInt()).apply { topMargin = (26 * d).toInt() })
        fill.post {
            fill.pivotX = 0f
            fill.animate().scaleX(1f).setDuration(1600).setInterpolator(android.view.animation.AccelerateDecelerateInterpolator()).start()
        }

        root.addView(box, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        listOf(logo, title, sub).forEachIndexed { i, v ->
            v.alpha = 0f
            v.scaleX = .6f
            v.scaleY = .6f
            v.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(i * 120L).setDuration(700).setInterpolator(Spring(1.8f, 5.5f)).start()
        }
        if (S.effects) {
            Fx.pulse(halo, 0.95f, 1.25f, 1500)
            Fx.spin(halo, 7000)
            Fx.float(logo, 3f, 2200)
        } else {
            halo.alpha = 0.2f
        }

        // Verifikasi lisensi non-blokir: hanya cabut jika server eksplisit menyatakan dicabut
        var denied = false
        if (S.activated && S.key.isNotEmpty()) {
            License.verify(this, S.key) { r ->
                if (!r.ok && (r.error == "revoked" || r.error == "device_limit")) {
                    denied = true
                    S.setActivated(false)
                }
            }
        }

        Handler(Looper.getMainLooper()).postDelayed({
            val nextClass = if (S.activated && !denied) MainActivity::class.java else LoginActivity::class.java
            startActivity(Intent(this, nextClass))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }, 1800)
    }
}
