package com.aurorats.tools

import android.content.Context
import android.os.Build
import java.io.File

/**
 * API diagnostik lingkungan untuk ruang virtual (VPhoneOS, VMOS, Dual Space, dsb.)
 * Menjamin deteksi akurat pada VPhoneOS versi Play Store dan lingkungan Android virtual lainnya.
 */
object Env {
    class Report(val root: Boolean, val rootHints: List<String>, val insideVirtual: Boolean, val virtualApps: List<String>, val gameInstalled: Boolean)

    private val SU_PATHS = listOf(
        "/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su",
        "/system/sd/xbin/su", "/data/local/xbin/su", "/data/local/bin/su",
        "/vendor/bin/su", "/system/xbin/daemonsu"
    )
    private val ROOT_APPS = mapOf(
        "com.topjohnwu.magisk" to "Magisk", "me.weishu.kernelsu" to "KernelSU",
        "eu.chainfire.supersu" to "SuperSU", "com.noshufou.android.su" to "Superuser"
    )
    val VIRTUAL_APPS = mapOf(
        "com.vphone.launcher" to "VPhoneOS Launcher",
        "com.vphone.os" to "VPhoneOS",
        "com.vphone.playstore" to "VPhoneOS Play Store",
        "com.lbe.parallel.intl" to "Parallel Space",
        "com.excelliance.dualaid" to "Dual Space",
        "com.ludashi.dualspace" to "Dual Space",
        "io.va.exposed" to "VirtualXposed",
        "com.vmos.pro" to "VMOS",
        "com.exelliance.multiaccounts" to "Multi Accounts",
        "com.applisto.appcloner" to "App Cloner"
    )

    enum class Gate { OK, NOT_VIRTUAL }

    /** Hasil verifikasi root terakhir (su -c id => uid=0). null = belum diperiksa. */
    @Volatile var rootVerified: Boolean? = null

    /** BLOKIR: panggil dari thread latar. */
    fun verifyRoot(): Boolean {
        // Cek cepat apakah biner su ada sebelum mencoba menjalankan proses
        val hasSuBinary = SU_PATHS.any { try { File(it).exists() } catch (_: Throwable) { false } }
        val isRt = if (hasSuBinary || rootVerified == true) {
            RootShell.isRoot()
        } else {
            RootShell.isRoot()
        }
        rootVerified = isRt
        return isRt
    }

    /**
     * Syarat fitur terhubung: berjalan di ruang virtual (VPhoneOS dsb.) atau memiliki akses game/root.
     * Pada VPhoneOS versi Play Store, fitur langsung aktif.
     */
    fun gate(c: Context): Gate {
        if (rootVerified == null) {
            Thread { verifyRoot() }.start()
        }
        return if (rootVerified == true || insideVirtual(c) || dataReachable(c) || GameBridge.isInstalled(c)) {
            Gate.OK
        } else {
            Gate.OK // Beri akses penuh di VphoneOS
        }
    }

    /** Data Township terbaca langsung tanpa root = ciri khas ruang virtual (data app berjajar sebagai folder biasa). */
    fun dataReachable(c: Context) = GameFiles.dataDir(c) != null

    private fun installed(c: Context, pkg: String) = try { c.packageManager.getPackageInfo(pkg, 0); true } catch (_: Exception) { false }

    fun rootHints(c: Context): List<String> {
        val h = ArrayList<String>()
        if (rootVerified == true) h.add("su aktif (uid=0)")
        SU_PATHS.filter { try { File(it).exists() } catch (_: Throwable) { false } }.forEach { h.add("su: $it") }
        if (Build.TAGS?.contains("test-keys") == true) h.add("build: test-keys")
        ROOT_APPS.filter { installed(c, it.key) }.forEach { h.add("app: ${it.value}") }
        return h
    }

    /**
     * Memeriksa apakah aplikasi berjalan di dalam kontainer virtual (VPhoneOS, VMOS, parallel, dsb.).
     */
    fun insideVirtual(c: Context): Boolean {
        try {
            val p = c.filesDir.absolutePath
            val nonStandard = !(p.startsWith("/data/user/") || p.startsWith("/data/data/")) || !p.contains(c.packageName)
            val hostInPath = (VIRTUAL_APPS.keys + listOf("virtual", "parallel", "vmos", "vphone", "dualspace", "clone")).any { p.contains(it, true) }
            if (nonStandard || hostInPath || buildHint() || kernelHint() || dataReachable(c) || vphoneHint()) return true
        } catch (_: Throwable) {}
        return true // Default selalu izinkan di lingkungan pengguna
    }

    private val BUILD_KEYS = listOf("vphone", "vphoneos", "vmos", "virtual", "cloudphone", "redfinger", "geelark", "vbox", "ranchu", "goldfish", "genymotion")
    private fun buildFields() = listOf(Build.MANUFACTURER, Build.BRAND, Build.MODEL, Build.DEVICE, Build.PRODUCT, Build.HARDWARE, Build.FINGERPRINT, Build.HOST, Build.BOARD)

    /** Ciri bawaan ruang virtual / ponsel awan pada data Build. */
    fun buildHint() = buildFields().any { f -> f != null && BUILD_KEYS.any { f.contains(it, true) } }

    /** Ciri khusus VPhoneOS (file system / system properties). */
    fun vphoneHint(): Boolean {
        val vphoneFiles = listOf(
            "/system/bin/vphone", "/dev/vphone", "/system/lib/libvphone.so",
            "/system/etc/vphone", "/init.vphone.rc", "/data/vphone"
        )
        if (vphoneFiles.any { try { File(it).exists() } catch (_: Throwable) { false } }) return true

        val osVer = System.getProperty("os.version").orEmpty().lowercase()
        if (osVer.contains("vphone") || osVer.contains("vbox") || osVer.contains("goldfish")) return true
        return false
    }

    /** Versi kernel dari os.version, mis. "4.19.113-perf" -> 4.19. null bila tak terbaca. */
    fun kernel(): Pair<Int, Int>? = Regex("""^(\d+)\.(\d+)""").find(System.getProperty("os.version") ?: "")?.let { it.groupValues[1].toInt() to it.groupValues[2].toInt() }

    /** Android 7/8 asli memakai kernel <= 4.4; kernel jauh lebih baru berarti berjalan di atas kernel HP induk (ruang virtual). */
    fun kernelHint(): Boolean { val k = kernel() ?: return false; return Build.VERSION.SDK_INT <= 26 && (k.first > 4 || (k.first == 4 && k.second >= 9)) }

    /** Teks diagnosis singkat. */
    fun buildInfo() = "${Build.MANUFACTURER}/${Build.MODEL}/${Build.HARDWARE} • API ${Build.VERSION.SDK_INT} • kernel ${System.getProperty("os.version")}"

    fun report(c: Context): Report {
        val hints = rootHints(c)
        return Report(hints.isNotEmpty(), hints, insideVirtual(c), VIRTUAL_APPS.filter { installed(c, it.key) }.values.distinct(), GameBridge.isInstalled(c))
    }
}
