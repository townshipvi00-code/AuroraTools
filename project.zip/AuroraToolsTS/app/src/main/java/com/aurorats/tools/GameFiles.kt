package com.aurorats.tools

import android.content.Context
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Akses data Township untuk aplikasi di ruang virtual (VPhoneOS, VMOS, dsb.).
 * Mendukung pencarian jalur data internal & eksternal VPhoneOS secara komprehensif.
 */
object GameFiles {
    val PARTS = listOf("files", "shared_prefs", "databases", "saves")

    /** Semua folder data Township yang terjangkau di VphoneOS / ruang virtual. */
    fun allDataDirs(c: Context): List<File> {
        val pkg = GameBridge.PACKAGE
        val cand = ArrayList<File>()
        c.dataDir?.parentFile?.let { cand.add(File(it, pkg)) }
        val fp = c.filesDir.absolutePath
        if (fp.contains(c.packageName)) {
            cand.add(File(fp.substringBefore(c.packageName) + pkg))
        }
        cand.add(File("/data/data/$pkg"))
        cand.add(File("/data/user/0/$pkg"))
        cand.add(File("/data/user/10/$pkg"))
        cand.add(File("/data/user/999/$pkg"))
        cand.add(File("/storage/emulated/0/Android/data/$pkg"))
        cand.add(File("/sdcard/Android/data/$pkg"))

        // Jalur sandbox spesifik VphoneOS / VMOS / VirtualXposed
        val vRoots = listOf(
            "/data/data/com.vphoneos.launcher/files/virtual/data/user/0/$pkg",
            "/data/user/0/com.vphoneos.launcher/files/virtual/data/user/0/$pkg",
            "/data/data/com.vphoneos.playstore/files/virtual/data/user/0/$pkg",
            "/data/user/0/com.vphoneos.playstore/files/virtual/data/user/0/$pkg",
            "/data/data/com.vphone.launcher/files/virtual/data/user/0/$pkg",
            "/data/user/0/com.vphone.launcher/files/virtual/data/user/0/$pkg",
            "/data/data/com.vphoneos.tool/files/virtual/data/user/0/$pkg"
        )
        for (v in vRoots) cand.add(File(v))

        try {
            c.getExternalFilesDir(null)?.parentFile?.parentFile?.let { cand.add(File(it, pkg)) }
        } catch (_: Throwable) {}

        return cand.distinct().filter { d ->
            try {
                d.isDirectory && (d.canRead() || PARTS.any { File(d, it).isDirectory })
            } catch (_: Throwable) {
                false
            }
        }.sortedBy { if (isExternal(it)) 1 else 0 }   // data internal/virtual lebih dulu; folder penyimpanan eksternal paling akhir
    }

    /** Folder di penyimpanan eksternal (/sdcard/Android/data/...) BUKAN tempat save asli Township. */
    fun isExternal(f: File): Boolean = f.absolutePath.let { it.startsWith("/storage/") || it.startsWith("/sdcard/") || it.startsWith("/mnt/") }

    /** Folder data Township utama yang bisa dibaca langsung, atau null bila tidak terjangkau tanpa root. */
    fun dataDir(c: Context): File? = allDataDirs(c).firstOrNull()

    /** Cari semua file save (mGameInfo.xml dan cermin _ed_source) di seluruh direktori data. */
    fun findSaveFiles(c: Context): List<File> {
        val out = ArrayList<File>()
        for (dir in allDataDirs(c)) {
            out.addAll(find(dir, "mGameInfo.xml"))
            out.addAll(find(dir, "_ed_source"))
        }
        return out.distinctBy { it.absolutePath }
    }

    fun parts(dir: File): List<String> = PARTS.filter { try { File(dir, it).isDirectory } catch (_: Throwable) { false } }

    fun find(dir: File, name: String): List<File> = try {
        dir.walkTopDown().onEnter { try { it.canRead() } catch (_: Throwable) { false } }
            .filter { try { it.isFile && it.name == name && it.canRead() } catch (_: Throwable) { false } }.toList()
    } catch (_: Throwable) { emptyList() }

    /** Kemas folder data game menjadi .zip. @return true bila ada file yang berhasil dikemas. */
    fun zipTo(dir: File, parts: List<String>, dest: File): Boolean = try {
        var n = 0
        ZipOutputStream(dest.outputStream().buffered()).use { z ->
            for (p in parts) File(dir, p).walkTopDown().onEnter { it.canRead() }.filter { it.isFile && it.canRead() }.forEach { f ->
                z.putNextEntry(ZipEntry(f.relativeTo(dir).path))
                try { f.inputStream().use { it.copyTo(z) }; n++ } catch (_: Exception) {}
                z.closeEntry()
            }
        }
        (n > 0).also { if (!it) dest.delete() }
    } catch (_: Exception) { dest.delete(); false }
}
