package com.aurorats.tools

import java.io.File
import java.io.FileOutputStream

/**
 * Pembungkus `su` untuk dipakai DI DALAM ruang virtual (VMOS dsb.).
 * Hanya dipanggil dari thread latar, dengan batas waktu agar tidak menggantung.
 */
object RootShell {
    class Out(val code: Int, val text: String)

    /** Jalankan perintah lewat su dan kembalikan stdout; null bila su gagal / timeout. */
    fun exec(cmd: String, timeoutMs: Long = 6000): Out? = try {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(false).start()
        val sb = StringBuilder()
        val t = Thread { try { sb.append(p.inputStream.bufferedReader().readText()) } catch (_: Exception) {} }
        t.start(); t.join(timeoutMs)
        if (t.isAlive) { p.destroy(); null } else Out(p.waitFor(), sb.toString())
    } catch (_: Exception) { null }

    /** Jalankan perintah lewat `sh` biasa (tanpa su) dengan batas waktu; null bila gagal / timeout. */
    fun sh(cmd: String, timeoutMs: Long = 5000): Out? = try {
        val p = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
        val sb = StringBuilder()
        val t = Thread { try { sb.append(p.inputStream.bufferedReader().readText()) } catch (_: Exception) {} }
        t.start(); t.join(timeoutMs)
        if (t.isAlive) { p.destroy(); null } else Out(p.waitFor(), sb.toString())
    } catch (_: Exception) { null }

    /** Root dianggap benar-benar aktif bila `su -c id` mengembalikan uid=0. */
    fun isRoot(): Boolean = exec("id", 4000)?.text?.contains("uid=0") == true

    /** Alirkan stdout perintah (biner, mis. tar) langsung ke file. @return true bila exit code 0 dan file tidak kosong. */
    fun pipeTo(cmd: String, dest: File, timeoutMs: Long = 120_000): Boolean = try {
        val p = ProcessBuilder("su", "-c", cmd).start()
        var ok = false
        val t = Thread {
            try { FileOutputStream(dest).use { o -> p.inputStream.copyTo(o) }; ok = true } catch (_: Exception) {}
        }
        t.start(); t.join(timeoutMs)
        if (t.isAlive) { p.destroy(); dest.delete(); false }
        else (ok && p.waitFor() == 0 && dest.length() > 0).also { if (!it) dest.delete() }
    } catch (_: Exception) { dest.delete(); false }
}
