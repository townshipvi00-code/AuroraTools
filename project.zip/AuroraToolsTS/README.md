# AuroraToolsTS — Powered by AuroraTS
Panduan build: lihat BUILD_RELEASE.md
- SplashActivity.kt : splash beranimasi
- MainActivity.kt   : menu, Info & Pengaturan (bahasa ID/EN, efek latar), layout HP 1 kolom / tablet 2 kolom
- Data.kt           : susunan menu (mengikuti mainMenu() di TSSV14.lua)
- GameBridge.kt     : launch() membuka Township; apply() = titik integrasi fitur (belum terhubung)
- res/drawable-nodpi/banner_*.png : gambar tiap layout; ikon = foto yang diupload (sudut melengkung)
- Env.kt / RootShell.kt : gerbang — fitur hanya jalan di ruang virtual (VPhoneOS, VMOS, dsb.); root OPSIONAL (bila `su -c id` = uid=0 dipakai, bila tidak -> GameFiles.kt)
- GameFiles.kt : mode TANPA root, membaca data Township langsung sebagai file di ruang virtual (backup jadi .zip)
- CityBackup.kt : cadangkan data game (tar) & fetch mGameInfo.xml → <externalFiles>/AuroraTS/{backup,fetch}
- Stats.kt : Statistik Profil — baca/tulis nyata ke mGameInfo.xml (XML polos, <Var name=.. v=..>). Terpetakan 12 dari 12.

## Menghubungkan ke server lisensi (ringkas)
1. VPS: `mkdir /opt/aurora-license`, salin isi `license-server/` ke sana, `chown -R www-data /opt/aurora-license`.
2. `cp deploy/aurora-license.service /etc/systemd/system/ && systemctl enable --now aurora-license`
3. Pasang Caddy dengan `deploy/Caddyfile` (ganti domain) agar HTTPS aktif.
4. Tes: `curl https://domain-anda/version` harus mengembalikan JSON.
5. Di komputer build: `./set-server.sh https://domain-anda`, lalu build ulang APK.
6. Daftarkan key: `python3 server.py add-key KEY --max 1 --label nama` (atau `gen`).

## Cara cepat (uji coba, tanpa VPS)
`./start-server.sh` -> menjalankan server + tunnel dan mengisi config.xml otomatis. Lalu build APK. Jendela harus tetap terbuka.

## Hosting gratis (Render)
1. Unggah folder ini ke repo GitHub (jangan sertakan keystore).
2. Render.com > New > Blueprint > pilih repo (membaca `render.yaml`). Key di env `AURORA_KEYS` (pisahkan koma) didaftarkan otomatis tiap server menyala.
3. Alamat: `https://aurora-license.onrender.com` (atau sesuai nama). Isi dengan `./set-server.sh`, build ulang APK.
Catatan: paket gratis tidur setelah ~15 menit tanpa trafik (bangun ±50 dtk; timeout app sudah 60 dtk). Database di /tmp hilang saat restart -> pengikatan perangkat ke-reset, key tetap ada dari env.

## Alur edit (v1.9.9+)
1. **HUBUNGKAN** — cek ruang virtual, cadangkan data, dekode mGameInfo.xml, simpan di memori (status jadi ONLINE).
2. Edit di tab Statistik/Buka/Alat/Premium — tiap "Terapkan" hanya mengubah salinan di memori.
3. **SIMPAN & KIRIM** — enkode (format asli save dipertahankan), timpa data game, baca ulang untuk verifikasi, lalu luncurkan Township.
   Bila save di disk berubah sejak HUBUNGKAN (game masih jalan), penyimpanan dibatalkan agar tidak menimpa progres.
Tanpa HUBUNGKAN, SIMPAN & KIRIM hanya membuka Township.

## Penyimpanan ke game (perbaikan)
- Berkas save dikunci saat HUBUNGKAN; SIMPAN & KIRIM menulis ke berkas yang sama (bukan memilih ulang). Bila ada beberapa salinan mGameInfo.xml, dipilih yang terbaru.
- Bila save di disk berubah sejak HUBUNGKAN, edit diterapkan ulang ke data terbaru (bukan dibatalkan).
- Tulis memakai fsync, dicoba walau canWrite() salah; diverifikasi dua kali (langsung dan setelah 1,5 dtk) agar terdeteksi bila Township menimpa lagi.
- Tanpa root: Township dimatikan lewat killBackgroundProcesses (izin ditambahkan di manifest).

## ID kota & deteksi lingkungan
- Kolom **ID kota** di console (tombol PAKAI ID / Enter): kosong = save terbaru; diisi = HUBUNGKAN memilih mGameInfo.xml yang path/isinya memuat ID itu (bila hanya ada satu save, dipakai dengan peringatan). ID terakhir diingat.
- Gerbang kini lolos bila: root aktif (su uid=0), ATAU ruang virtual terdeteksi, ATAU data Township terbaca langsung. Info › Root/Ruang virtual menampilkan alasan deteksi; ketuk kartu Root untuk periksa ulang.

## Perbaikan v1.9.12 — nilai Tcash/Koin tidak bertambah di game
- Penyebab: `writeBack` menulis ke SEMUA folder kandidat (termasuk /sdcard/Android/data/...) dan menganggap sukses bila salah satu berhasil, padahal save asli yang dibaca game tidak tertulis. Tidak ada pengecekan isi setelah menulis.
- Kini hanya menulis ke berkas save yang sama dengan saat HUBUNGKAN (+ cermin `_ed_source` di folder itu); tidak membuat berkas tiruan dan tidak menimpa save kota lain.
- Setelah menulis, save dibaca ulang & didekode, lalu dibandingkan dengan editan (langsung dan setelah 1,5 dtk). Bila beda, muncul pesan gagal dan Township tidak diluncurkan.
- Pemilihan save: data internal/virtual diprioritaskan; folder eksternal (/sdcard/Android/data) hanya dipakai bila tidak ada yang lain (versi lama membuat berkas tiruan di sana dengan waktu terbaru, sehingga HUBUNGKAN memilihnya dan editan tidak pernah sampai ke save asli).
- T-Cash dibatasi 2147483647 (tipe int32 `t="i"`); nilai lebih besar bisa membuat save dianggap rusak lalu dikembalikan oleh game.

## Perbaikan v1.5-fix-hash — Tcash/Koin kembali ke nilai lama setelah game dibuka
- Penyebab utama (dugaan kuat): header enkripsi `0x79` menyimpan `hashLength` yang diturunkan dari UKURAN berkas. Encoder lama selalu memakai `hashLength` save asli, padahal ukuran hasil edit bisa berbeda; selain itu padding nol ditambahkan DI LUAR bingkai terenkripsi. Game menganggap save rusak lalu memuat `mGameInfo.bak`/cloud, sehingga nilai kembali.
- `AuroraCodec.encode`: bila `hashLength` asli = rumus ukuran dan ukuran baru berbeda, `hashLength` dihitung ulang (`sizeHash`).
- `saveBack`: tidak lagi menambah nol di luar bingkai untuk format 0x79; log baru "Header 0x79: hashLength=… sesuai-ukuran=…".
- `writeBack`: bila `mGameInfo.bak` ada di folder yang sama, ikut ditimpa dengan data hasil edit.
- Bila masih kembali: matikan internet / logout Playrix ID sebelum membuka Township pertama kali (save cloud yang lebih baru menimpa save lokal), dan kirim isi log HUBUNGKAN + SIMPAN & KIRIM.
