#!/usr/bin/env python3
"""Server lisensi AuroraToolsTS (tanpa dependensi, Python 3.8+, SQLite).
Tiap key punya batas perangkat (default 1) -> satu key = satu pengguna/perangkat.
Contoh:
  python3 server.py add-key VIP-26122005-LIFE --max 1 --label "owner"
  python3 server.py gen --max 1 --label "budi"      # buat key baru untuk pengguna lain
  python3 server.py list | reset KEY | revoke KEY | unrevoke KEY
  python3 server.py serve 8080\nPembaruan: edit version.json -> {"version_code": 2, "version_name": "1.1", "url": "https://.../app.apk"}                       # pasang di belakang HTTPS (nginx/Caddy)
"""
import sqlite3, json, hashlib, time, sys, secrets, os, argparse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

DB = os.environ.get("AURORA_DB", "licenses.db")

def db():
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    c.execute("CREATE TABLE IF NOT EXISTS keys(key_hash TEXT PRIMARY KEY, label TEXT, max_devices INTEGER NOT NULL DEFAULT 1, expires INTEGER, revoked INTEGER NOT NULL DEFAULT 0)")
    c.execute("CREATE TABLE IF NOT EXISTS devices(key_hash TEXT, device_id TEXT, first_seen INTEGER, last_seen INTEGER, PRIMARY KEY(key_hash, device_id))")
    return c

def h(k): return hashlib.sha256(k.strip().upper().encode()).hexdigest()

def check(key, dev, bind):
    """Kembalikan (ok, error). expires NULL = seumur hidup."""
    if not key or not dev or len(dev) > 128 or len(key) > 64: return False, "invalid"
    kh = h(key); now = int(time.time())
    with db() as c:
        r = c.execute("SELECT * FROM keys WHERE key_hash=?", (kh,)).fetchone()
        if not r: return False, "invalid"
        if r["revoked"]: return False, "revoked"
        if r["expires"] is not None and r["expires"] < now: return False, "expired"
        known = c.execute("SELECT 1 FROM devices WHERE key_hash=? AND device_id=?", (kh, dev)).fetchone()
        if known:
            c.execute("UPDATE devices SET last_seen=? WHERE key_hash=? AND device_id=?", (now, kh, dev)); return True, None
        if not bind: return False, "device_limit"
        n = c.execute("SELECT COUNT(*) FROM devices WHERE key_hash=?", (kh,)).fetchone()[0]
        if n >= r["max_devices"]: return False, "device_limit"
        c.execute("INSERT INTO devices VALUES(?,?,?,?)", (kh, dev, now, now)); return True, None

HITS = {}
def limited(ip):
    t = time.time(); L = [x for x in HITS.get(ip, []) if t - x < 60]; L.append(t); HITS[ip] = L
    return len(L) > 30

class H(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path != "/version": return self.out(404, {"ok": False, "error": "not_found"})
        try: v = json.load(open(os.environ.get("AURORA_VERSION", "version.json")))
        except Exception: v = {"version_code": 0}
        self.out(200, v)
    def do_POST(self):
        ip = self.client_address[0]
        if limited(ip): return self.out(429, {"ok": False, "error": "rate"})
        try:
            body = json.loads(self.rfile.read(min(int(self.headers.get("Content-Length", 0)), 2048)) or b"{}")
        except Exception: return self.out(400, {"ok": False, "error": "bad_request"})
        if self.path not in ("/activate", "/verify"): return self.out(404, {"ok": False, "error": "not_found"})
        ok, err = check(str(body.get("key", "")), str(body.get("device", "")), True)
        self.out(200, {"ok": ok, "error": err})
    def out(self, code, obj):
        b = json.dumps(obj).encode(); self.send_response(code)
        self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def log_message(self, *a): pass

def main():
    p = argparse.ArgumentParser(); s = p.add_subparsers(dest="cmd", required=True)
    a = s.add_parser("add-key"); a.add_argument("key"); a.add_argument("--max", type=int, default=1); a.add_argument("--label", default=""); a.add_argument("--expires-days", type=int)
    g = s.add_parser("gen"); g.add_argument("--max", type=int, default=1); g.add_argument("--label", default=""); g.add_argument("--expires-days", type=int)
    for n in ("reset", "revoke", "unrevoke"): s.add_parser(n).add_argument("key")
    s.add_parser("list"); sv = s.add_parser("serve"); sv.add_argument("port", type=int, nargs="?", default=8080)
    x = p.parse_args(); c = db()
    def add(k):
        exp = int(time.time() + x.expires_days * 86400) if x.expires_days else None
        c.execute("INSERT OR REPLACE INTO keys VALUES(?,?,?,?,0)", (h(k), x.label, x.max, exp)); c.commit()
        print("OK", k, "max perangkat:", x.max, "| masa aktif:", "seumur hidup" if exp is None else f"{x.expires_days} hari")
    if x.cmd == "add-key": add(x.key)
    elif x.cmd == "gen": add("VIP-%s-%s" % (secrets.token_hex(3).upper(), secrets.token_hex(3).upper()))
    elif x.cmd == "reset": c.execute("DELETE FROM devices WHERE key_hash=?", (h(x.key),)); c.commit(); print("perangkat direset")
    elif x.cmd in ("revoke", "unrevoke"): c.execute("UPDATE keys SET revoked=? WHERE key_hash=?", (1 if x.cmd == "revoke" else 0, h(x.key))); c.commit(); print("OK")
    elif x.cmd == "list":
        for r in c.execute("SELECT k.*, (SELECT COUNT(*) FROM devices d WHERE d.key_hash=k.key_hash) n FROM keys k"):
            print(r["key_hash"][:10], r["label"] or "-", f"{r['n']}/{r['max_devices']} perangkat", "REVOKED" if r["revoked"] else "aktif", "lifetime" if r["expires"] is None else "exp")
    elif x.cmd == "serve":
        # Hosting gratis: database bisa hilang saat restart -> daftarkan ulang key dari env AURORA_KEYS (pisahkan dengan koma)
        for k in filter(None, (v.strip() for v in os.environ.get("AURORA_KEYS", "").split(","))):
            c.execute("INSERT OR IGNORE INTO keys VALUES(?,?,?,NULL,0)", (h(k), "env", int(os.environ.get("AURORA_MAX", "1")))); c.commit()
        print("Mendengarkan di port", x.port); ThreadingHTTPServer(("0.0.0.0", x.port), H).serve_forever()
if __name__ == "__main__": main()
