# Membuat APK rilis AuroraToolsTS

1. Buka folder ini di Android Studio (Hedgehog atau lebih baru, JDK 17). Tunggu Gradle sync selesai;
   Android Studio akan membuat gradle wrapper otomatis.
2. Buat keystore (sekali saja, SIMPAN file & password-nya):
   keytool -genkeypair -v -keystore aurora-release.jks -alias aurorats -keyalg RSA -keysize 2048 -validity 10000
3. Salin `keystore.properties.example` menjadi `keystore.properties`, lalu isi password sesuai langkah 2.
4. Build: Build > Generate Signed Bundle / APK > APK, atau di terminal:
   ./gradlew assembleRelease
5. Hasil: app/build/outputs/apk/release/app-release.apk
   (tanpa keystore.properties, hasilnya `app-release-unsigned.apk` dan belum bisa dipasang).

Debug cepat: ./gradlew assembleDebug  → app/build/outputs/apk/debug/app-debug.apk
Jangan unggah keystore atau keystore.properties ke tempat publik.

## Lisensi per pengguna (server)
1. Jalankan `license-server/server.py` di VPS (lihat komentar di file). Pasang di belakang HTTPS (Caddy/nginx).
2. Daftarkan key: `python3 server.py add-key VIP-26122005-LIFE --max 1 --label owner`
   Key untuk pengguna lain: `python3 server.py gen --max 1 --label nama` (otomatis acak, tanpa masa kedaluwarsa).
3. Isi alamat server di `app/src/main/res/values/config.xml` (`license_server`), lalu build ulang APK.
4. Kelola: `list`, `reset KEY` (pindah perangkat), `revoke KEY` / `unrevoke KEY`.
Satu key hanya bisa dipakai di jumlah perangkat `--max` (default 1).

## Pembaruan versi
Edit `license-server/version.json` di server (`version_code` lebih besar dari versi terpasang + `url` HTTPS ke APK baru).
App akan menampilkan kartu "Pembaruan tersedia" di menu utama. Naikkan `versionCode` di `app/build.gradle` setiap rilis.
